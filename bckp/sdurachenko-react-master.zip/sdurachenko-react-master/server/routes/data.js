const express = require('express');
const cors = require('cors');
const data = require('../data/data');
const router = express.Router();

router.use(cors());

router.get('/', function(req, res, next) {
  res.json(data);
});

module.exports = router;
