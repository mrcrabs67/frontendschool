import React, { useEffect, useState } from 'react'
import Main from '../components/Main'
import Banner from '../components/banner/Banner'
import EventChips from '../components/events/EventChips'
import Events from '../components/events/Events'
import Modal from '../components/modal/Modal'
import reducer from '../reducers/reducers'
import { connect, Provider } from 'react-redux'
import { hideModal, showModal } from '../actions/modal'
import * as eventsApi from '../service/EventsApi'
import { listEvents } from '../actions/events'
import { useHistory } from 'react-router-dom'
import { addUserEvents } from '../actions/userEvents'

const EventsPage = ({ isAuthenticated, events }) => {

  const modalDefaultValues = {};
  const history = useHistory();
  const [currentEvent, setCurrentEvent] = useState();

  useEffect(() => {
    eventsApi.getAllEvents()
      .then((response) => response.data)
      .then((data) => reducer.dispatch(listEvents(data)));
  }, []);

  const onRegistrationClick = (e) => {
    e.preventDefault();
    const eventId = parseInt(e.target.parentNode.parentNode.querySelector('.event-id').innerText);
    const curEvent = reducer.getState().events.find(({id}) => id === eventId);
    setCurrentEvent(curEvent);
    reducer.dispatch(showModal());
  }

  const onRegistrationCancel = (e) => {
    e.preventDefault();
    reducer.dispatch(hideModal());
  }

  const onModalSubmit = (formData) => {
    reducer.dispatch(hideModal());
    const userEvent = { ...formData.event, place: formData.place, comment: formData.comment}
    reducer.dispatch(addUserEvents(userEvent));
    history.push('/user/events');
  }

  const renderPage = () => {
    return (
      <>
        <Main>
          <Banner/>
          <EventChips/>
          <Events onRegistrationClick={onRegistrationClick} events={events}/>
        </Main>
        <Provider store={reducer}>
          <Modal onCancel={onRegistrationCancel} formData={{ ...modalDefaultValues, event: currentEvent }} onModalSubmit={onModalSubmit}/>
        </Provider>
      </>
    );
  }

  return isAuthenticated ? renderPage() : null;


};

function mapStateToProps(state, ownProps) {
  return {
    ...ownProps,
    isAuthenticated: state.user,
    events: state.events,
  };
}

export default connect(mapStateToProps)(EventsPage);