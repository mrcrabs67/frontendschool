import React from 'react'
import { connect } from 'react-redux'
import UserEventRow from '../components/events/UserEventRow'
import OnlyMain from '../components/OnlyMain'

const UserEventsPage = ({ isAuthenticated, events }) => {

  const renderPage = () => {
    return (
      <OnlyMain>
        <div id="events-container">
          {events.map((event) => <UserEventRow key={event.date} event={event}/>)}
        </div>
      </OnlyMain>
    );
  }

  return isAuthenticated ? renderPage() : null;


};

function mapStateToProps(state, ownProps) {
  return {
    ...ownProps,
    isAuthenticated: state.user,
    events: state.userEvents,
  };
}

export default connect(mapStateToProps)(UserEventsPage);