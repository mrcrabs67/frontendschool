import React from 'react'
import { connect } from 'react-redux'
import { useParams } from 'react-router-dom'
import Event from '../components/events/Event'
import OnlyMain from '../components/OnlyMain'

const EventPage = ({ isAuthenticated, events }) => {

  const {id} = useParams();

  const currentEvent = events.find((event) => parseInt(id) === event.id);

  const renderPage = () => {
    return (
      <OnlyMain>
         <Event event={currentEvent}/>
      </OnlyMain>
    );
  }

  return isAuthenticated ? renderPage() : null;


};

function mapStateToProps(state, ownProps) {
  return {
    ...ownProps,
    isAuthenticated: state.user,
    events: state.events,
  };
}

export default connect(mapStateToProps)(EventPage);