
const logger = (store) => (next) => (action) => {
  if (action.type === 'SHOW_MODAL') {
    console.log("Opened modal window");
  } else if (action.type === 'HIDE_MODAL') {
    console.log("Closed modal window");
  }
  return next(action);
};

export default logger;