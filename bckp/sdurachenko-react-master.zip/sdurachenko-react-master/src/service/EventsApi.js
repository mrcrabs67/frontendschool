import axios from "axios";

const serverHost = process.env.REACT_APP_SERVER_HOST;
const client = axios.create();

export function getAllEvents() {
  return client.get(`${serverHost}/data`);
}