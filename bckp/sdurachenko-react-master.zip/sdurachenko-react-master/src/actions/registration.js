export const registrate = (event) => ({
  type: 'REGISTRATE',
  payload: {
    event: event
  }
});