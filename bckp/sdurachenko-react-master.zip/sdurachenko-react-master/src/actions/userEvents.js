export const addUserEvents = (event) => ({
  type: 'ADD_USER_EVENT',
  payload: {
    event: event
  }
});