export const listEvents = (events) => ({
  type: 'LIST_EVENTS',
  payload: {
    events: events
  }
});

export const addEvents = (event) => ({
  type: 'ADD_EVENT',
  payload: {
    event: event
  }
});