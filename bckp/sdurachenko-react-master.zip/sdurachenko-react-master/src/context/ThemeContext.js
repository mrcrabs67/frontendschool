import { createContext } from 'react';
import { themes } from '../components/constants/themes'

export default createContext({
  themes: themes,
  theme: themes[0],
  setTheme: (theme) => this.setState({ theme }),
});