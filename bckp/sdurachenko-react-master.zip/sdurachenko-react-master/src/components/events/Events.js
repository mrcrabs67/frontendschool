import './Events.scss'
import '../Fonts.scss'
import EventRow from './EventRow'

const Events = (props) => {

  return (
    <div id="events-container">
      {props.events.map((event) => <EventRow key={event.date} event={event} onRegistrationClick={props.onRegistrationClick}/>)}
    </div>
  );
};

export default Events;

