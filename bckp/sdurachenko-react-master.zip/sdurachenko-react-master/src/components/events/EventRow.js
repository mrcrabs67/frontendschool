import "./EventRow.scss"
import "../Fonts.scss"
import heart from "../../img/heart.svg"

const EventRow = (props) => {

  return (
    <div className="events-row">
      <div hidden className="event-id">{props.event.id}</div>
      <p className="event-date">{props.event.date}</p>
      <div className="event-description"><p><a href={'/event/' + props.event.id}>{props.event.title}</a></p><p
        className="footnote">{props.event.description}</p>
      </div>
      <p className="event-likes"><img className="like" src={heart} alt="likes"/>{props.event.countLikes}</p><p
        className="event-leading link">{props.event.names}</p>
      <div className="event-registration">
        <button className="registration-button btn" disabled={props.event.registrationDisabled} onClick={props.onRegistrationClick}>
          {props.event.registrationDisabled ? 'Регистрация Закрыта': 'Зарегистрироваться'}
        </button>
      </div>
    </div>
  );
};

export default EventRow;