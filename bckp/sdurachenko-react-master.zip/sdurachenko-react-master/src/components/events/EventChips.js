import "./EventChips.scss"
import "../Fonts.scss"
import { useState } from 'react'

const EventChips = () => {

  const [activeChip, setActiveChip] = useState('academy-chip')

  const activateChipHandler = (e) => {
    setActiveChip(e.target.id);
  }

  return (
    <div className="chips">
      <label htmlFor="academy-chip">
        <input id="academy-chip" type="radio" name="radio" checked={activeChip==='academy-chip'} onChange={activateChipHandler}/>
        <p>IT Academy</p>
      </label>
      <label htmlFor="marketing-chip">
        <input id="marketing-chip" type="radio" name="radio" checked={activeChip==='marketing-chip'} onChange={activateChipHandler}/>
        <p>Маркетинг</p>
      </label>
      <label htmlFor="others-chip">
        <input id="others-chip" type="radio" name="radio" checked={activeChip==='others-chip'} onChange={activateChipHandler}/>
        <p>Остальные</p>
      </label>
      <label htmlFor="retail-chip">
        <input id="retail-chip" type="radio" name="radio" checked={activeChip==='retail-chip'} onChange={activateChipHandler}/>
        <p>Retail</p>
      </label>
    </div>
  );
};

export default EventChips;