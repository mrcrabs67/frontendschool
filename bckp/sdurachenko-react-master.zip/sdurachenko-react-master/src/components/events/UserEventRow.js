import "./EventRow.scss"
import "../Fonts.scss"
import heart from "../../img/heart.svg"

const UserEventRow = (props) => {
  return (
    <div className="events-row">
      <div hidden className="event-id">{props.event.id}</div>
      <p className="event-date">{props.event.date}</p>
      <div className="event-description"><p><a href={'/event/' + props.event.id}>{props.event.title}</a></p><p
        className="footnote">{props.event.description}</p>
      </div>
      <p className="event-likes"><img className="like" src={heart} alt="likes"/>{props.event.countLikes}</p><p
        className="event-leading link">{props.event.names}</p>
      <p className="event-date">{props.event.place}</p>
      <p className="event-date">{props.event.comment}</p>
    </div>
  );
};

export default UserEventRow;