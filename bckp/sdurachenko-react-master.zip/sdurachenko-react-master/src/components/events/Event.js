import './Event.scss'
import '../Fonts.scss'

const Events = ({ event }) => {



  return (
    <div id="event-container">
      <p>Дата: {event.date}</p>
      <p>Заголовок: {event.title}</p>
      <p>Описание: {event.description}</p>
      <p>Количество лайков: {event.countLikes}</p>
      <p>Участники: {event.names.join(',' )}</p>
      <p>Регистрация: {event.registrationDisabled ? 'Закрыта' : 'Открыта'}</p>
    </div>
  );
};

export default Events;

