import {act, render, screen, waitFor} from "@testing-library/react"
import '@testing-library/jest-dom/extend-expect'
import reducer from '../../reducers/reducers'
import Modal from './Modal'
import { Provider } from 'react-redux'
import React from 'react'
import { hideModal, showModal } from '../../actions/modal'
import userEvent from '@testing-library/user-event'

const onRegistrationCancel = jest.fn();
const onModalSubmit = jest.fn();
const modalDefaultValues = {}

describe('Modal', () => {
  test('render hidden modal', async () => {
    renderModal();
    verifyThatModalIsHidden();
  });

  test('render modal and show it', async () => {
    await renderAndShowModal();
    verifyThatModalIsShown();
  });

  test('render modal and fill it correctly', async () => {
    await renderAndShowModal();
    verifyThatModalIsShown();

    fillFormWithValues('ruaDummyLogin');
    await clickRegistrationButton();
    await waitFor(() => expect(onModalSubmit).toHaveBeenCalled());
    expect(onModalSubmit).toHaveBeenCalledTimes(1);
  });

  test('render modal and fill it wrongly', async () => {
    await renderAndShowModal();
    verifyThatModalIsShown();

    fillFormWithValues('dummyLogin');
    await clickRegistrationButton();
    await waitFor(() => expect(onModalSubmit).not.toHaveBeenCalled());
  });

  test('render modal and close it', async () => {
    await renderAndShowModal();
    verifyThatModalIsShown();

    fillFormWithValues('dummyLogin');
    await clickCancelButton();
    await waitFor(() => expect(onRegistrationCancel).toHaveBeenCalled());
    expect(onRegistrationCancel).toHaveBeenCalledTimes(1);
  });

  const renderModal = () => {
    render(
      <Provider store={reducer}>
        <Modal onCancel={onRegistrationCancel} formData={modalDefaultValues} onModalSubmit={onModalSubmit}/>
      </Provider>
    );
  }

  const renderAndShowModal = async () => {
    render(
      <Provider store={reducer}>
        <Modal onCancel={onRegistrationCancel} formData={modalDefaultValues} onModalSubmit={onModalSubmit}/>
      </Provider>
    );
    await showModalForm();
  }

  const showModalForm = async () => {
    await act(async () => reducer.dispatch(showModal()));
  }

  const hideModalForm = async () => {
    await act(async () => reducer.dispatch(hideModal()));
  }

  const verifyThatModalIsHidden = () => {
    expect(screen.queryByTestId('registration-modal-form')).not.toBeInTheDocument();
  };

  const verifyThatModalIsShown = () => {
    expect(screen.queryByTestId('registration-modal-form')).toBeInTheDocument();
  };

  const fillFormWithValues = (login) => {
    userEvent.type(screen.getByLabelText('Кто пойдет на мероприятие'), login);
    userEvent.click(screen.getByLabelText('Онлайн'));
  }

  const clickRegistrationButton = async () => {
    await act(async () => {
      userEvent.click(screen.getByText('Зарегистрироваться'));
    });
  };

  const clickCancelButton = async () => {
    await act(async () => {
      userEvent.click(screen.getByText('Отменить'));
    });
  };

})