import "./Modal.scss"
import "../Fonts.scss"
import {ErrorMessage, Field, Form, Formik} from 'formik';
import { connect } from 'react-redux';
import * as Yup from 'yup';
import close from '../../img/close.svg'


const Modal = ({showModal, formData, onModalSubmit, onCancel}) => {

  const renderModalBackground = (showModal) => {
    return showModal && <div id="registration-modal-background" className="modal-background"/>;
  }

  const renderModal = (showModal) => {
    if(!showModal)
      return null;
    return (<Formik
        initialValues={{
          place: formData.place,
          username: formData.username,
          comment: formData.comment,
        }}
        validationSchema={Yup.object({
          place: Yup.string()
            .typeError('Выберите место проведения')
            .required('Выберите место проведения'),
          username: Yup.string()
            .typeError('Введите логин участника')
            .required('Введите логин участника')
            .matches("rua*"),
          comment: Yup.string()
            .nullable()
            .notRequired()
        })}
        onSubmit={(values, {setSubmitting}) => {
          onModalSubmit({ ...values, event: formData.event });
          setSubmitting(false);
        }}
      >
        <Form data-testid="registration-modal-form">
          <div id="registration-modal" className="modal-window">
            <button id="registration-modal-close" className="btn close" onClick={onCancel}>
              <img src={close} alt="close"/>
            </button>
            <h5 id="modal-header">Запись на мероприятие</h5>
            <p className="footnote">Выберите необходимые параметры мероприятия</p>
            <div className="event-description">
              <p>Венецианский карнавал танцев и богохульных плясок: смотрим вместе</p>
              <p className="footnote">К посещению приглашаются сотрудники 18-</p>
            </div>
            <div className="chips" role="group">
              <label className="chip-label" htmlFor="online-chip">
                <Field id="online-chip" type="radio" name="place" className="form-control input-rf" value="online"/>
                <p>Онлайн</p>
              </label>
              <label className="chip-label" htmlFor="office-chip">
                <Field id="office-chip" type="radio" name="place" className="form-control input-rf" value="office"/>
                <p>Оффлайн: офис Нагатино</p>
              </label>
              <ErrorMessage name="place" component="div" className="form-text text-danger"/>
            </div>
            <div className="input-filed">
              <label htmlFor="username">Кто пойдет на мероприятие</label>
              <Field id="username" name="username" type="text" placeholder="Логин или имя сотрудника" className="form-control input-rf" value={formData.username}/>
              <ErrorMessage name="username" component="div" className="form-text text-danger"/>
            </div>
            <div className="input-filed long-input">
              <label htmlFor="comment">Комментарий</label>
              <Field id="comment" name="comment" type="text" component="textarea" rows="2" className="form-control input-rf" value={formData.comment}/>
            </div>
            <div id="modal-buttons">
              <button id="registration" className="btn" type="submit">Зарегистрироваться</button>
              <button id="cancel" className="btn" onClick={onCancel} type="reset">Отменить</button>
            </div>
          </div>
        </Form>
      </Formik>
    );
  }

  return (
    <>
      {renderModalBackground(showModal)}
      {renderModal(showModal)}
    </>
  );
};

function mapStateToProps(state, ownProps) {
  return {
    ...ownProps,
    showModal: state.modal
  };
}

export default connect(mapStateToProps)(Modal);