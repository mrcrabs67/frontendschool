const themes = [
  {
    id: 1,
    name: 'Day',
    className: 'light-theme',
  },
  {
    id: 2,
    name: 'Night',
    className: 'dark-theme',
  },
];

export { themes };