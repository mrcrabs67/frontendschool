import './Navbar.scss';
import "./Fonts.scss";
import raifLogo from '../img/raif-logo.png';
import ava from '../img/ava.png';
import enter from '../img/enter.svg';
import reducer from '../reducers/reducers';
import cn from 'classnames';
import { logout } from '../actions/login';
import ThemeContext from '../context/ThemeContext';
import { useContext } from 'react';
import { useHistory } from 'react-router-dom'

const Navbar = () => {

  let history = useHistory();

  const themeContext = useContext(ThemeContext)
  let classNames = cn('navbar', themeContext.theme.className)

  const onExitClick = () => {
    reducer.dispatch(logout());
    history.push('/');
  }

  return (
    <header className={classNames}>
      <div id="logo">
        <img src={raifLogo} alt="logo"/>
      </div>

      <div id="profile">
        <span className="user-name">Валентин&nbsp;Костин</span>
        <img src={ava} alt="user avatar"/>
        <button className="btn"><img src={enter} alt="exit" onClick={onExitClick}/></button>
      </div>
    </header>
  );
};

export default Navbar;