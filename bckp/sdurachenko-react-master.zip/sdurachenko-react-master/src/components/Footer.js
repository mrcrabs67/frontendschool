import "./Footer.scss"
import ThemeSwitcher from './ThemeSwitcher'
import { useContext } from 'react'
import ThemeContext from '../context/ThemeContext'
import cn from 'classnames'

const Footer = () => {

  const themeContext = useContext(ThemeContext);
  let classNames = cn('footer', 'd-flex', 'align-items-center',
    'justify-content-center', themeContext.theme.className);

  return (
    <footer className={classNames}>
      <ThemeSwitcher/>
    </footer>
  );
};

export default Footer;