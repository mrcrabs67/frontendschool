import { useContext } from 'react'
import ThemeContext from '../context/ThemeContext'
import ToggleSwitch from './toggle/ToggleSwitch'
import { themes } from './constants/themes'

const ThemeSwitcher = () => {

  const themeContext = useContext(ThemeContext);

  const onToggle = () => {
    const { theme } = themeContext;
    const newTheme = themes.find(({id}) => id !== theme.id);
    themeContext.setTheme(newTheme);
  }

  return <ToggleSwitch label="Темная тема" onToggle={onToggle}/>
}

export default ThemeSwitcher;