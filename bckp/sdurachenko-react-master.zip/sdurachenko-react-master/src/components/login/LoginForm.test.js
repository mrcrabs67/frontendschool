import {act, render, screen, waitFor} from "@testing-library/react";
import '@testing-library/jest-dom/extend-expect';
import userEvent from "@testing-library/user-event";
import {LoginForm} from "./LoginForm";

const onAuthenticate = jest.fn();

describe('LoginForm', () => {
  test('render login form, fill inputs correctly and submit should submit successfully', async () => {
    renderLoginForm();
    fillFormWithValues('ruaDummyLogin', 'dummyPassword');
    await clickLoginButton();
    await waitFor(() => expect(onAuthenticate).toHaveBeenCalled());
    expect(onAuthenticate).toHaveBeenCalledTimes(1);
  });

  test('render login form, fill inputs wrongly and submit should submit failed', async () => {
    renderLoginForm();
    fillFormWithValues('dummyLogin', 'dummyPassword');
    await clickLoginButton();
    await waitFor(() => expect(onAuthenticate).not.toHaveBeenCalled());
  });

  test('render login form, not fill inputs and submit should submit failed', async () => {
    renderLoginForm();
    await clickLoginButton();
    expect(screen.getByText('Введите логин')).toBeInTheDocument();
    expect(screen.getByText('Введите пароль')).toBeInTheDocument();
    await waitFor(() => expect(onAuthenticate).not.toHaveBeenCalled());
  });

  const renderLoginForm = () => {
    render(
        <LoginForm onAuthenticate={onAuthenticate}/>
    );
  }

  const fillFormWithValues = (login, password) => {
    userEvent.type(screen.getByLabelText('Логин'), login);
    userEvent.type(screen.getByLabelText('Пароль'), password);
  }

  const clickLoginButton = async () => {
    await act(async () => {
      userEvent.click(screen.getByText('Войти'));
    });
  };
})