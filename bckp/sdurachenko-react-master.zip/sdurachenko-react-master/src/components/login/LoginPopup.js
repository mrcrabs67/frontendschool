import React from 'react'
import './LoginPopup.scss'
import { LoginForm } from './LoginForm'
import reducer from '../../reducers/reducers'
import { login } from '../../actions/login'
import { connect } from 'react-redux'
import { useHistory } from 'react-router-dom'

const LoginPopup = ({ isAuthenticated }) => {

  let history = useHistory();

  const onAuthenticate = (loginData) => {
    reducer.dispatch(login(loginData.username));
    history.push('/events');

  };

  const renderLoginPopup = () => {
    return (
      <div className="modal-rf">
        <LoginForm onAuthenticate={onAuthenticate}/>
      </div>
    );
  }

  return isAuthenticated ? null : renderLoginPopup();
}

function mapStateToProps(state, ownProps) {
  return {
    ...ownProps,
    isAuthenticated: state.user
  };
}

export default connect(mapStateToProps)(LoginPopup);