import React from "react";
import {ErrorMessage, Field, Form, Formik} from 'formik';
import * as Yup from "yup";
import './LoginForm.scss'
import keyIcon from '../../img/key.svg'

export const LoginForm = ({ onAuthenticate }) => {
 return (
    <div className="d-flex flex-column shadow rounded">
      <Formik
        initialValues={{
          username: '',
          password: ''
        }}
        validationSchema={Yup.object({
          username: Yup.string()
            .typeError('Введите логин')
            .required('Введите логин')
            .matches('rua*'),
          password: Yup.string()
            .typeError('Введите пароль')
            .required('Введите пароль')
        })}
        onSubmit={(values, { setSubmitting }) => {
          onAuthenticate(values);
          setSubmitting(false);
        }}
      >
        <Form data-testid="login-form">
          <div className="m-3">
            <div className="m-3">
              <label htmlFor="username" className="form-label">Логин</label>
              <Field id="username" name="username" type="text" className="form-control input-rf" value={undefined} />
              <ErrorMessage name="username" component="div" className="form-text text-danger" />
            </div>

            <div className="m-3">
              <label htmlFor="password" className="form-label">Пароль</label>
              <Field id="password" name="password" type="password" className="form-control input-rf" value={undefined}/>
              <ErrorMessage name="password" component="div" className="form-text text-danger" />
            </div>
          </div>

          <div className="d-flex flex-column">
            <button type="submit" className="m-3 btn btn-rf">
              <div className="d-flex flex-row">
                <img src={keyIcon} alt="keyIcon"/>
                <div className="divider-rf py-0 px-2">
                  <div className="divider-border-vertical-rf"/>
                </div>
                Войти
              </div>
            </button>
          </div>
        </Form>
      </Formik>
    </div>
  );
};