import '@testing-library/jest-dom/extend-expect';
import renderer from 'react-test-renderer';
import Banner from './Banner'

describe('Banner', () => {
  test('render banner', async () => {
    const banner = renderer.create(<Banner/>).toJSON();
    expect(banner).toMatchSnapshot();
  });
})