import "./Banner.scss"
import "../Fonts.scss"
import rocket from "../../img/rocket.png"

const Banner = () => {

  return (
    <div id="banner">
      <p id="nearest" className="fs-14">Ближайшее мероприятие</p>
      <h1 className="fs-40">Школа по фронтенду</h1>
      <p id="place" className="fs-14">25.05.2020 &middot; Офис в Нагатино</p>
      <button id="join" className="btn">Записаться на курс</button>
      <img id="rocket" src={rocket} alt="rocket"/>
    </div>
  );
};

export default Banner;