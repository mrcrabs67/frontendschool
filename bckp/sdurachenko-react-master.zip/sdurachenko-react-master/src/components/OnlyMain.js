import "./Main.scss"
import { useContext, Children } from 'react'
import ThemeContext from '../context/ThemeContext'
import cn from 'classnames'

const OnlyMain = (props) => {

  const themeContext = useContext(ThemeContext);
  let classNames = cn(themeContext.theme.className);

  return (
    <main className={classNames}>
      {Children.only(props.children)}
    </main>
  );
};

export default OnlyMain;