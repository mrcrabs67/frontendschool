import "./Main.scss"
import { useContext } from 'react'
import ThemeContext from '../context/ThemeContext'
import cn from 'classnames'

const Main = (props) => {

  const themeContext = useContext(ThemeContext);
  let classNames = cn(themeContext.theme.className);

  return (
    <main className={classNames}>
      {props.children}
    </main>
  );
};

export default Main;