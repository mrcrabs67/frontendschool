const reducer = (state = [], action) => {
    switch (action.type) {
      case 'ADD_USER_EVENT':
        const isEventExist = state.find(({id}) => id === action.payload.event.id) !== undefined;
        return isEventExist ? state : [...state, action.payload.event];
      default:
        return state;
    }
};

export default reducer;

