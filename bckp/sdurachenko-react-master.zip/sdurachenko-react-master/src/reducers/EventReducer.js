const reducer = (state = [], action) => {
    switch (action.type) {
      case 'LIST_EVENTS':
        return action.payload.events;
      case 'ADD_EVENT':
        return [...state, action.payload.event];
      default:
        return state;
    }
};

export default reducer;

