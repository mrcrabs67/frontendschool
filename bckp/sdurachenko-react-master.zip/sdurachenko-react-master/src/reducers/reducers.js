import { applyMiddleware, combineReducers, createStore } from 'redux'
import ModalReducer from './ModalReducer'
import LoginReducer from './LoginReducer'
import ModalLogger from '../middlewares/ModalLogger'
import EventReducer from './EventReducer'
import UserEventsReducer from './UserEventsReducer'


const reducers = combineReducers({
  modal:   ModalReducer,
  user: LoginReducer,
  events: EventReducer,
  userEvents: UserEventsReducer,
});

const persistedState = localStorage.getItem('reduxState') ?
  JSON.parse(localStorage.getItem('reduxState')):
  {}

const store = createStore(
  reducers,
  persistedState,
  applyMiddleware(ModalLogger)
);

store.subscribe(() => {
  localStorage.setItem('reduxState', JSON.stringify(store.getState()));
})

export default store;