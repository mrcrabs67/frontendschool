import React from 'react'
import Navbar from './components/Navbar'
import Footer from './components/Footer'
import reducer from './reducers/reducers'
import LoginPopup from './components/login/LoginPopup'
import ThemeContext from './context/ThemeContext'
import { Provider } from 'react-redux'
import { themes } from './components/constants/themes'
import { Route, Switch } from 'react-router-dom'
import EventsPage from './pages/EventsPage'
import EventPage from './pages/EventPage'
import UserEventsPage from './pages/UserEventsPage'
import ErrorBoundary from './components/ErrorBoundary'

export default class App extends React.Component {

  constructor(props) {
    super(props);
    this.state = { theme: themes[0] };
  }

  setTheme = (theme) => {
    this.setState({ theme });
  }

  render() {
    const { theme } = this.state;
    return (
      <div className="component-app">
        <ErrorBoundary>
          <ThemeContext.Provider value={{ theme, setTheme: this.setTheme, themes }}>
            <Navbar/>
            <Provider store={reducer}>
              <Switch>
                <Route exact path="/" component={LoginPopup}/>
                <Route exact path="/events" component={EventsPage}/>
                <Route exact path="/user/events" component={UserEventsPage}/>
                <Route exact path="/event/:id" component={EventPage}/>
              </Switch>
            </Provider>
            <Footer/>
          </ThemeContext.Provider>
        </ErrorBoundary>
      </div>
    );
  }
}