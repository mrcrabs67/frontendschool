import iconLike from '../img/like.svg';
import { popupOpen, popupClose, addEventPopup } from '../js/popup.js';

class RowData {
    constructor(object) {
        this.date = object.date;
        this.info = [object.title, object.description];
        this.like = object.countLikes;
        this.speakers = object.names;
        this.btn = object.registrationDisabled;
    }   
};

const tdRender = (name, value) => {
    const td = document.createElement('td');
    td.classList.add(`event__${name}`);
    let html = ``;
    switch (name) {
        case 'info':
            html = `<a class="event__title href="#">${value[0]}</a>
                    <p class = "event__descr">${value[1]}</p>`;
            break;
        case 'like':
            const img = new Image();
            img.src = iconLike;
            img.alt = 'Поставить лайк';
            html = `<div class='event__like-wrap'>
                    ${img.outerHTML}
                    <span>${value}</span>
                    </div>`;
            break;
        case 'speakers':
            html = "";
            for (const val in value) {
                html = `${html}<p>${value[val]}</p>`;
            }
            break;
        case 'btn':
            let classBtn ="event__reg-btn btn-reset open";
            let classText = "Зарегистрироваться";
            if(!value){
                classBtn ="event__reg-btn btn-reset close";
                classText = "Регистрация&nbsp;закрыта";
            }
            html = `<button class="${classBtn}">${classText}</button>`;
            break;
        default:
            html = value;
            break;  
    }
    td.insertAdjacentHTML('beforeend', html);
    return td;
}

export const renderEvents = (data) => {
  const allEventSection = document.getElementsByClassName('all-events');
  const table = document.createElement('table');
  table.classList.add('all-events__table', 'event');
  const length = data.length;
  for (let i = 1; i <= length; i+= 1) {
    const tr = document.createElement('tr');
    tr.classList.add('event__item');
    const rowSet = new RowData(data[i-1]);
    const rowSetArr = Object.entries(rowSet);
    for (const [name, value] of rowSetArr) {
        const html = tdRender(name, value);
        tr.insertAdjacentElement('beforeend', html);
    }
     table.appendChild(tr);
    }
  allEventSection[0].appendChild(table);
  const btnOpen = document.querySelectorAll('button.open');
  btnOpen.forEach((btn) => btn.addEventListener('click', popupOpen));
  window.addEventListener('keydown', popupClose);

  addEventPopup();
  
};