import '../index.html';
import '../css/normalize.css';
import '../css/style.css';
import '../css/media.css';
import { renderEvents } from '../js/render.js';
fetch('http://localhost:3000/data')
  .then((response) => response.json())
  .then((data) => {
    data.sort((prev, next) => {
      const prevDate = new Date(prev.date);
      const nextDate = new Date(next.date);
      if (prevDate < nextDate) return -1;
      else if (prevDate > nextDate) return 1;
      else return 0;
    });
    renderEvents(data);
  });
