import {getRecords, createRecord, updateRecord} from './api.js';

const form = document.querySelector('.modal');
const btnReset = form.querySelectorAll('.modal__close');
const btnSubmit = form.querySelector('[type=submit]');

export const popupOpen = (e) => {
  const parentRow = e.target.parentNode.parentNode;
  parentRow.classList.add('selected');
  const eventTitle = parentRow.querySelector('.event__title').textContent;
  const eventDescr = parentRow.querySelector('.event__descr').textContent;
  const formTitle = form.querySelector('.modal__event-title');
  const formDescr = form.querySelector('.modal__event-descr');
  formTitle.textContent = eventTitle;
  formDescr.textContent = eventDescr;
  form.classList.add('active');
  form.elements.user.focus();
  form.scrollIntoView({block: "start", behavior: "smooth"});
  document.body.classList.add('bck-gray');
};

export const popupClose = (e) => {
  if (
    (e.type === 'keydown' && e.keyCode === 27) || e.type === 'click' ) {
    form.classList.remove('active');
    document.body.classList.remove('bck-gray');
    const parentEvent = document.querySelector('tr.selected');
    parentEvent.classList.remove('selected');
  }
};

export const popupCloseLite = () => {
    const popup = document.querySelector('.modal');
    popup.classList.remove('active');
    document.body.classList.remove('bck-gray');
    const parentEvent = document.querySelector('tr.selected');
    parentEvent.classList.remove('selected');
}

export const submitRecord = (e) => {
    const formData = e.target;
    const parentEvent = document.querySelector('tr.selected');
    const regData = {
        user: formData.elements.user.value,
        comment: formData.elements.comment.value,
        event: parentEvent.querySelector('.event__title').textContent,
        date: parentEvent.querySelector('.event__date').textContent,
    };
    getRecords()
    .then((response) => {
        const recExist = response.find((item) => item.user === regData.user && item.event === regData.event && item.date === regData.date);
        if (recExist !== undefined) { //если запись сущетсвует, то получаем id и обновляем
            console.log('запись существует');
            console.log(recExist._id);
            updateRecord(recExist._id, regData);
        }
        else {
        //иначе, создаем новую
        createRecord(regData);
     }
    })
    .then(() => {
        popupCloseLite();
        alert('Вы успешно зарегистрированы на мероприятие');
    })
    .catch(() => {
        popupCloseLite();
        alert('Ошибка при регистрации! Попробуйте позднее');
    });
}

export const addEventPopup = () => {
    btnReset.forEach((btn) => btn.addEventListener('click', popupClose));
    form.addEventListener('submit', (event) => {
        event.preventDefault();
        submitRecord(event);
    });
}