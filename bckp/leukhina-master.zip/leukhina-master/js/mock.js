/* Заглушки */

const randomBoolean = () => {
    if (Math.random() >= 0.5) 
        return false
    else
        return true;
}

const randomValue = (min, max) => {
    return Math.floor(Math.random() * (max - min + 1)) + Math.ceil(min);
}

const randomDate = () => {
    const minDate = Date.now();
    const maxDate = minDate + (24*3600* 1000*90);
    const newDate = new Date(randomValue(minDate, maxDate));
    return newDate;
}

const randomString = () => {
    const items = [
        'Веницианский карнавал танцев и богохульных плясок: смотрим вместе',
        'Солнцестоим вместе или как провести выходные продуктивно',
        'Бредовые макеты и как с ним работать: спитч о проблемах друзей-фронтендеров',
        'Аукцион: лоснящаяся шкура золотого дракона Монина. Что скрывается в повале офиса Нагатино?',
        'К посещению приглашаются сотрудники 18-',
        'Если вы любите солнце и стоять - то данный курс вам очень подойдет. Мы вместе будем стоять и смотреть на солнце. Чистый кайф.',
        'Что делать если в дизайне, который вам отправил дизайнер написаны бредовые тексты? Посмеяться?! Это что для вас шуточки?!',
        'Если у вас еще осталась зарплата - приходите, мы будем рады ее забрать'
    ];
    const maxVal = items.length - 1;
    return items[randomValue(0, maxVal)];
}

const randomName = () => {
    const names = ['Петр', 'Василий', 'Николай', 'Олег', 'Павел'];
    const surnames = ['Иванов', 'Петров', 'Гагарин', 'Сюткин', 'Грозный'];
    const maxNames = names.length - 1;
    const maxSurnames = surnames.length -1;
    return `${names[randomValue(0, maxNames)]} ${surnames[randomValue(0, maxSurnames)]}`;
}

const randomObject = () => {
    const event = {
        date: randomDate(),
        title: randomString(),
        description: randomString(),
        countLikes: randomValue(0, 1000),
        names: randomName(),
        registrationDisabled: randomBoolean(),
    };
    return event;
}

export const randomEvents = (count) => {
    const events = [];
    for (let i = 1; i <= count; i += 1) {
        events.push(randomObject());
    }
    return events;
};