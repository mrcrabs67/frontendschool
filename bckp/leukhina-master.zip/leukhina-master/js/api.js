const baseUrl = 'https://crudcrud.com/api/50a36534854e41299e2c3abdcfa44759/registration';

export const getRecords = () =>
    fetch(baseUrl)
        .then(response => response.json());

export const createRecord = data =>
    fetch(baseUrl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json;charset=utf-8'
        },
        body: JSON.stringify(data)
    });

export const updateRecord = (recordId, data) =>
    fetch(`${baseUrl}/${recordId}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json;charset=utf-8'
        },
        body: JSON.stringify(data)
    });

export const deleteRecord = (recordId) =>
    fetch(`${baseUrl}/${recordId}`, {
        method: 'DELETE',
    });