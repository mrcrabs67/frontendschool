const express = require('express');
const data = require('../data/data');
const router = express.Router();

router.get('/', function(req, res, next) {
  res.set('Access-Control-Allow-Origin', '*');
  res.json(data);
});

module.exports = router;
