export const validError = "Логин должен быть в формате rua";
export const validName = new RegExp("(^rua)[a-z0-9]{4,5}$");
