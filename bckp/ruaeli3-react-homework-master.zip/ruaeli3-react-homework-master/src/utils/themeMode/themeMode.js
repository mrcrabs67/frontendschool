import React, { useEffect } from "react";
import { ThemeContext } from "./themeContext";

const ThemeMode = ({ children }) => {
  const [theme, setTheme] = React.useState({ dataTheme: "dark" });

  useEffect(() => {
    document.documentElement.dataset.theme = theme.dataTheme;
  }, [theme]);

  return (
    <ThemeContext.Provider value={{ theme, setTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};

export default ThemeMode;
