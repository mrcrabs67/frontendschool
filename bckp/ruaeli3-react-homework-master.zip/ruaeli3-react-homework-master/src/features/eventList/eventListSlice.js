import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";

export const getEventList = createAsyncThunk(
  "eventList/getEventList",
  async (_, thunkAPI) => {
    try {
      return await fetch("/mock/list.json").then((res) => res.json());
    } catch (err) {
      console.log(err);
      thunkAPI.rejectWithValue(err);
    }
  }
);

const initialState = {
  list: [],
  filtered: [],
  showModal: false,
  modalData: {},
  isLoading: false,
};
const eventListSlice = createSlice({
  name: "eventList",
  initialState: initialState,
  reducers: {
    incrementLike: ({ filtered, list }, { payload }) => {
      filtered[payload.id].countLikes = filtered[payload.id].countLikes + 1;
      filtered[payload.id].isLike = true;
      list[payload.id].isLike = true;
    },
    decrementLike: ({ filtered, list }, { payload }) => {
      filtered[payload.id].countLikes = filtered[payload.id].countLikes - 1;
      filtered[payload.id].isLike = false;
      list[payload.id].isLike = false;
    },
    filterById: (state, { payload }) => {
      state.filtered = state.list.filter(({ id }) => id >= payload.id);
      console.log(payload);
    },
    addToModalStore: (state, { payload }) => {
      state.modalData = payload;
      state.showModal = true;
    },
    showModal: (state) => {
      state.showModal = true;
    },
    defaultModalStore: (state, { payload }) => {
      state.modalData = state.list[0];
      state.showModal = false;
    },
  },

  extraReducers: (builder) => {
    builder.addCase(getEventList.pending, (state) => {
      state.isLoading = true;
    });
    builder.addCase(getEventList.fulfilled, (state, { payload }) => {
      state.list = payload;
      state.filtered = payload;
      state.isLoading = false;
    });
    builder.addCase(getEventList.rejected, (state) => {
      state.isLoading = false;
    });
  },
});

export default eventListSlice.reducer;
export const {
  incrementLike,
  decrementLike,
  filterById,
  addToModalStore,
  defaultModalStore,
  showModal,
} = eventListSlice.actions;
