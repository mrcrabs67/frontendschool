import { configureStore } from "@reduxjs/toolkit";
import getEventList from "./eventList/eventListSlice";
import logger from "redux-logger";

export const store = configureStore({
  reducer: {
    eventList: getEventList,
  },
  middleware: (getDefaultMiddleware) => getDefaultMiddleware().concat(logger),
});
