import "./App.css";
import React from "react";
import { connect } from "react-redux";

import Header from "./components/Header/Header";
import Banner from "./components/Banner/Banner";
import Events from "./components/Events/Events";
import ModalWindow from "./ModalWindow/ModalWindow";

import BodyContent from "./components/BodyContent/BodyContent";
import ThemeMode from "./utils/themeMode/themeMode";

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return (
      <ThemeMode>
        <BodyContent>
          <Header />
          <Banner />
          <Events />
          {this.props.modalShow && <ModalWindow />}
        </BodyContent>
      </ThemeMode>
    );
  }
}
function mapStateToProps(state) {
  return {
    modalShow: state.eventList.showModal,
  };
}

export default connect(mapStateToProps)(App);
