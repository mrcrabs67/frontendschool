import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { defaultModalStore } from "../features/eventList/eventListSlice";
import { useState } from "react";
import { validName, validError } from "../utils/reg";

const ModalWindow = () => {
  const meetingType = [
    {
      placeMeeting: "Онлайн",
      id: 0,
    },
    {
      placeMeeting: "Оффлайн: офис Нагатино",
      id: 1,
    },
  ];
  const [student, setStudent] = useState({
    login: "",
    comment: "",
    courseId: 0,
    validName: true,
    placeMeeting: meetingType[0].placeMeeting,
  });

  const meetingHandler = (place) => {
    setStudent({ ...student, placeMeeting: place });
  };

  const [active, setActive] = useState({
    id: meetingType[0].id,
    placeMeeting: meetingType[0].placeMeeting,
  });

  const onChangeInput = (e) => {
    if (e.target.name === "name") {
      setStudent({
        ...student,
        login: e.target.value,
        validName: validateName(e.target.value),
      });
    }
    if (e.target.name === "comment")
      setStudent({ ...student, comment: e.target.value });
  };

  const registerStudent = () => {
    if (student.validName) {
      if (!validateName(student.login)) {
        setStudent({ ...student, validLogin: false });
      } else {
        // dispatch(register(student));
        // closeModal();
      }
    }
  };

  const validateName = (value) => {
    return validName.test(value);
  };

  const handleClick = (item) => {
    const { id, placeMeeting } = item;
    console.log(item);
    setActive({ id: id, placeMeeting: placeMeeting });
    meetingHandler(placeMeeting);
    // setStudent();
  };

  const { modalData } = useSelector(({ eventList }) => eventList);

  const dispatch = useDispatch();

  const handlerModalHide = (e) => {
    e.preventDefault();
    if (e.target.classList.contains("closeModal")) {
      dispatch(defaultModalStore());
    }
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" || e.key === "Esc") {
        dispatch(defaultModalStore());
      }
    });
  };

  return (
    <div onClick={handlerModalHide} className="modal-wrapper" id="modal">
      <div id="modal-window" className="modal-window">
        <div className="modal-closebutton closeModal" />
        <h2 className="modal-headertext">Запись на мероприятие</h2>
        <div className="modal-subtext">
          Выберите необходимые параметры мероприятия
        </div>
        <div className="modal-description">
          <div className="modal-description-header">{modalData.title}</div>
          <div className="modal-description-subText">
            {modalData.description}
          </div>
        </div>
        <ul className="modal-tabs list-buttons">
          {meetingType.map((item) => (
            <li
              id={item.id}
              key={item.id}
              // active={active}
              onClick={() => handleClick(item)}
              className={`modal-tabs-item list-buttons-item ${
                active.id === item.id ? "list-buttons-item__active" : ""
              } `}
            >
              {item.placeMeeting}
            </li>
          ))}
        </ul>
        <form className="modal-form" action="#">
          <label className="modal-form-label-name" htmlFor="name">
            Кто пойдет на мероприятие
          </label>
          <input
            onChange={onChangeInput}
            value={student.login}
            id="name"
            name="name"
            className="modal-form-name"
            type="text"
            placeholder="Логин или имя сотрудника"
          />
          {!student.validName && (
            <div style={{ color: "red" }}>{validError}</div>
          )}
          <label className="modal-form-label-comment" htmlFor="comment">
            Комментарий
          </label>
          <textarea
            onChange={onChangeInput}
            value={student.comment}
            className="modal-form-comment"
            name="comment"
            id="comment"
            cols="30"
            rows="4"
            placeholder="Дополнительная информация"
          />
          <div className="modal-buttons">
            <button
              onClick={registerStudent}
              type="submit"
              className="modal-submit event-schedule-btn"
            >
              Зарегистрироваться
            </button>
            <button className="modal-cancel event-schedule-btn closeModal">
              Отменить
            </button>
          </div>
        </form>
      </div>
      <div className="overlay" />
    </div>
  );
};

export default ModalWindow;
