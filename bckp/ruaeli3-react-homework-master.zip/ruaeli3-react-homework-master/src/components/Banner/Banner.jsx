import React from "react";
import IMG_SALY1 from "../../img/Saly-1.png";
import IMG_SALY2 from "../../img/Saly-1 (1).png";
import { useDispatch } from "react-redux";
import { showModal } from "../../features/eventList/eventListSlice";

const Banner = () => {
  const dispatch = useDispatch();

  return (
    <section className="agenda">
      <div className="agenda-banner">
        <p className="agenda-smalltext">Ближайшее мероприятие</p>
        <h1 className="agenda-name">Школа по фронтенду</h1>
        <div className="agenda-location">25.05.2020 · Офис в Нагатино</div>
        <button
          onClick={() => dispatch(showModal())}
          className="agenda-takeofferbtn "
        >
          Записаться на курс
        </button>
        <img src={IMG_SALY1} alt="Скачет на облаке" className="agenda-img" />
        <img src={IMG_SALY2} alt="Облако" className="agenda-img-2" />
      </div>
    </section>
  );
};

export default Banner;
