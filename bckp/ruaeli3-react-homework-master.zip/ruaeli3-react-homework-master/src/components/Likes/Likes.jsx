import React, { useState } from "react";
import { useDispatch } from "react-redux";
import {
  decrementLike,
  incrementLike,
} from "../../features/eventList/eventListSlice";

const Likes = ({ countLikes, id, isLike }) => {
  // const [fill, setFill] = useState(false);
  const dispatch = useDispatch();

  return (
    <>
      <div
        onClick={() => {
          !isLike && dispatch(incrementLike({ id }));
          isLike && dispatch(decrementLike({ id }));
          // setFill(!fill);
        }}
        className="event-schedule-like-heart"
        style={
          isLike
            ? { backgroundColor: "red" }
            : { backgroundColor: "transparent" }
        }
      />
      <div className="event-schedule-like-counter">{countLikes}</div>
    </>
  );
};

export default Likes;
