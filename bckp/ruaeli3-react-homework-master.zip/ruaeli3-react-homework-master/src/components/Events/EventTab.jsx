import React from "react";
import { useDispatch } from "react-redux";
import { filterById } from "../../features/eventList/eventListSlice";

const EventTab = ({ props, active, handle }) => {
  const dispatch = useDispatch();

  const id = props.id;
  return (
    <li
      id={props.id}
      onClick={() => {
        handle(props.id);
        dispatch(filterById({ id }));
      }}
      className={`event-list-item list-buttons-item ${
        active === props.id ? "list-buttons-item__active" : ""
      }`}
    >
      {props.name}
    </li>
  );
};

export default EventTab;
