import React, { useState } from "react";
import EventTab from "./EventTab";

const EventTabs = () => {
  const list = [
    {
      name: "IT Academy",
      id: 0,
    },
    {
      name: "Маркетинг",
      id: 1,
    },
    {
      name: "Retail",
      id: 2,
    },
    {
      name: "Остальные",
      id: 3,
    },
  ];

  const [active, setActive] = useState(0);

  const handleClick = (id) => {
    setActive(id);
  };
  // console.log(active);

  return (
    <ul className="event-list list-buttons">
      {list.map((item) => (
        <EventTab
          handle={handleClick}
          active={active}
          key={item.id}
          props={item}
        />
      ))}
    </ul>
  );
};

export default EventTabs;
