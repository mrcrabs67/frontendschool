import React from "react";
import Likes from "../Likes/Likes";
import { useDispatch } from "react-redux";
import { addToModalStore } from "../../features/eventList/eventListSlice";

const Event = ({ data, id }) => {
  const normallDate = data.date.split("-").reverse().join(".");

  const dispatch = useDispatch();

  const addModalData = (e) => {
    if (
      !data.registrationDisabled &&
      (e.target.classList.contains("event-schedule-btn") ||
        e.target.classList.contains("agenda-takeofferbtn")) &&
      !e.target.classList.contains("event-schedule-btn__disabled") &&
      !e.target.classList.contains("modal-cancel")
    ) {
      dispatch(addToModalStore(data));
    }
  };
  return (
    <div onClick={addModalData} className="event-schedule">
      <div className="event-schedule-date">{normallDate}</div>
      <div className="event-schedule-textblock">
        <h3 className="event-schedule-header">{data.title}</h3>
        <div className="event-schedule-text">{data.description}</div>
      </div>
      <div className="event-schedule-like">
        <Likes id={id} countLikes={data.countLikes} isLike={data.isLike} />
      </div>
      <div className="event-schedule-name">
        {data.names.map((name, i) => (
          <span key={i}>{name}</span>
        ))}
      </div>
      <div className="event-buttons">
        <button
          id={id}
          className={`event-schedule-btn ${
            data.registrationDisabled ? "event-schedule-btn__disabled" : ""
          }`}
        >
          {data.registrationDisabled
            ? "Регистрация закрыта"
            : "Зарегистрироваться"}
        </button>
      </div>
    </div>
  );
};

export default Event;
