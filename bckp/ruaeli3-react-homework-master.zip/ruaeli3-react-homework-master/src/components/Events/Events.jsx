import React, { useEffect } from "react";
import EventTabs from "./EventTabs";
import EventsList from "./EventsList";
import { useDispatch } from "react-redux";
import { getEventList } from "../../features/eventList/eventListSlice";

const Events = ({ showModal }) => {
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(getEventList());
  }, [dispatch]);

  return (
    <section onClick={showModal} className="event">
      <div className="wrapper">
        <h2 className="event-header">Все мероприятия</h2>
        <EventTabs />
        <EventsList />
      </div>
    </section>
  );
};

export default Events;
