import React from "react";
import Event from "./Event";

import { useSelector } from "react-redux";

const EventsList = () => {
  const { filtered, isLoading } = useSelector(({ eventList }) => eventList);

  return !filtered || isLoading ? (
    <div>LOADING...</div>
  ) : (
    <div className="events">
      {filtered.map((item, i) => (
        <Event key={i} id={i} data={item} />
      ))}
    </div>
  );
};

export default EventsList;
