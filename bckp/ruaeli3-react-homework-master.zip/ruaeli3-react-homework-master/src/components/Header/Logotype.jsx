import React from "react";
import IMG_LOGO from "../../img/Logotype.svg";
import ThemeSwitcher from "../ThemeSwitcher/ThemeSwitcher";

const Logotype = () => {
  return (
    <div className="header-leftside">
      <img src={IMG_LOGO} alt="" className="header-logo" />
      <ThemeSwitcher />
    </div>
  );
};

export default Logotype;
