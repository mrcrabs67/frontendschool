import React from 'react';
import IMG_EXIT from "../../img/exit.svg";

const ExitButton = () => {
    return (
        <button className="header-exitbutton" style={{ backgroundImage: `url(${IMG_EXIT})` }}></button>
    );
};

export default ExitButton;