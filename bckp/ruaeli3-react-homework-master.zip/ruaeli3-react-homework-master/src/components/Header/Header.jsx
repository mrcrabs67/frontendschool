import React from 'react';

import User from "./User";
import Logotype from "./Logotype";


const Header = () => {
    return (
        <header className="header">
            <Logotype/>
            <User/>
        </header>
    );
};

export default Header;