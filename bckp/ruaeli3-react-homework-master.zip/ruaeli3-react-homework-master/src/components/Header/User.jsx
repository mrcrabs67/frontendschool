import React from 'react';
import ExitButton from "./ExitButton";
import IMG_AVATAR from "../../img/aaron-mello-528795-unsplash.svg";

const User = () => {
    return (
        <div className="header-rightside">
            <p className="header-username">Валентин Костин</p>
            <img className="header-userphoto" src={IMG_AVATAR} alt="User Photo" />
            <ExitButton/>
        </div>
    );
};

export default User;