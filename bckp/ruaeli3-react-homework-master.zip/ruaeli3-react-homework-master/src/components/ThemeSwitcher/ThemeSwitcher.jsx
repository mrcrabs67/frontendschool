import React, { useContext } from "react";
import { ThemeContext } from "../../utils/themeMode/themeContext";

const ThemeSwitcher = () => {
  const { theme, setTheme } = useContext(ThemeContext);

  const themeModeSwitch = () => {
    if (theme.dataTheme === "light") setTheme({ dataTheme: "dark" });
    else setTheme({ dataTheme: "light" });
  };

  return (
    <label for="">
      <input type="checkbox" onChange={themeModeSwitch} />
      Switch Theme
    </label>
  );
};

export default ThemeSwitcher;
