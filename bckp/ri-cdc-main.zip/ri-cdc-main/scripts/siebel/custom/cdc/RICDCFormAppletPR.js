//Regenerate using:https://duncanford.github.io/prpm-code-generator/?prpm=PR&object=DesktopForm&name=RICDCFormApplet&userprops=&comments=Yes&logging=No
if (typeof (SiebelAppFacade.RICDCFormAppletPR) === "undefined") {

    SiebelJS.Namespace("SiebelAppFacade.RICDCFormAppletPR");
    define("siebel/custom/cdc/RICDCFormAppletPR", ["siebel/phyrenderer"],
        function () {
            SiebelAppFacade.RICDCFormAppletPR = (function () {

                    function RICDCFormAppletPR(pm) {
                        SiebelAppFacade.RICDCFormAppletPR.superclass.constructor.apply(this, arguments);
                    }

                    SiebelJS.Extend(RICDCFormAppletPR, SiebelAppFacade.PhysicalRenderer);

                    RICDCFormAppletPR.prototype.Init = function () {
                        // Init is called each time the object is initialised.
                        // Add code here that should happen before default processing
                        SiebelAppFacade.RICDCFormAppletPR.superclass.Init.apply(this, arguments);
                        // Add code here that should happen after default processing
                        //console.log('RICDCFormAppletPR');
                        const PR = this;
                        const View = SiebelApp.S_App.GetActiveView();
                        //const Applet = View.GetActiveApplet();
                        const PM = PR.GetPM();

                        const AppletClass = PM.Get("AppletClass");
                        const AppletId = PM.Get("GetFullId");

                        if (AppletClass && AppletClass.length > 0) {
                            if (AppletId) {
                                let elId = document.getElementById(AppletId);
                                elId.classList.add(AppletClass);
                            }
                        }

                    }

                    RICDCFormAppletPR.prototype.ShowUI = function () {
                        // ShowUI is called when the object is initially laid out.
                        // Add code here that should happen before default processing
                        SiebelAppFacade.RICDCFormAppletPR.superclass.ShowUI.apply(this, arguments);
                        // Add code here that should happen after default processing
                    }

                    RICDCFormAppletPR.prototype.BindData = function (bRefresh) {
                        // BindData is called each time the data set changes.
                        // This is where you'll bind that data to user interface elements you might have created in ShowUI
                        // Add code here that should happen before default processing
                        SiebelAppFacade.RICDCFormAppletPR.superclass.BindData.apply(this, arguments);
                        // Add code here that should happen after default processing
                    }

                    RICDCFormAppletPR.prototype.BindEvents = function () {
                        // BindEvents is where we add UI event processing.
                        // Add code here that should happen before default processing
                        SiebelAppFacade.RICDCFormAppletPR.superclass.BindEvents.apply(this, arguments);
                        // Add code here that should happen after default processing
                    }

                    RICDCFormAppletPR.prototype.EndLife = function () {
                        // EndLife is where we perform any required cleanup.
                        // Add code here that should happen before default processing
                        SiebelAppFacade.RICDCFormAppletPR.superclass.EndLife.apply(this, arguments);
                        // Add code here that should happen after default processing
                    }

                    return RICDCFormAppletPR;
                }()
            );
            return "SiebelAppFacade.RICDCFormAppletPR";
        })
}
   
   