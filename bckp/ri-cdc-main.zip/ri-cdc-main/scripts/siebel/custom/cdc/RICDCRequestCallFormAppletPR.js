//Regenerate using:https://duncanford.github.io/prpm-code-generator/?prpm=PR&object=DesktopForm&name=RICDCRequestCallFormApplet&userprops=&comments=Yes&logging=No
if (typeof(SiebelAppFacade.RICDCRequestCallFormAppletPR) === "undefined") {
 SiebelJS.Namespace("SiebelAppFacade.RICDCRequestCallFormAppletPR");
 define("siebel/custom/cdc/RICDCRequestCallFormAppletPR", ["siebel/phyrenderer"],
  function () {
   SiebelAppFacade.RICDCRequestCallFormAppletPR = (function () {
    function RICDCRequestCallFormAppletPR(pm) {
     SiebelAppFacade.RICDCRequestCallFormAppletPR.superclass.constructor.apply(this, arguments);
    }
    SiebelJS.Extend(RICDCRequestCallFormAppletPR, SiebelAppFacade.PhysicalRenderer);
    RICDCRequestCallFormAppletPR.prototype.Init = function () {
     // Init is called each time the object is initialised.
     // Add code here that should happen before default processing
     SiebelAppFacade.RICDCRequestCallFormAppletPR.superclass.Init.apply(this, arguments);
     // Add code here that should happen after default processing
    }
    RICDCRequestCallFormAppletPR.prototype.ShowUI = function () {
     // ShowUI is called when the object is initially laid out.
     // Add code here that should happen before default processing
     SiebelAppFacade.RICDCRequestCallFormAppletPR.superclass.ShowUI.apply(this, arguments);
     // Add code here that should happen after default processing
     console.log("RICDCRequestCallFormAppletPR");
    }
    RICDCRequestCallFormAppletPR.prototype.BindData = function (bRefresh) {
     // BindData is called each time the data set changes.
     // This is where you'll bind that data to user interface elements you might have created in ShowUI
     // Add code here that should happen before default processing
     SiebelAppFacade.RICDCRequestCallFormAppletPR.superclass.BindData.apply(this, arguments);
     // Add code here that should happen after default processing
    }
    RICDCRequestCallFormAppletPR.prototype.BindEvents = function () {
     // BindEvents is where we add UI event processing.
     // Add code here that should happen before default processing
     SiebelAppFacade.RICDCRequestCallFormAppletPR.superclass.BindEvents.apply(this, arguments);
     // Add code here that should happen after default processing
    }
    RICDCRequestCallFormAppletPR.prototype.EndLife = function () {
     // EndLife is where we perform any required cleanup.
     // Add code here that should happen before default processing
     SiebelAppFacade.RICDCRequestCallFormAppletPR.superclass.EndLife.apply(this, arguments);
     // Add code here that should happen after default processing
    }
    return RICDCRequestCallFormAppletPR;
   }()
  );
  return "SiebelAppFacade.RICDCRequestCallFormAppletPR";
 })
}