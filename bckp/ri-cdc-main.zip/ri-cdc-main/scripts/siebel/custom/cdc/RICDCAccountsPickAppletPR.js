//Regenerate using:https://duncanford.github.io/prpm-code-generator/?prpm=PR&object=DesktopList&name=RICDCAccountsPickApplet&userprops=&comments=Yes&logging=No
if (typeof(SiebelAppFacade.RICDCAccountsPickAppletPR) === "undefined") {

 SiebelJS.Namespace("SiebelAppFacade.RICDCAccountsPickAppletPR");
 define("siebel/custom/cdc/RICDCAccountsPickAppletPR", ['siebel/custom/cdc/RICDCListAppletPR',//"siebel/jqgridrenderer",
 'siebel/custom/cdc/cdc-utils',
 'siebel/custom/cdc/dist/app',
 'siebel/custom/cdc/dist/cdc-vendor'
 ],
  function () {
		let DataManager = SiebelAppFacade.DMPL;

		if (SiebelAppFacade.DMPL) {
			DataManager = SiebelAppFacade.DMPL;
		} else {
			DataManager = SiebelAppFacade.Events();
		}

   SiebelAppFacade.RICDCAccountsPickAppletPR = (function () {

    function RICDCAccountsPickAppletPR(pm) {
     SiebelAppFacade.RICDCAccountsPickAppletPR.superclass.constructor.apply(this, arguments);
    }

    SiebelJS.Extend(RICDCAccountsPickAppletPR, SiebelAppFacade.RICDCListAppletPR);

    RICDCAccountsPickAppletPR.prototype.Init = function () {
     // Init is called each time the object is initialised.
     // Add code here that should happen before default processing
     SiebelAppFacade.RICDCAccountsPickAppletPR.superclass.Init.apply(this, arguments);
     // Add code here that should happen after default processing
    }

    RICDCAccountsPickAppletPR.prototype.ShowUI = function () {
    // ShowUI is called when the object is initially laid out.
    // Add code here that should happen before default processing
    SiebelAppFacade.RICDCAccountsPickAppletPR.superclass.ShowUI.apply(this, arguments);
	
	const PR = this;
	const View = SiebelApp.S_App.GetActiveView();
	const Applet = View.GetActiveApplet();
	const ReqFormApplet = View.GetApplet("RI CDC Request Form Applet");
	const AccDetApplet = View.GetApplet("RI CDC Request Account Details Form Applet");
	const HistApplet = View.GetApplet('RI CDC Request VBC List Applet');
	const ReqFormPM = ReqFormApplet.GetPModel();
	const AccDetPM = AccDetApplet?.GetPModel();
	const HistPM = HistApplet?.GetPModel();
	const PM = PR.GetPM();
	const BC = PM.Get("GetBusComp");
	
	const ReqFormBC = ReqFormPM.Get("GetBusComp");
	const AccDetBC = AccDetPM?.Get("GetBusComp");
	const HistBC = HistPM?.Get("GetBusComp");
	

	//$('.ui-dialog[style*="z-index: 10000"]').hide();
	//$('.ui-widget-overlay.ui-front.ui-droppable').hide();
	
	const foundCompaniesId = ReqFormBC.GetFieldValue("FoundCompaniesId");
	const initialArray = foundCompaniesId.split(';');
	const aLength = initialArray.length;
	
	console.log('initialArray = ', initialArray);
	
	const dataOrgSearch = [];
	dataOrgSearch.length = 0;
	
	if(aLength != 1){
	
		NQ(PM);
		
		initialArray.splice(aLength - 1, 1);//Удалим лишний элемент массива
		
		let sinitialArray = "";
		
		for(i = 0; i < initialArray.length; i++){
			if(i == 0){
				sinitialArray = '[Id] = '+initialArray[i];
			}
			else {
				sinitialArray = sinitialArray + ' OR '+'[Id] = '+initialArray[i];
			}
		}
		console.log('sinitialArray = ', sinitialArray);
		
		
		function InitialQuery(initialArray){
			BC.SetFieldValue("RI INN", sinitialArray);
			PM.ExecuteMethod("InvokeMethod", "ExecuteQuery");
		}
		//Предзаполненный список. Добавлю промисы для того, чтобы ждать появление кнопки OK
		const promise = new Promise((resolve, reject) => {

			const IntId = setInterval(() => {

				if(document.getElementsByClassName('siebui-ctrl-btn siebui-icon-pickrecord').length === 1)
				{
					clearInterval(IntId);
					resolve(true);
				}
			}, 700);

		});
		void promise.then((result) => {
			console.log('Появилсь кнопка OK');
			//InitialQuery(sinitialArray);

		});
		//
		
		InitialQuery(sinitialArray);
		
		///////////////// 
		//Filling the initial array with data
		
		function FillingArray(){
		const Records = PM.Get("GetRawRecordSet");
		
		for(let i = 0; i < Records.length; i ++){
			dataOrgSearch.push({
				id: Records[i]["Id"],
				orgName: Records[i]["Name"],
				inn: Records[i]["RI INN"],
				kpp: Records[i]["RI KPP"],
				cnum: Records[i]["RI External Client ID"],
			});
			if(BC.GetCurRowNum()< Records.length) {
				PM.ExecuteMethod("InvokeMethod","GotoNext");}
		 }
		}
		
		FillingArray();
	
	}
	 
	function PickRecord(id, PM, ReqFormPM, AccDetPM){
		
		const BC = PM.Get("GetBusComp");
		if(id != null) {
			BC.SetFieldValue("Name", "[Id] = "+id);
		}
		
		PM.ExecuteMethod("InvokeMethod", "ExecuteQuery");
		//console.log("find record ", PM.Get("GetRawRecordSet"));
		
		PM.ExecuteMethod("InvokeMethod","PickRecord");
		ReqFormPM.ExecuteMethod("InvokeMethod", "WriteRecord");//(?)
		
		RefreshRecord(ReqFormPM);
		if(AccDetPM){
			RefreshRecord(AccDetPM);
		}
		if(HistPM){
			RefreshHistory(HistPM,id);
		}

		
		delete PS;

	}
	function RefreshHistory(PM,id){
		const data = PM.GetRenderer().GetRequestList(1,25,"Y",id);
		PM.GetRenderer().DataManager.add('tabHistoryAppealsEvents',{
			pathEvent: 'data',
			value: data.data,
		});
		PM.GetRenderer().DataManager.add('tabHistoryAppealsEvents',{
			 pathEvent: 'totalCount',
			 value: data.totalCount, 
		});
	}
	function RefreshRecord(PM){
		PM.ExecuteMethod("InvokeMethod", "RefreshRecord");
	}
	
	/*function GetInputName(ControlName){
		return PR.GetUIWrapper(PM.Get("GetControls")[ControlName]).control.GetInputName();
	}*/
	
	function ExecuteQuery(value){
		
		let orgName = value.orgName;
		let inn = value.inn;
		let kpp = value.kpp;
		let cnum = value.cnum;
		
		//console.log('value = ', value);
		
		//const PM = PR.GetPM();
		const BC = PM.Get("GetBusComp");

		if(inn != null) {
			BC.SetFieldValue("RI INN", inn);
		}
		
		if(kpp != null) {
			BC.SetFieldValue("RI KPP", kpp);
		}
		
		if(cnum != null) {
			BC.SetFieldValue("RI External Client ID", cnum);
		}
		
		if(orgName != null) {
			BC.SetFieldValue("Name", orgName);;
		}
		
		
		PM.ExecuteMethod("InvokeMethod", "ExecuteQuery");
		
		let oQuerySet = PM.Get("GetRawRecordSet");
		//console.log('SearchResult', oQuerySet);
		
		return oQuerySet;
	}

						//setTimeout(() => {
							//DataManager.add('isOpenSearchOrg', true);
						//}, 5000);

						const onSearch = (value) => {
							
							let oQuerySet = ExecuteQuery(value);
							
							//const dataOrgSearch[];
							
							if(dataOrgSearch.length != 0){
								dataOrgSearch.length = 0;
							};
							for(i = 0; i < oQuerySet.length; i++){
							dataOrgSearch.push(
								{
									id: oQuerySet[i]["Id"],
									orgName: oQuerySet[i]["Name"],
									inn: oQuerySet[i]["RI INN"],
									kpp: oQuerySet[i]["RI KPP"],
									cnum: oQuerySet[i]["RI External Client ID"],
								}
								);
							}
							
							//setTimeout(() => console.log('Заполнили массив результатами поиска'), 1000);
							DataManager.add('searchOrgDataUpdate', dataOrgSearch);
							console.log(dataOrgSearch);
							//DataManager.add('isOpenSearchOrg', false);
						}
	if($("#search-org-modal").length==0){
		//console.log($("#search-org-modal").html());
	SiebelAppFacade.SearchOrgShow({
		elementId: 'appeal--modals-box',
		isOpen: true,
		data: dataOrgSearch,
		onSearch: (value) => {
			PM.ExecuteMethod("InvokeMethod", "NewQuery");
			setTimeout(onSearch,1000,value);
		},
		onSelect: (value) => {
			PM.ExecuteMethod("InvokeMethod", "NewQuery"/*, PS*/);
			//$('#appeal--modals-box').html('');
			setTimeout(PickRecord,1000,value, PM, ReqFormPM, AccDetPM);
			setTimeout(isOpenSearchOrgFalse, 1000);
			},
		onClose: () => {
			//console.log("close");
			PM.ExecuteMethod("InvokeMethod", "CloseApplet");
			setTimeout(isOpenSearchOrgFalse, 1000);
		},
		subscribe: DataManager.subscribe
	});
	//console.log($("#search-org-modal").html());
	}
	else {
			DataManager.add('isOpenSearchOrg', true);
			DataManager.add('searchOrgDataUpdate', dataOrgSearch);
			//console.log($("#search-org-modal").html());
	}
	
	function EQ(PM){
		PM.ExecuteMethod("InvokeMethod", "ExecuteQuery");
		//console.log('EQ');
	};
	
	function NQ(PM){
		PM.ExecuteMethod("InvokeMethod", "NewQuery");
		//console.log('EQ');
	};
	
	function isOpenSearchOrgFalse(){
		SiebelAppFacade.DMPL.add('isOpenSearchOrg', false);
	}
     // Add code here that should happen after default processing
    }

    RICDCAccountsPickAppletPR.prototype.BindData = function (bRefresh) {
     // BindData is called each time the data set changes.
     // This is where you'll bind that data to user interface elements you might have created in ShowUI
     // Add code here that should happen before default processing
     SiebelAppFacade.RICDCAccountsPickAppletPR.superclass.BindData.apply(this, arguments);
     // Add code here that should happen after default processing
    }

    RICDCAccountsPickAppletPR.prototype.BindEvents = function () {
     // BindEvents is where we add UI event processing.
     // Add code here that should happen before default processing
     SiebelAppFacade.RICDCAccountsPickAppletPR.superclass.BindEvents.apply(this, arguments);
     // Add code here that should happen after default processing
    }

    RICDCAccountsPickAppletPR.prototype.EndLife = function () {
     // EndLife is where we perform any required cleanup.
     // Add code here that should happen before default processing
			DataManager.add('isOpenSearchOrg', false);
     SiebelAppFacade.RICDCAccountsPickAppletPR.superclass.EndLife.apply(this, arguments);
     // Add code here that should happen after default processing
    }

    return RICDCAccountsPickAppletPR;
   }()
  );
  return "SiebelAppFacade.RICDCAccountsPickAppletPR";
 })
}

