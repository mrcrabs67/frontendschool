/* eslint-disable prefer-rest-params */
/* eslint-disable prefer-arrow-callback */
// Regenerate using:https://duncanford.github.io/prpm-code-generator/?prpm=PR&object=DesktopForm&name=RI%20CDC%20Request%20Form%20Applet&userprops=&comments=Yes&logging=No
if (typeof SiebelAppFacade.RICDCRequestFormAppletPR === 'undefined') {
    SiebelJS.Namespace('SiebelAppFacade.RICDCRequestFormAppletPR');
    define('siebel/custom/cdc/RICDCRequestFormAppletPR', [
        'siebel/custom/cdc/RICDCFormAppletPR',
        //'siebel/phyrenderer',
        'siebel/custom/cdc/cdc-utils',
        // eslint-disable-next-line sonarjs/cognitive-complexity
    ], function () {
        const DEFAULT_ID = 'Id';
        const ACCOUNT_ID = 'Account Id';
        let previousAccountId = '';
        let DataManager = SiebelAppFacade.DMPL;
        let dataOrg;
        let DefaultEmp;
        if (SiebelAppFacade.DMPL) {
            DataManager = SiebelAppFacade.DMPL;
        } else {
            DataManager = SiebelAppFacade.Events();
        }

        SiebelAppFacade.RICDCRequestFormAppletPR = (function () {
            function RICDCRequestFormAppletPR(pm) {
                SiebelAppFacade.RICDCRequestFormAppletPR.superclass.constructor.apply(
                    this,
                    arguments,
                );
            }

            SiebelJS.Extend(
                RICDCRequestFormAppletPR,
                SiebelAppFacade.RICDCFormAppletPR,
                //SiebelAppFacade.PhysicalRenderer,
            );

            RICDCRequestFormAppletPR.prototype.Init = function () {
                // Init is called each time the object is initialised.
                // Add code here that should happen before default processing
                SiebelAppFacade.RICDCRequestFormAppletPR.superclass.Init.apply(
                    this,
                    arguments,
                );
                // Add code here that should happen after default processing
                DefaultEmp = undefined;
                previousAccountId = '';
            };

            RICDCRequestFormAppletPR.prototype.ShowUI = function () {
                // ShowUI is called when the object is initially laid out.
                // Add code here that should happen before default processing
                SiebelAppFacade.RICDCRequestFormAppletPR.superclass.ShowUI.apply(
                    this,
                    arguments,
                );

                /*let PM1 = this.GetPM();
                const sAppletId = PM1.Get('GetFullId');

                const elAppletId = document.getElementById(sAppletId);
                if (elAppletId) {
                  elAppletId.style.display = 'none';
                }*/
                // Add code here that should happen after default processing
                const compareFunc = function (a, b) {
                    let result = 0;
                    const nameA = a.lastName + a.firstName + a.middleName;
                    const nameB = b.lastName + b.firstName + b.middleName;
                    if (nameA > nameB) {
                        result = 1;
                    } else if (nameA === nameB) {
                        result = 0;
                    } else {
                        result = -1;
                    }
                    if (result === 0) {
                        if (a.edit < b.edit) {
                            result = 1;
                        } else if (a.edit === b.edit) {
                            result = 0;
                        } else {
                            result = -1;
                        }
                    }
                    return result;
                };

                const fillUndefined = function (obj) {
                    for (let i in obj) {
                        if (typeof obj[i] === 'undefined') {
                            obj[i] = '';
                        }
                    }
                };

                const onContactUpdate = function (obj) {
                    const serviceWF = SiebelApp.S_App.GetService(
                        'Workflow Process Manager',
                    );
                    const psInp = SiebelApp.S_App.NewPropertySet();
                    const positionName = obj.jobTitleOther === true ? 'Иное' : obj.jobTitle;
                    const position = obj.jobTitleOther === true ? obj.jobTitle : '';
                    psInp.SetProperty('ProcessName', 'RI CDC Change Account Contact Process');
                    psInp.SetProperty('Object Id', obj.id);
                    psInp.SetProperty('AccountId', obj.accountId);
                    psInp.SetProperty('sFirstName', obj.firstName ? obj.firstName : '');
                    psInp.SetProperty('sLastName', obj.lastName ? obj.lastName : '');
                    psInp.SetProperty('sMiddleName', obj.middleName ? obj.middleName : '');
                    psInp.SetProperty('sMobileNum', obj.mobileNumber ? obj.mobileNumber : '');
                    psInp.SetProperty('sIncomingPhone', obj.incomingNumber ? obj.incomingNumber : '');
                    psInp.SetProperty('sAdditionalNum', obj.additionalNumber ? obj.additionalNumber : '');
                    psInp.SetProperty('sPositionName', positionName);
                    psInp.SetProperty('sPosition', position);

                    const psOut = serviceWF.InvokeMethod('RunProcess', psInp);
                    const error = psOut.childArray[0].propArray['Error Code'];
                    if (error.indexOf(400) === -1) {
                        previousAccountId = Math.random();//TODO fix
                        const index = dataOrg.employees.findIndex(
                            findId,
                            obj.id,
                        );
                        obj.edit = true;
                        if (index > -1) {
                            fillUndefined(obj);
                            dataOrg.employees[index] = obj;
                        }
                        const data = {};
                        data.contactedEmployeeId = obj.id;
                        onDataUpdate(data);
                    }
                };

                const onContactAdd = function (obj) {
                    const serviceWF = SiebelApp.S_App.GetService(
                        'Workflow Process Manager',
                    );
                    const positionName = obj.jobTitleOther === true ? 'Иное' : obj.jobTitle;
                    const position = obj.jobTitleOther === true ? obj.jobTitle : '';
                    const psInp = SiebelApp.S_App.NewPropertySet();
                    psInp.SetProperty('ProcessName', 'RI CDC Add Account Contact Process');
                    psInp.SetProperty('Object Id', obj.accountId);
                    psInp.SetProperty('sFirstName', obj.firstName ? obj.firstName : '');
                    psInp.SetProperty('sLastName', obj.lastName ? obj.lastName : '');
                    psInp.SetProperty('sMiddleName', obj.middleName ? obj.middleName : '');
                    psInp.SetProperty('sMobileNum', obj.mobileNumber ? obj.mobileNumber : '');
                    psInp.SetProperty('sIncomingPhone', obj.incomingNumber ? obj.incomingNumber : '');
                    psInp.SetProperty('sAdditionalNum', obj.additionalNumber ? obj.additionalNumber : '');
                    psInp.SetProperty('sPositionName', positionName);
                    psInp.SetProperty('sPosition', position);

                    const psOut = serviceWF.InvokeMethod('RunProcess', psInp);
                    const Id = psOut.childArray[0].propArray['sContactId'];
                    obj.edit = true;
                    obj.id = Id;
                    const fullName = obj.lastName + ' ' + obj.firstName + ' ' + (obj.middleName ? obj.middleName : '');
                    previousAccountId = Math.random();//TODO fix
                    fillUndefined(obj);
                    dataOrg.employees.push(obj);
                    const data = {};
                    data.contactedEmployeeId = Id;
                    onDataUpdate(data);
                };
                const onContactDelete = function (obj) {
                    const serviceWF = SiebelApp.S_App.GetService(
                        'Workflow Process Manager',
                    );
                    const psInp = SiebelApp.S_App.NewPropertySet();

                    psInp.SetProperty('ProcessName', 'RI CDC Delete Account Contact Process');
                    psInp.SetProperty('Object Id', obj.id);
                    const psOut = serviceWF.InvokeMethod('RunProcess', psInp);
                    //previousAccountId = Math.random();//TODO fix
                    const index = dataOrg.employees.findIndex(
                        findId,
                        obj.id,
                    );
                    if (index > -1) {
                        dataOrg.employees.splice(index, 1);
                    }
                    const data = {};
                    if (dataOrg.contactedEmployeeId === obj.id) {
                        data.contactedEmployeeId = '';
                    }
                    onDataUpdate(data);

                };

                const findId = function (elem, index, array) {
                    if (this.toString() === elem.id) {
                        return true;
                    }
                    return false;
                };

                const findName = function (elem, index, array) {
                    const name = elem.lastName + ' ' + elem.firstName + ' ' + elem.middleName;
                    if (this.toString() === name.trim()) {
                        return true;
                    }
                    return false;
                };

                function OpenPickApplet(PR, ControlName) {
                    const PM = PR.GetPM();
                    const InPS = new JSSPropertySet();
                    InPS.SetProperty('SWECSP', 'false');
                    InPS.SetProperty(
                        'SWEField',
                        PR.GetUIWrapper(
                            PM.Get('GetControls')[ControlName],
                        ).control.GetInputName(),
                    );
                    InPS.SetProperty('SWEMethod', 'EditField');
                    InPS.SetProperty('SWESP', 'true');

                    PM.ExecuteMethod('InvokeMethod', 'EditField', InPS);
                }

                const onDataUpdate = function (data, needRefresh = true) {
                    if (dataOrg) {
                        let name = '';
                        if (typeof data.contactedEmployeeId !== 'undefined') {
                            dataOrg.contactedEmployeeId = data.contactedEmployeeId;
                            if (data.contactedEmployeeId !== '') {
                                name = dataOrg.employees.find(
                                    findId,
                                    data.contactedEmployeeId,
                                );
                            }
                            BC.SetFieldValue('Contact_Full_Name', name ? (name.lastName + ' ' + name.firstName + ' ' + name.middleName) : '');
                        }
                    }
                    if (data.additionalNumber) {
                        BC.SetFieldValue(
                            'RI_CDC_Additional_Phone_Number',
                            data.additionalNumber,
                        );
                    }
                    if (data.mobileNumber) {
                        BC.SetFieldValue('RI Primary Phone Number', data.mobileNumber);
                    }
                    PM.ExecuteMethod('InvokeMethod', 'WriteRecord');
                    if (needRefresh) {
                        PM.ExecuteMethod('InvokeMethod', 'RefreshRecord');
                    }
                };

                function fillDefaultEmployee(lastName, firstName, middleName = '', accountId, phone = '', edit = false) {
                    DefaultEmp = lastName
                        ? {
                            edit: edit,
                            accountId: accountId,
                            lastName: lastName,
                            firstName: firstName ? firstName : '',
                            middleName: middleName ? middleName : '',
                            jobTitle: "",
                            jobTitleOther: true,
                            incomingNumber: phone,
                            id: DEFAULT_ID,
                        }
                        : undefined;
                }

                function getDataOrg(BC) {
                    const AccountId = BC.GetFieldValue(ACCOUNT_ID);
                    const employees = [];
                    let CurrentEmployee;
                    const CurrentEmployeeName =
                        BC.GetFieldValue('Contact_Full_Name').trim();
                    let contactedEmployeeId = '';

                    if (AccountId !== '' && previousAccountId != AccountId) {
                        previousAccountId = AccountId;
                        const serviceWF = SiebelApp.S_App.GetService(
                            'Workflow Process Manager',
                        );
                        const psInp = SiebelApp.S_App.NewPropertySet();

                        psInp.SetProperty('ProcessName', 'RI CDC Query IO Process');
                        psInp.SetProperty('IOName', 'RI CDC Contact Account Phone');
                        psInp.SetProperty(
                            'Search',
                            `[RI CDC Account Phone.Account Id]="${AccountId}"`,
                        );

                        const psOut = serviceWF.InvokeMethod('RunProcess', psInp);
                        const employeesTemp =
                            psOut.childArray[0].childArray[0].childArray[0].childArray;

                        employeesTemp.forEach((item) => {
                            let edit = false;
                            const roles = [];
                            item.childArray[0].childArray.forEach((it) => {
                                roles.push(it.propArray.Role)
                            });
                            item.roles = roles;
                            if (roles.indexOf('Контакт из АРМ') > -1) {
                                edit = true;
                            }
                            let jobTitle = item.propArray['RI Position Name'];
                            let jobTitleOther = false;
                            if (jobTitle === 'Иное') {
                                jobTitleOther = true;
                                jobTitle = item.propArray['RI Position'];
                            }
                            employees.push({
                                accountId: AccountId,
                                additionalNumber: item.propArray['RI Additional Phone Number'],
                                edit: edit,
                                firstName: item.propArray['First Name'],
                                incomingNumber: BC.GetFieldValue('RI_CDC_Incoming_Phone_Number'),
                                jobTitle: jobTitle,
                                jobTitleOther: jobTitleOther,
                                lastName: item.propArray['Last Name'],
                                middleName: item.propArray['Middle Name'],
                                mobileNumber: item.propArray['RI Contact Mobile Number'],
                                phone: item.propArray['RI Contact Phone Number'],
                                id: item.propArray.Id,
                            });
                        });

                        employees.sort(compareFunc);

                        if (
                            dataOrg &&
                            DefaultEmp &&
                            typeof employees.find(findName, DefaultEmp.value) === 'undefined'
                        ) {
                            employees.push(DefaultEmp);
                        }
                    } else if (dataOrg) {
                        if (AccountId === '') {
                            dataOrg.employees.length = 0;
                        }
                        dataOrg.employees.forEach((item) => {
                            employees.push(item);
                        });
                    }


                    if (CurrentEmployeeName !== '') {
                        CurrentEmployee = employees.find(
                            findName,
                            CurrentEmployeeName,
                        );
                        if (typeof CurrentEmployee === 'undefined') {
                            contactedEmployeeId = DEFAULT_ID;

                            if (typeof DefaultEmp === 'undefined') {
                                const Namearr = CurrentEmployeeName.split(' ');
                                fillDefaultEmployee(
                                    Namearr[0],
                                    Namearr[1],
                                    Namearr[2],
                                    BC.GetFieldValue(ACCOUNT_ID),
                                    BC.GetFieldValue('RI_CDC_Incoming_Phone_Number'),
                                    false,
                                );
                                employees.push(DefaultEmp);
                            }
                        } else {
                            contactedEmployeeId = CurrentEmployee.id;
                        }
                    }
                    const data = {
                        appeal: `Обращение №${BC.GetFieldValue('SR_Number')}`,
                        accountId: AccountId,
                        incomingNumber: BC.GetFieldValue('RI_CDC_Incoming_Phone_Number'),
                        status: BC.GetFieldValue('Status'),
                        nameOrganization: BC.GetFieldValue('Account_Name'),//RUAVSVA CDR-3743
                        companyGroup: BC.GetFieldValue('RI_GCC_Calc'),
                        clientCategory: BC.GetFieldValue('RI_CDC_Client_Category'),
                        manager: BC.GetFieldValue('Manager Name Calc'),//pvolkov 31052023 ARM-298 Поменял поле RI_Sales_Rep на Manager Name Calc
                        //mobileNumber:CurrentEmployee ? CurrentEmployee.mobileNumber : '',
                        //additionalNumber:CurrentEmployee ? CurrentEmployee.additionalNumber : '',
                        //jobTitle:CurrentEmployee ? CurrentEmployee.jobTitle : '',
                        //mobileNumber: BC.GetFieldValue('RI Primary Phone Number'),
                        //additionalNumber: BC.GetFieldValue(
                        //  'RI_CDC_Additional_Phone_Number',
                        //),
                        contactedEmployeeId,
                        employees,
                    };

                    if (
                        dataOrg &&
                        data.contactedEmployeeId === DEFAULT_ID &&
                        dataOrg.contactedEmployeeId !== DEFAULT_ID
                    ) {
                        // set Default Employee if Account changed
                        onDataUpdate({contactedEmployeeId});
                    }

                    if (dataOrg) {
                        dataOrg = data;
                    }

                    return data;
                }

                function goToAccountDetails(accountId) {
                    SiebelApp.S_App.uiStatus.Busy({mask: !0});

                    const serviceWF = SiebelApp.S_App.GetService('Workflow Process Manager');
                    const psInp = SiebelApp.S_App.NewPropertySet();
                    SiebelApp.S_App.SetProfileAttr("RICDCReqId", BC.GetFieldValue("Id"));
                    SiebelApp.S_App.SetProfileAttr("canInvokeBack", "false");
                    console.log("RICDCReqId = ", SiebelApp.S_App.GetProfileAttr("RICDCReqId"));

                    const options = {
                        goToBackDisabled: false,
                    }

                    DataManager.add('header', {
                        pathEvent: 'options',
                        value: options,
                    });


                    psInp.SetProperty('ProcessName', 'RBRU Go To View');
                    psInp.SetProperty('View Name', 'Account Detail - Company Details 1 View');
                    psInp.SetProperty('BO Name', 'Account');
                    psInp.SetProperty('BC Name', 'Account');
                    psInp.SetProperty('Entity Id', accountId);

                    serviceWF.InvokeMethod('RunProcess', psInp);

                    setTimeout('SiebelApp.S_App.uiStatus.Free(true)', 5000);
                }

                function getJobTitleList() {
                    let serviceWF = SiebelApp.S_App.GetService('Workflow Process Manager');
                    const psInp = SiebelApp.S_App.NewPropertySet();
                    let psOut;
                    const Type = 'RI_CONTACTS_FUNCTION';
                    psInp.SetProperty('ProcessName', 'RI CDC Query IO Process');
                    psInp.SetProperty('IOName', 'ListOfValuesIO');
                    psInp.SetProperty(
                        'Search',
                        `[List Of Values.Type]="${Type}" AND [List Of Values.Active]='Y'`,
                    );
                    psOut = serviceWF.InvokeMethod('RunProcess', psInp);
                    const resArr = psOut.childArray[0].childArray[0].childArray[0].childArray;
                    const lovArr = [];
                    resArr.forEach(element => {
                        const arr = element.propArray;
                        lovArr.push({
                            value: arr['Description'],
                            order: arr['Order By'],
                        });
                    });
                    lovArr.sort((a, b) => {
                        const orderA = +a.order, orderB = +b.order;

                        if (orderA > orderB) {
                            return 1;
                        } else if (orderA === orderB) {
                            return 0;
                        } else {
                            return -1;
                        }
                    });
                    return lovArr.map((a) => a.value);
                }

                const jobTitleList = getJobTitleList();
                const PR = this;
                const View = SiebelApp.S_App.GetActiveView();
                const Applet = View.GetActiveApplet();
                const PM = PR.GetPM();
                const BC = PM.Get('GetBusComp');
                dataOrg = getDataOrg(BC);
                if (typeof DefaultEmp === 'undefined') {
                    DefaultEmp = null;
                }
                PM.AttachPostProxyExecuteBinding('RefreshRecord', DataOrgUpdate);

                const props = {
                    data: dataOrg,
                    guides: {
                        jobTitleList: jobTitleList,
                    },
                    onContactAdd: (arguments) => {
                        console.log('onContactAdd', arguments);
                        onContactAdd(arguments);
                    },
                    onContactUpdate: (arguments) => {
                        console.log('onContactUpdate', arguments);
                        onContactUpdate(arguments);
                    },
                    onContactDelete: (arguments) => {
                        console.log('onContactDelete', arguments);
                        onContactDelete(arguments);
                    },
                    onDataUpdate,
                    onOpenModalSearchOrg: (org) => {
                        DataManager.add('isOpenSearchOrg', false);
                        setTimeout(OpenPickApplet, 1000, PR, ACCOUNT_ID);
                    },
                    onOpenModalEditOrg: (org) => {
                        goToAccountDetails(dataOrg.accountId);
                        //SiebelAppFacade.tmpfun('1-15237');
                    },
                    subscribe: DataManager.subscribe,
                };

                SiebelAppFacade.AppealOrganizationShow(props);

                function DataOrgUpdate() {
                    const data = getDataOrg(BC);
                    DataManager.add('appealDataOrgUpdate', data);
                    /*DataManager.add('appealEvents', {
                      pathEvent: 'employees.update',
                      value: {
                        id: data.contactedEmployeeId,
                        employees: data.employees,
                      },
                    });*/
                }

                // const PM = this.GetPM();
                /* const sAppletId = PM.Get('GetFullId');
                 const $sNavTab = $('#s_vctrl_div');
                 // document.getElementsByClassName("siebui-nav-tab siebui-subview-navs");

                 const elAppletId = document.getElementById(sAppletId);
                 if (elAppletId) {
                   elAppletId.style.display = 'none';
                 }

                 if ($sNavTab) {
                   $sNavTab.hide();
                 }*/
                const AID = BC.GetFieldValue(ACCOUNT_ID);
                const NOF = SiebelApp.S_App.GetProfileAttr('NeedOpenFlg');
                if (
                    BC.GetFieldValue(ACCOUNT_ID) === '' &&
                    SiebelApp.S_App.GetProfileAttr('NeedOpenFlg') === 'Y'
                ) {
                    SiebelApp.S_App.SetProfileAttr('NeedOpenFlg', '');
                    DataManager.add('isOpenSearchOrg', false);
                    setTimeout(OpenPickApplet, 1000, PR, ACCOUNT_ID);
                }
            };

            RICDCRequestFormAppletPR.prototype.BindData = function (bRefresh) {
                // BindData is called each time the data set changes.
                // This is where you'll bind that data to user interface elements you might have created in ShowUI
                // Add code here that should happen before default processing
                SiebelAppFacade.RICDCRequestFormAppletPR.superclass.BindData.apply(
                    this,
                    arguments,
                );
                // Add code here that should happen after default processing
            };

            RICDCRequestFormAppletPR.prototype.BindEvents = function () {
                // BindEvents is where we add UI event processing.
                // Add code here that should happen before default processing
                SiebelAppFacade.RICDCRequestFormAppletPR.superclass.BindEvents.apply(
                    this,
                    arguments,
                );
                // Add code here that should happen after default processing
            };

            RICDCRequestFormAppletPR.prototype.EndLife = function () {
                // EndLife is where we perform any required cleanup.
                // Add code here that should happen before default processing
                SiebelAppFacade.RICDCRequestFormAppletPR.superclass.EndLife.apply(
                    this,
                    arguments,
                );
                // Add code here that should happen after default processing
            };

            return RICDCRequestFormAppletPR;
        })();
        return 'SiebelAppFacade.RICDCRequestFormAppletPR';
    });
}
