//Regenerate using:https://duncanford.github.io/prpm-code-generator/?prpm=PR&object=DesktopList&name=RI%20CDC%20Request%20Directory%20List%20Applet&userprops=&comments=Yes&logging=No
if (typeof (SiebelAppFacade.RICDCRequestDirectoryListAppletPR) === "undefined") {

	SiebelJS.Namespace("SiebelAppFacade.RICDCRequestDirectoryListAppletPR");
	define("siebel/custom/cdc/RICDCRequestDirectoryListAppletPR", ['siebel/custom/cdc/RICDCListAppletPR',//"siebel/jqgridrenderer",
		'siebel/custom/cdc/cdc-utils'
	],
		function () {
			SiebelAppFacade.RICDCRequestDirectoryListAppletPR = (function () {

				function RICDCRequestDirectoryListAppletPR(pm) {
					SiebelAppFacade.RICDCRequestDirectoryListAppletPR.superclass.constructor.apply(this, arguments);
				}

				SiebelJS.Extend(RICDCRequestDirectoryListAppletPR, SiebelAppFacade.RICDCListAppletPR);

				RICDCRequestDirectoryListAppletPR.prototype.Init = function () {
					// Init is called each time the object is initialised.
					// Add code here that should happen before default processing
					SiebelAppFacade.RICDCRequestDirectoryListAppletPR.superclass.Init.apply(this, arguments);

					// Add code here that should happen after default processing
				}

				RICDCRequestDirectoryListAppletPR.prototype.ShowUI = function () {
					// ShowUI is called when the object is initially laid out.
					// Add code here that should happen before default processing
					SiebelAppFacade.RICDCRequestDirectoryListAppletPR.superclass.ShowUI.apply(this, arguments);
					// Add code here that should happen after default processing
					const PR = this;
					const View = SiebelApp.S_App.GetActiveView();
					const Applet = View.GetActiveApplet();
					const PM = PR.GetPM();
					const BC = PM.Get("GetBusComp");
					if (typeof SiebelAppFacade.OldNotifyGeneric === 'undefined') {
						SiebelAppFacade.OldNotifyGeneric = SiebelApp.S_App.ListApplet.superclass.NotifyGeneric;
					}
					SiebelApp.S_App.ListApplet.superclass.NotifyGeneric = function (a, b) {
						if (View.GetName() != "RI CDC Request Detail View") {
							SiebelAppFacade.OldNotifyGeneric.call(this, a, b);
						}
					};


					/*const sAppletId = PM.Get('GetFullId');
					const elAppletId = document.getElementById(sAppletId);
					if (elAppletId) {
					 elAppletId.style.display = 'none';
					}*/

					function RequestControlPickList(PR, ControlName) {
						let PM = PR.GetPM();
						let InsPS = new JSSPropertySet();
						InsPS.SetProperty("SWEJI", "false");
						InsPS.SetProperty("SWEField", PR.GetColumnControl(ControlName).GetInputName());
						PM.ExecuteMethod("InvokeMethod", "GetQuickPickInfo", InsPS);

						delete InsPS;
					}

					let Arr = [];
					let GetControlPickList = function (a, b, c) {
						let pickList;

						pickList = c.childArray[1].childArray[1].propArray.ArgsArray;
						Arr.length = 0;//clear array
						let mas = pickList.split("*");
						let slength = mas[6];
						let mascount = mas.length;
						for (let i = 7; i < mascount; i++) {
							let value = mas[i].slice(0, slength);
							Arr.push(value);
							let ilength = mas[i].length;
							slength = mas[i].slice(slength, ilength);
						}
					}

					PM.AttachPreProxyExecuteBinding("GetQuickPickInfo", GetControlPickList);

					const DataManager = SiebelAppFacade.Events();

					RequestControlPickList(PR, "Product_Name");
					const products = Arr.map((x) => x);
					products.sort();


					const addProblem = () => {

						//console.log("Add Problem");
						PM.ExecuteMethod("InvokeMethod", "NewRecord");
						let newid = BC.GetFieldValue("Id");

						const item = {
							id: newid,
							product: '',
							theme: '',
							clarification: '',
							themes: [],
							clarifications: [],
						};


						DataManager.add('problems', item);

						if (newid != BC.GetFieldValue("Id"))
							while (newid != BC.GetFieldValue("Id") && PM.ExecuteMethod("CanInvokeMethod", "GotoNext")) {
								PM.ExecuteMethod("InvokeMethod", "GotoNext");
							}
						PM.ExecuteMethod("InvokeMethod", "WriteRecord");
					}

					function setFieldValue(id, fieldname, fieldvalue) {
						PM.ExecuteMethod("InvokeMethod", "ExecuteQuery");//firstrecord
						if (id != BC.GetFieldValue("Id"))
							while (id != BC.GetFieldValue("Id") && PM.ExecuteMethod("CanInvokeMethod", "GotoNext")) {
								PM.ExecuteMethod("InvokeMethod", "GotoNext");
							}
						BC.SetFieldValue(fieldname, fieldvalue);
						PM.ExecuteMethod("InvokeMethod", "WriteRecord");
					}

					const loadedThemes = (id, product) => {
						setFieldValue(id, "Product_Name", product);
						RequestControlPickList(PR, "Theme_Name");
						//console.log('loadedThemes',id, product);
						const themes = Arr.map((x) => x);
						themes.sort();
						//console.log("themes = ", themes);
						DataManager.add(`themes_${id}`, themes);
						//console.log("tkey", `themes_${id}`);

					}

					const loadedClarification = (id, clarification) => {
						//setFieldValue(id, "Theme_Name", clarification);
						setFieldValue(id, "Theme_Name", clarification);
						setFieldValue(id, "Clarification_Name", "");
						//ProdTheme
						const serviceWF = SiebelApp.S_App.GetService('Workflow Process Manager');
						const psInp = SiebelApp.S_App.NewPropertySet();
						let psOut = SiebelApp.S_App.NewPropertySet();
						psInp.SetProperty('ProcessName', 'RI CDC ProdTheme WF');
						psInp.SetProperty('Object Id', id);
						psOut = serviceWF.InvokeMethod('RunProcess', psInp);
						const ProdTheme = psOut.childArray[0].propArray.ProdThemeId;
						setFieldValue(id, "ProdTheme", ProdTheme);
						//
						RequestControlPickList(PR, "Clarification_Name");
						//console.log('Theme = ', clarification);
						const clarifications = Arr.map((x) => x);;
						clarifications.sort();

						DataManager.add(`clarifications_${id}`, clarifications);


					}

					const onUpdateProblem = (problem) => {
						//console.log('onUpdateProblem', problem);
						//console.log("Clarification = ", problem.clarification);
						//console.log("Id = ", problem.id);
						setFieldValue(problem.id, "Clarification_Name", problem.clarification);
						//setFieldValue(id, "Clarification_Name",
					};

					const onDeleteProblem = (id) => {
						PM.ExecuteMethod("InvokeMethod", "ExecuteQuery");//firstrecord
						//console.log('onDeleteProblem', id);
						while (id != BC.GetFieldValue("Id") && PM.ExecuteMethod("CanInvokeMethod", "GotoNext")) {
							PM.ExecuteMethod("InvokeMethod", "GotoNext");
						}
						PM.ExecuteMethod("InvokeMethod", "DeleteRecord");
					};



					let Records = PM.Get("GetRawRecordSet");

					let problems = [];
					PM.ExecuteMethod("InvokeMethod", "ExecuteQuery");//firstrecord
					for (let i = 0; i < Records.length; i++) {
						let pvalue = Records[i]["Product_Name"];
						let tvalue = Records[i]["Theme_Name"];
						let cvalue = Records[i]["Clarification_Name"];
						let id = Records[i]["Id"];
						RequestControlPickList(PR, "Theme_Name");
						let themes = Arr.map((x) => x);
						RequestControlPickList(PR, "Clarification_Name");
						let clarifications = Arr.map((x) => x);
						problems[i] = {
							id: id,
							product: pvalue,
							theme: tvalue,
							clarification: cvalue,
							themes: pvalue === "" ? [] : themes,
							clarifications: tvalue === "" ? [] : clarifications,
						};
						if (/*PM.ExecuteMethod("CanInvokeMethod","GotoNext") && */BC.GetCurRowNum() < Records.length)
							PM.ExecuteMethod("InvokeMethod", "GotoNext");
						/*else {
							PM.ExecuteMethod("InvokeMethod","ExecuteQuery");//firstrecord
						}*/
					}

					SiebelApp.S_App.ListApplet.superclass.NotifyGeneric = SiebelAppFacade.OldNotifyGeneric;



					//console.log(problems);

					SiebelAppFacade.AppealProblemsShow({
						subscribe: DataManager.subscribe,
						products,
						problems,
						addProblem,
						loadedThemes,
						loadedClarification,
						onUpdateProblem,
						onDeleteProblem,
					});

				}

				RICDCRequestDirectoryListAppletPR.prototype.BindData = function (bRefresh) {
					// BindData is called each time the data set changes.
					// This is where you'll bind that data to user interface elements you might have created in ShowUI
					// Add code here that should happen before default processing
					SiebelAppFacade.RICDCRequestDirectoryListAppletPR.superclass.BindData.apply(this, arguments);
					// Add code here that should happen after default processing
				}

				RICDCRequestDirectoryListAppletPR.prototype.BindEvents = function () {
					// BindEvents is where we add UI event processing.
					// Add code here that should happen before default processing
					SiebelAppFacade.RICDCRequestDirectoryListAppletPR.superclass.BindEvents.apply(this, arguments);
					// Add code here that should happen after default processing
				}

				RICDCRequestDirectoryListAppletPR.prototype.EndLife = function () {
					// EndLife is where we perform any required cleanup.
					// Add code here that should happen before default processing
					SiebelAppFacade.RICDCRequestDirectoryListAppletPR.superclass.EndLife.apply(this, arguments);
					// Add code here that should happen after default processing
				}

				return RICDCRequestDirectoryListAppletPR;
			}()
			);
			return "SiebelAppFacade.RICDCRequestDirectoryListAppletPR";
		})
}

