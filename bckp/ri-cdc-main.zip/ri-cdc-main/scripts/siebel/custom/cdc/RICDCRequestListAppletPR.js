//Regenerate using:https://duncanford.github.io/prpm-code-generator/?prpm=PR&object=DesktopList&name=RICDCRequestListApplet&userprops=&comments=Yes&logging=Yes
if (typeof (SiebelAppFacade.RICDCRequestListAppletPR) === "undefined") {

    SiebelJS.Namespace("SiebelAppFacade.RICDCRequestListAppletPR");
    define("siebel/custom/cdc/RICDCRequestListAppletPR", ["siebel/custom/cdc/RICDCListAppletPR"],
        function () {
            let DataManager = SiebelAppFacade.DMPL;
            if (SiebelAppFacade.DMPL) {
                DataManager = SiebelAppFacade.DMPL;
            } else {
                DataManager = SiebelAppFacade.Events();
            }
            SiebelAppFacade.RICDCRequestListAppletPR = (function () {

                function RICDCRequestListAppletPR(pm) {
                    SiebelAppFacade.RICDCRequestListAppletPR.superclass.constructor.apply(this, arguments);
                }

                SiebelJS.Extend(RICDCRequestListAppletPR, SiebelAppFacade.RICDCListAppletPR);

                RICDCRequestListAppletPR.prototype.DataManager = DataManager;

                RICDCRequestListAppletPR.prototype.Init = function () {
                    // Init is called each time the object is initialised.
                    // Add code here that should happen before default processing
                    SiebelAppFacade.RICDCRequestListAppletPR.superclass.Init.apply(this, arguments);
                    //SiebelJS.Log(this.GetPM().Get("GetName")+": RICDCRequestListAppletPR:      Init method reached.");
                    // Add code here that should happen after default processing
                }
                RICDCRequestListAppletPR.prototype.GetRequestList = function (pageNumber, pageSize, needCount = 'N', accountId = '', searchSpec = '', isMyAppeals = true) {
                    uniq_fast = function (a) {
                        let seen = {};
                        let out = [];
                        const len = a.length;
                        let j = 0;
                        for (let i = 0; i < len; i++) {
                            let item = a[i];
                            if (seen[item.id] !== 1) {
                                seen[item.id] = 1;
                                out[j++] = item;
                            }
                        }
                        return out;
                    }
                    const result = {};
                    let parentId = '';
                    let login = '';
                    let historyPage = false;

                    if (accountId === 'NoId') {
                        result.totalCount = 0;
                        result.errorCode = '';
                        result.errorDescription = '';
                        result.data = [];
                        return result;
                    }


                    if (searchSpec === '' && accountId !== 'NoId' && accountId !== '') {
                        parentId = SiebelApp.S_App.GetActiveView().GetAppletMap()['RI CDC Request Form Applet'].GetBusComp().GetFieldValue('Id');
                        searchSpec = "[Account Id]='" + accountId + "' AND [Id] <>'" + parentId + "'";
                        historyPage = true;
                    }

                    if (isMyAppeals == true && !historyPage) {
                        login = SiebelApp.S_App.GetUserName();
                        searchSpec = "[login]='" + login + "'";
                    }

                    const serviceWF = SiebelApp.S_App.GetService('Workflow Process Manager');
                    const psInp = SiebelApp.S_App.NewPropertySet();
                    psInp.SetProperty('ProcessName', 'RI CDC Get Requests Process');
                    psInp.SetProperty('NeedCount', needCount);
                    psInp.SetProperty('PageNum', pageNumber);
                    psInp.SetProperty('PageSize', pageSize);
                    //psInp.SetProperty('AccountId',accountId);
                    psInp.SetProperty('SearchSpecific', searchSpec);
                    psInp.SetProperty('isMyAppeals', isMyAppeals);
                    const psOut = serviceWF.InvokeMethod('RunProcess', psInp);
                    console.log(psOut);
                    const resArr = psOut.childArray[0].propArray;
                    const totalCount = resArr.Count;
                    const lastPage = resArr.lastPage;
                    const errorCode = resArr['Error Code'];
                    const errorMessage = resArr['Error Message'];
                    //const appealNumber = resArr['Request2Num'];//RUAVSVA 02092022
                    result.totalCount = totalCount;
                    result.errorCode = errorCode;
                    result.errorDescription = errorMessage;
                    result.featureToggle = true;
                    result.currentAppealNumber = parentId;//ruavsva
                    result.currentAppealId = parentId;//ruavsva

                    const reqArr = psOut.childArray[0].childArray[0].childArray[0]?.childArray;
                    const requests = [];
                    let links, problems;
                    reqArr?.forEach(function (i) {
                        links = [];
                        problems = [];
                        i.childArray[1].childArray.forEach(function (j) {
                            links.push({
                                id: j.propArray['Request2 Id'],
                                number: j.propArray['Request2Num'],
                            });
                            //links.push(j.propArray['Request2 Id']);
                            //console.log(j.propArray['Request2 Id']);
                            //console.log(j.propArray['Request2Num']);//Request2Num
                        });
                        //Смотрим что за херня
                        links = uniq_fast(links);
                        i.childArray[0].childArray.forEach(function (k) {
                            problems.push({
                                "product": k.propArray['Product_Name'],
                                "theme": k.propArray['Theme_Name'],
                                "description": k.propArray['Clarification_Name'],
                            });
                        });

                        requests.push({
                            "appealId": i.propArray['Id'],
                            "number": i.propArray['SR_Number'],
                            "createdAt": i.propArray['Created Date'],
                            "type": i.propArray['SR Type'] === 'Inbound' ? 'Входящее' : 'Исходящее',
                            "phone": i.propArray['RI_CDC_Incoming_Phone_Number'],
                            "requestTime": i.propArray['Created Time'],
                            "operator": i.propArray['Operator Full Name'],
                            "client": i.propArray['Account_Name'], //RUAVSVA CDR-3743
                            "inn": i.propArray['RI_Account_INN'],
                            "cnum": i.propArray['RI_External_Client_Midas_ID'],
                            "line": i.propArray['Line'],
                            "source": i.propArray['Source'],
                            "status": i.propArray['Status'],
                            "link": links,
                            "problems": problems,
                            "grade": i.propArray['Grade'],
                            //"product": i.propArray['Product'],
                            //"product": problems['0']['product'],
                            //pvalue === "" ? [] : themes,
                            "product": problems.length == 0 ? "" : problems['0']['product'],
                            //"theme": i.propArray['Theme'],
                            //"theme": problems['0']['theme'],
                            "theme": problems.length == 0 ? "" : problems['0']['theme'],
                            //"description": i.propArray['Clarification'],
                            //"description": problems['0']['description'],
                            "description": problems.length == 0 ? "" : problems['0']['description'],
                            "otherProblemCount": i.propArray['Problems Count'],
                            "jiraTask": i.propArray['Jira Task']
                        });
                    });
                    result.data = requests;
                    return result;
                }

                RICDCRequestListAppletPR.prototype.ShowUI = function () {
                    // ShowUI is called when the object is initially laid out.
                    // Add code here that should happen before default processing
                    //SiebelJS.Log(this.GetPM().Get("GetName")+": RICDCRequestListAppletPR:      ShowUI method reached.");
                    SiebelAppFacade.RICDCRequestListAppletPR.superclass.ShowUI.apply(this, arguments);
                    const activeViewName = SiebelApp.S_App.GetProfileAttr('ActiveViewName');
                    let accountId = '', eventName = 'pageHistoryAppealsEvents';
                    if (activeViewName === 'RI CDC Request History Detail View') {
                        accountId = SiebelApp.S_App.GetActiveBusObj().GetBusCompByName('RI CDC Request').GetFieldValue("Account Id");
                        eventName = 'tabHistoryAppealsEvents';
                        if (accountId === '') {
                            accountId = 'NoId';
                        }
                    }
                    let page = 1;
                    const data = this.GetRequestList(1, 25, "Y", accountId);
                    data.onToAppeal = (appealNumber) => {
                        let id = '';
                        const serviceWF = SiebelApp.S_App.GetService('Workflow Process Manager');
                        const psInp = SiebelApp.S_App.NewPropertySet();
                        if (appealNumber.match(new RegExp('[A-Za-z]')) === null) {
                            const psInp2 = SiebelApp.S_App.NewPropertySet();
                            psInp2.SetProperty('ProcessName', 'RI CDC GetRequestId Process');
                            psInp2.SetProperty('ReqNum', appealNumber);
                            const psOut2 = serviceWF.InvokeMethod('RunProcess', psInp2);
                            id = psOut2.childArray[0].propArray.ReqId;
                        } else {
                            id = appealNumber;
                        }
                        psInp.SetProperty('ProcessName', 'RI CDC GotoView Process');
                        psInp.SetProperty('AppletName', 'RI CDC Request Form Applet');
                        psInp.SetProperty('ViewName', 'RI CDC Request History Detail View');
                        psInp.SetProperty('Object Id', id);
                        let psOut = serviceWF.InvokeMethod('RunProcess', psInp);
                    };
                    data.onToPage = (type, pageNumber, appealCount, isMyAppeals) => {
                        page = pageNumber;
                        console.log(type, pageNumber, appealCount, isMyAppeals);
                        let needCount = 'N';
                        needCount = type == 'filter' ? 'Y' : 'N';
                        const data = this.GetRequestList(pageNumber, appealCount, needCount, accountId, '', isMyAppeals);
                        DataManager.add(eventName, {
                            pathEvent: 'data',
                            value: data.data,
                        });
                        if(needCount == 'Y'){
                        DataManager.add(eventName, {
                            pathEvent: 'totalCount',
                            value: data.totalCount,
                        });}
                    };
                    data.goToTab = (name) => {
                        SiebelApp.S_App.SetProfileAttr('CDCTop', $('div#_sweview').scrollTop());
                        SiebelApp.S_App.GotoView('RI CDC Request Detail View');
                    };
                    data.subscribe = DataManager.subscribe;
                    data.onAppealLink = (params) => {
                        const request1Id = SiebelApp.S_App.GetActiveView().GetAppletMap()['RI CDC Request Form Applet'].GetBusComp().GetFieldValue('Id');
                        const serviceWF = SiebelApp.S_App.GetService('Workflow Process Manager');
                        const psInp = SiebelApp.S_App.NewPropertySet();
                        let psOut;
                        let UserId = SiebelApp.S_App.GetProfileAttr("User Id");
                        let operation, request2Id;
                        const result = [];
                        psInp.SetProperty('ProcessName', 'RI CDC Handle Problem Link Process');
                        psInp.SetProperty('Object Id', UserId ? UserId : '0-1');
                        psInp.SetProperty('Request1Id', request1Id);
                        for (let link = 0; link < params.length; link++) {
                            operation = params[link]['select'] === true ? 'Add' : 'Delete';
                            request2Id = params[link]['appealId'];
                            psInp.SetProperty('Operation', operation);
                            psInp.SetProperty('Request2Id', request2Id);
                            psOut = serviceWF.InvokeMethod('RunProcess', psInp);
                            result.push({ id: request2Id, result: psOut.childArray[0].propArray["Result"] });
                        }
                        const data = this.GetRequestList(page, 25, "N", accountId);
                        DataManager.add(eventName, {
                            pathEvent: 'data',
                            value: data.data,
                        });
                    };
                    if (activeViewName === 'RI CDC All Request List View') {
                        const div = $('#_swecontent div[title-preserved]')[1];
                        div.id = 'reload-box';
                        SiebelAppFacade.HistoryAppealsShow('reload-box');
                        SiebelAppFacade.HistoryAppealsPageShow(data);
                    } else if (activeViewName === 'RI CDC Request History Detail View') {
                        SiebelAppFacade.AppealTabsHistoryAppealsShow(data);
                    }
                    const top = SiebelApp.S_App.GetProfileAttr('CDCTop');
                    if (top !== "") {
                        SiebelApp.S_App.SetProfileAttr('CDCTop', "");
                        setTimeout(() => {
                            $('div#_sweview').scrollTop(top)
                        }, 200);
                    }
                    // Add code here that should happen after default processing
                }

                RICDCRequestListAppletPR.prototype.BindData = function (bRefresh) {
                    // BindData is called each time the data set changes.
                    // This is where you'll bind that data to user interface elements you might have created in ShowUI
                    // Add code here that should happen before default processing
                    //SiebelJS.Log(this.GetPM().Get("GetName")+": RICDCRequestListAppletPR:      BindData method reached.");
                    SiebelAppFacade.RICDCRequestListAppletPR.superclass.BindData.apply(this, arguments);
                    // Add code here that should happen after default processing
                }

                RICDCRequestListAppletPR.prototype.BindEvents = function () {
                    // BindEvents is where we add UI event processing.
                    // Add code here that should happen before default processing
                    //SiebelJS.Log(this.GetPM().Get("GetName")+": RICDCRequestListAppletPR:      BindEvents method reached.");
                    SiebelAppFacade.RICDCRequestListAppletPR.superclass.BindEvents.apply(this, arguments);
                    // Add code here that should happen after default processing
                }

                RICDCRequestListAppletPR.prototype.EndLife = function () {
                    // EndLife is where we perform any required cleanup.
                    // Add code here that should happen before default processing
                    //SiebelJS.Log(this.GetPM().Get("GetName")+": RICDCRequestListAppletPR:      EndLife method reached.");
                    SiebelAppFacade.RICDCRequestListAppletPR.superclass.EndLife.apply(this, arguments);
                    // Add code here that should happen after default processing
                }

                return RICDCRequestListAppletPR;
            }()
            );
            return "SiebelAppFacade.RICDCRequestListAppletPR";
        })
}