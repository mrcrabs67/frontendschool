if (typeof SiebelAppFacade.RICDCPreload === 'undefined') {
    Namespace('SiebelAppFacade.RICDCPreload');
    define('siebel/custom/cdc/RICDCPreload', [
        'siebel/custom/cdc/dist/app',
        'siebel/custom/cdc/dist/cdc-vendor',
        'siebel/custom/cdc/cdc-utils',
    ], (function () {
        const getSysPref = (name) => {
            const serviceWF = SiebelApp.S_App.GetService('Workflow Process Manager');
            const psInp = SiebelApp.S_App.NewPropertySet();
            let psOut = SiebelApp.S_App.NewPropertySet();
            psInp.SetProperty('ProcessName', 'RI CDC Get System Preference');
            psInp.SetProperty('Name', name);
            psOut = serviceWF.InvokeMethod('RunProcess', psInp);

            const value = psOut.childArray[0].propArray['Value']
            return value;
        }

        function goToAccountDetails(event) {
            console.log(event.data);
            const eventName = event?.data?.event;
            const message = event?.data?.message;
            const URL = document.URL;
            let cliendId = '';
            if (eventName === 'openClientData') {
                cliendId = String(message?.clientId);
            }
            console.log(cliendId);
            /*             if (URL.indexOf(cliendId) > -1 && URL.indexOf('View=Account+Detail+-+Company+Details+1+View') > -1) {
                            return;
                        } */


            SiebelApp.S_App.uiStatus.Busy({ mask: !0 });

            const serviceWF = SiebelApp.S_App.GetService('Workflow Process Manager');
            const psInp = SiebelApp.S_App.NewPropertySet();
            psInp.SetProperty('ProcessName', 'RBRU Go To View');
            psInp.SetProperty('View Name', 'Account Detail - Company Details 1 View');
            psInp.SetProperty('BO Name', 'Account');
            psInp.SetProperty('BC Name', 'Account');
            psInp.SetProperty('Entity Id', cliendId);

            serviceWF.InvokeMethod('RunProcess', psInp);

            setTimeout('SiebelApp.S_App.uiStatus.Free(true)', 5000);
        }

        function OnPreloadCDC() {
            try {
                const activeViewName = SiebelApp.S_App.GetProfileAttr('ActiveViewName');
                const ConnectError = 'Произошла ошибка подключения к Avaya';
                const URL = document.URL;
                if (URL.indexOf('fins_cdc') === -1) {
                    $('body').addClass('fins');
                }

                //


                if ((activeViewName.indexOf('RI CDC') == -1)) {
                    SiebelApp.S_App.SetProfileAttr("canInvokeBack", "false");
                }
                else {
                    SiebelApp.S_App.SetProfileAttr("canInvokeBack", "true");
                }

                //window.removeEventListener('message', goToAccountDetails);

                if (
                    activeViewName.indexOf('RI CDC') > -1 &&
                    URL.indexOf('fins_cdc') > -1
                ) {
                    $('head script[data-requiremodule="siebel/custom/retail"]').remove();
                    $('head script[data-requiremodule="siebel/custom/vendor"]').remove();
                    $('head script[src*="retail"]').remove();
                    $('head script[src*="RIToggleTaskPanePW"]').remove();
                    $('head script[src*="RRIReactCollection"]').remove();
                    $('head script[src*="/SME/"]').remove();
                    $('head script[src*="/SSC/"]').remove();
                    //
                    /*const $div = $('body > div#_sweclient div#cdc_body_show + div');
                    if($div.attr('style') !== ''){
                      $div.attr('style','');
                    }*/

                    let DataManager;
                    let OldConfirmFn = SiebelApp.Utils.Confirm;
                    SiebelApp.Utils.Confirm = () => { };
                    const FirstLoad = SiebelApp.S_App.GetProfileAttr('CDCFirstLoad');
                    if (FirstLoad != 'N') {
                        DataManager = SiebelAppFacade.Events();
                        SiebelApp.S_App.SetProfileAttr('CDCFirstLoad', 'N');
                    }
                    $('#_swecontent').css('border', 'none');
                    if (SiebelAppFacade.DMPL) DataManager = SiebelAppFacade.DMPL;
                    else DataManager = SiebelAppFacade.Events();
                    if (typeof SiebelAppFacade.DMPL === 'undefined')
                        SiebelAppFacade.DMPL = DataManager;

                    const options = {
                        goToBackDisabled: true,
                    }

                    DataManager.add('header', {
                        pathEvent: 'options',
                        value: options,
                    });

                    function cleaning() {
                        const mini_nav = document.getElementById('s_vctrl_div');
                        if (mini_nav) {
                            mini_nav.style.display = 'none';
                        }
                        const sweappmenu = document.getElementById('_sweappmenu');
                        if (sweappmenu) {
                            sweappmenu.style.display = 'none';
                        }

                        const swethreadbar = document.getElementById('_swethreadbar');
                        if (swethreadbar) {
                            swethreadbar.style.display = 'none';
                        }

                        const swescrnbar = document.getElementById('_swescrnbar');
                        if (swescrnbar) {
                            swescrnbar.style.display = 'none';
                        }

                        const siebuiViewMultiColumn = document.getElementById(
                            'siebui-view-multi-column',
                        );
                        if (siebuiViewMultiColumn) {
                            siebuiViewMultiColumn.style.display = 'none';
                        }

                        const siebuiButtonToolbar = document.querySelector(
                            'div.siebui-button-toolbar',
                        );
                        if (siebuiButtonToolbar) {
                            siebuiButtonToolbar.style.display = 'none';
                        }
                        $('#_sweclient').children()[1].setAttribute('class', 'forcehide');
                    }

                    //cleaning();

                    const footerItems = [
                        {
                            id: 1,
                            icon: 'Settings',
                            title: 'Настройки',
                            onClick: () =>
                                SiebelApp.S_App.GotoView('RI CDC All Request List View'),
                        },
                        {
                            id: 2,
                            icon: 'ChartPie',
                            title: 'Отчеты',
                            onClick: () =>
                                SiebelApp.S_App.GotoView('RI CDC All Request List View'),
                        },
                    ];

                    const menuItems = [
                        {
                            id: 6,
                            active: false,
                            icon: 'Home',
                            title: 'Домой',
                            onClick: () => SiebelApp.S_App.GotoView('RI CDC HomePage View'),
                        },
                        /*{
                          id: 1,
                          active: false,
                          icon: 'CallOut',
                          title: 'Обзвон',
                          onClick: () =>
                            SiebelApp.S_App.GotoView('RI CDC All Request List View'),
                        },*/
                        {
                            id: 2,
                            active: false,
                            icon: 'Retry2',
                            title: 'История',
                            onClick: () =>
                                SiebelApp.S_App.GotoView('RI CDC All Request List View'),
                        },
                        /*{
                            id: 3,
                            active: false,
                            icon: 'People1',
                            title: 'Позвонить',
                            onClick: () => {
                                let phoneNumber = prompt('Введите номер телефона');
                                const res = phoneNumber.match(/\D/);
                                if (res === null || res[0] === '+') {
                                    phoneNumber = phoneNumber.replace(/^\+7/, '08');
                                    const ser = SiebelApp.S_App.GetService("Communications Client");
                                    const inPropSet = SiebelApp.S_App.NewPropertySet();
                                    inPropSet.SetProperty('NewCallPhone', phoneNumber);
                                    ser.InvokeMethod('RRIOUIMakeCallToPhone', inPropSet);
                                }
                            },
                        },*/
                        /*{
                          id: 3,
                          active: false,
                          icon: 'Rating',
                          title: 'Топ тикетов',
                          onClick: () =>
                            SiebelApp.S_App.GotoView('RI CDC All Request List View'),
                        },
                        {
                          id: 4,
                          active: false,
                          icon: 'People1',
                          title: 'Контакты',
                          onClick: () =>
                            SiebelApp.S_App.GotoView('RI CDC All Request List View'),
                        },
                        {
                          id: 5,
                          active: false,
                          icon: 'Education',
                          title: 'База знаний',
                          onClick: () =>
                            SiebelApp.S_App.GotoView('RI CDC All Request List View'),
                        },*/
                    ];




                    /* function beforeunload(){
                        SiebelApp.S_App.SetProfileAttr("eventListenerExist", "false");
                        window.alert("asdf");
                    } */

                    //                     if (getEventListeners(window).message.find(({listener}) => listener.name === 'goToAccountDetails')) {
                    //                           window.addEventListener('message', goToAccountDetails);
                    // }
                    // document.addEventListener("DOMContentLoaded", function () {
                    //     //if IsRefresh cookie exists
                    //     console.log('refresh');
                    // });

                    /*                     let eventListenerExist = SiebelApp.S_App.GetProfileAttr("eventListenerExist");
                                        if (eventListenerExist != 'true') {
                                            window.addEventListener('message', goToAccountDetails);
                                            SiebelApp.S_App.SetProfileAttr("eventListenerExist", "true");
                                            window.addEventListener("beforeunload", beforeunload);
                                        } */
                    window.addEventListener('message', goToAccountDetails);

                    SiebelAppFacade.BodyShow('_sweclient');
                    if ($('#content-box').children('#_swecontent').length < 1) {
                        const cont_el = $('#_swecontent').detach();
                        cont_el.appendTo('#content-box');
                        cont_el.height('100%');
                    }

                    const onToHome = () => {
                        SiebelApp.S_App.GotoView('RI CDC HomePage View');
                    };

                    SiebelAppFacade.SidebarShow({
                        elementId: 'sidebar-box',
                        menuItems,
                        footerItems: [],
                        onToHome,
                        collapsed: true,
                    });

                    const onLogout = () => {
                        SiebelApp.S_App.LogOff();
                    };
                    const onSettings = () => {
                        SiebelApp.S_App.GotoView('User Profile CTI View');
                    };
                    const GetReady = function (EventName) {
                        let buttonName = 'RRIOUICommAgentAvailable';
                        if (EventName == 'RRIOUIAgentAvailable') {
                            buttonName = 'noCheck';
                        }
                        let Result = SiebelAppFacade.CTI(
                            'RRIOUIAgentAvailable',
                            buttonName,
                        ); //"RRIOUICommAgentAvailable"
                        SiebelAppFacade.DMPL.add('changeReadyStatus', false);
                        if (Result == -1) {
                            //SiebelAppFacade.CTI("RICDCSignOff","RI CDC Sign Off");
                            DataManager.add('isErrorConnect', {
                                text: ConnectError,
                            });
                            DataManager.add('changeCurrentStatus', 15);
                            SiebelApp.S_App.SetProfileAttr('CDCCTIStatus', 15);
                        } else {
                            DataManager.add('changeCurrentStatus', 16);
                            SiebelApp.S_App.SetProfileAttr('CDCCTIStatus', 16);
                        }
                    };
                    const getPromiseFromEvent = function (item, event) {
                        return new Promise((resolve) => {
                            const listener = () => {
                                item.removeEventListener(event, listener);
                                resolve(event);
                            };
                            item.addEventListener(event, listener);
                            if (event == 'RRIOUIAgentAvailable' || event == 'RICDCSignOn') {
                                setTimeout(resolve, 7000, event + ' timeout');
                            }
                        });
                    };


                    const OutboundCallConnect = function (Phone, teamCode = '') {
                        SiebelApp.S_App.SetProfileAttr("CTI Request Id Out", "");
                        const serviceWF = SiebelApp.S_App.GetService('Workflow Process Manager');
                        const psInp = SiebelApp.S_App.NewPropertySet();
                        let psOut = SiebelApp.S_App.NewPropertySet();
                        psInp.SetProperty('ProcessName', 'RI CDC CTI OutboundCallConnect');
                        psInp.SetProperty('PhoneNumber', Phone);
                        let add_phone_number = '';
                        if (teamCode == 'RI CDC VK Corp' || teamCode == 'RI CDC TB Corp') { //ARM-477
                            add_phone_number = Phone;
                        }
                        psInp.SetProperty('add_phone_number', add_phone_number);
                        psOut = serviceWF.InvokeMethod('RunProcess', psInp);
                    }

                    
                    const formattedTracking = (trackingId) => {
                        let newtrackingid = String(trackingId);
                        const cut = trackingId.indexOf(':');
                        newtrackingid = trackingId.slice(0, cut);
                        return newtrackingid;
                    }
                    
                    const ClientSearch = function (Phone) {

                        const OrgList = [];
                        const NamesList = [];
                        let companyGroup = '';
                        let clientCategory = '';
                        const organizations = []

                        const time = new Date();

                        SiebelApp.S_App.SetProfileAttr("CDCAccountId", "");
                        SiebelApp.S_App.SetProfileAttr("FoundCompId", "");
                        SiebelApp.S_App.SetProfileAttr("NeedOpenFlg", "");
                        SiebelApp.S_App.SetProfileAttr("Identified", "N");//CDR-3360
                        const serviceWF = SiebelApp.S_App.GetService('Workflow Process Manager');
                        const psInp = SiebelApp.S_App.NewPropertySet();
                        let psOut = SiebelApp.S_App.NewPropertySet();
                        psInp.SetProperty('ProcessName', 'RI CDC Search Client Process');
                        psInp.SetProperty('sPhoneNum', Phone);
                        psOut = serviceWF.InvokeMethod('RunProcess', psInp);
                        const Num = +psOut.childArray[0].propArray.OutNum;
                        console.log('Num', Num);
                        let ResIO = Num > 0 ? psOut.childArray[0].childArray[0].childArray[0].childArray : [];
                        const ArrayLength = ResIO.length;
                        const Res = [];
                        const aAccountId = [];
                        let AccountId = '';
                        let CallerName = '';
                        let CurOrgNameShort = '';
                        let CurFullName = '';
                        let CurAccountId = '';
                        let inn = '';
                        let cnum = '';


                        if (Num > 0) {
                            SiebelApp.S_App.SetProfileAttr("Identified", "Y");
                            for (let i = 0; i < ArrayLength; i++) {
                                Res.push(ResIO[i].propArray);
                                CurOrgNameShort = Res[i]['Client Name'];//new 
                                //CurOrgNameShort = Res[i]['RI Client Name Short'];
                                CurFullName = Res[i]['RI Contact Person Name'];//new 
                                //CurFullName = Res[i]['RI Full Name'];
                                CurAccountId = Res[i]['Parent Id'];//new
                                //CurAccountId = Res[i]['Account Id'];
                                //inn = Res[i]['inn'];
                                if (Res[i].hasOwnProperty('inn')) inn = Res[i]['inn'];
                                //cnum = Res[i]['cnum'];
                                if (Res[i].hasOwnProperty('cnum')) cnum = Res[i]['cnum'];

                                if (OrgList.indexOf(CurOrgNameShort) == -1) OrgList.push(CurOrgNameShort ? CurOrgNameShort : '');
                                if (NamesList.indexOf(CurFullName) == -1) NamesList.push(CurFullName ? CurFullName : '');
                                if (aAccountId.indexOf(CurAccountId) == -1) aAccountId.push(CurAccountId ? CurAccountId : '');//RUAVSVA 01.04.2022 CDR - 3073
                                if (aAccountId !== "") organizations.push({
                                    "name": CurOrgNameShort ? CurOrgNameShort : '',
                                    "id": CurAccountId ? CurAccountId : '',
                                    "inn": inn ? inn : '',
                                    "cnum": cnum ? cnum : '',
                                });
                            }
                            if (Num == 1) {
                                AccountId = Res[0]['Parent Id'];//new 
                                //AccountId = Res[0]['Account Id'];
                                SiebelApp.S_App.SetProfileAttr('CDCAccountId', AccountId);
                                CallerName = Res[0]['RI Contact Person Name'];//new 
                                //CallerName = Res[0]['RI Full Name'];

                                SiebelApp.S_App.SetProfileAttr('CDCCallerName', CallerName);
                            }
                            companyGroup = Res[0]['GCC Id'];//new 
                            //companyGroup = Res[0]['RI GCC'];
                            clientCategory = Res[0]['RI CDC Client Category'];//new 
                            //clientCategory = Res[0]['RI_CDC_Client_Category'];

                            /***************************************************¶
                             RUAVSVA 01.04.2022 CDR - 3073
                             ***************************************************/
                            let profile = SiebelApp.S_App.GetProfileAttr('FoundCompId');
                            for (i = 0; i < 100 && i < aAccountId.length; i++) {
                                profile += aAccountId[i] + ';';
                            }
                            SiebelApp.S_App.SetProfileAttr('FoundCompId', profile);
                            SiebelApp.S_App.SetProfileAttr('NeedOpenFlg', 'Y');//RUAVSVA 17.04.2022 CDR-3074

                            /***************************************************
                             RUAVSVA 01.04.2022 CDR - 3073
                             ***************************************************/
                        } else {
                            SiebelApp.S_App.SetProfileAttr("Identified", "N");
                            SiebelApp.S_App.SetProfileAttr('NeedOpenFlg', 'Y');//RUAVSVA 17.04.2022 CDR-3074

                        }

                        //Формируем объект с данными организации
                        const data = {}
                        const outgoingCallTime = time.toLocaleTimeString("ru-RU", { "hour12": false });
                        data["outgoingCallTime"] = outgoingCallTime;
                        data["phone"] = Phone;
                        if (OrgList.length > 0) data["organizations"] = OrgList;
                        if (NamesList.length > 0) data["fio"] = NamesList;
                        if (companyGroup != "") data["companyGroup"] = companyGroup;
                        if (clientCategory != "") data["clientCategory"] = clientCategory;

                        let login = SiebelApp.S_App.GetProfileAttr('Login Name');
                        login = login.toLowerCase();
                        let trackingId = SiebelApp.S_App.GetProfileAttr("CTI TrackingID");
                        trackingId = formattedTracking(trackingId);
                        dataSend = {
                            "event": "item",
                            "topic": "outgoingCall",
                            "service": "siebel",
                            "message": {
                                "item": {
                                    "login": login,
                                    "phone": Phone,
                                    "organizations": organizations,
                                    "fio": NamesList,
                                    "outgoingCallTime": outgoingCallTime,
                                    "companyGroup": companyGroup,
                                    "clientCategory": clientCategory,
                                    "trackingId": trackingId,
                                }
                            }
                        }
                        return dataSend;
                    }

                    let SetProfileAttr = (name, value) => {
                        SiebelApp.S_App.SetProfileAttr(name, value);
                    }

                    const StatusChange = function (value, Buttons, currentStatusProfile, eventListenerFlg, ws = false) {
                        let Error = false;
                        let Res = 0;
                        let Result;
                        switch (value) {
                            case 15: //Not Ready
                                let t1 = Buttons['RI CDC Sign Off'].m_state;
                                let t2 = Buttons['RI CDC Sign On'].m_state;

                                if (Buttons['RI CDC Sign Off'].m_state == 'enabled') {// && Buttons['RI CDC Sign On'].m_state == 'disabled') {
                                    console.log("Можем поменять статус на не готов")
                                    Res = SiebelAppFacade.CTI('RICDCSignOff', 'RI CDC Sign Off');
                                    if (Res == -1) {
                                        DataManager.add('changeCurrentStatus', currentStatusProfile);
                                        Error = true;
                                    }
                                }

                                SiebelApp.S_App.SetProfileAttr('CDCCTIStatus', 15);
                                SiebelApp.S_App.SetProfileAttr('futureStatus', "");
                                let CDCCTIPostponedStatus = SiebelApp.S_App.GetProfileAttr('CDCCTIPostponedStatus', '');

                                if (ws && CDCCTIPostponedStatus == '') {
                                    DataManager.add('changeCurrentStatus', value);
                                    const response = {
                                        "topic": "userStatus",
                                        "event": "item",
                                        "message": {
                                            "item": {
                                                "statusCode": value,
                                                "changedAfterCall": "0"
                                            }
                                        }
                                    };
                                    SiebelAppFacade.Send(response);
                                }

                                break;

                            case 16: //Ready
                                const Buthr = SiebelAppFacade.GetAllButtons
                                    ? SiebelAppFacade.GetAllButtons(SiebelAppFacade.CTIPR)
                                    : [];

                                    /*if(Buthr['RI CDC GetEDUData'].m_state == 'enabled') {console.log('Меняем на готов')}
                                    else */if (Buthr['RI CDC Sign Off'].m_state == 'disabled' && Buthr['RI CDC Sign On'].m_state == 'disabled') {
                                    DataManager.add('isErrorConnect', {
                                        text: 'Проблема с интернет - соединением. Пожалуйста, перезагрузите страницу',
                                    });
                                    DataManager.add('changeCurrentStatus', currentStatusProfile);

                                    if (ws) {
                                        const responseError = {
                                            "topic": "error",
                                            "event": "userStatusChange",
                                            "message": {
                                                "text": "Произошла ошибка, статус в Avaya не изменен. Проблема с интернет - соединением"
                                            }
                                        };

                                        const response = {
                                            "topic": "userStatus",
                                            "event": "item",
                                            "message": {
                                                "item": {
                                                    "statusCode": currentStatusProfile,
                                                    "changedAfterCall": "0"
                                                }
                                            }
                                        };

                                        SetProfileAttr('CDCCTIPostponedStatus', '');
                                        SiebelAppFacade.Send(responseError);
                                        SiebelAppFacade.Send(response);
                                    }


                                    break;
                                }

                                //let countChange = 1;
                                if (currentStatusProfile === value) {
                                    DataManager.add('isErrorConnect', {
                                        text: 'Такой статус уже установлен',
                                    });

                                    // const response = {
                                    //     "topic": "error",
                                    //     "event": "userStatusChange",
                                    //     "message": {
                                    //         "text": "Произошла ошибка, статус в Avaya не изменен"
                                    //     }
                                    // };

                                    // if (ws) SiebelAppFacade.Send(response);

                                    break;
                                }

                                if (Buttons['RI CDC Sign Off'].m_state == 'disabled' && Buttons['RI CDC Sign On'].m_state == 'enabled') {
                                    console.log("Входим в CTI");

                                    Res = SiebelAppFacade.CTI('RICDCSignOn', 'RI CDC Sign On');//Войти в CTI

                                    if (Res == -1) {
                                        DataManager.add('changeCurrentStatus', currentStatusProfile);
                                        Error = true;

                                        DataManager.add('isErrorConnect', {
                                            text: 'Не получилось войти в CTI. Проверьте Avaya и попробуйте снова',
                                        });

                                        if (ws) {
                                            SetProfileAttr('CDCCTIPostponedStatus', '');
                                            const responseError = {
                                                "topic": "error",
                                                "event": "userStatusChange",
                                                "message": {
                                                    "text": "Произошла ошибка, статус в Avaya не изменен"
                                                }
                                            };

                                            const response = {
                                                "topic": "userStatus",
                                                "event": "item",
                                                "message": {
                                                    "item": {
                                                        "statusCode": currentStatusProfile,
                                                        "changedAfterCall": "0"
                                                    }
                                                }
                                            };

                                            SiebelAppFacade.Send(responseError);
                                            SiebelAppFacade.Send(response);

                                        }

                                        break;
                                    }
                                }





                                const promise = new Promise((resolve, reject) => {

                                    const IntId = setInterval(() => {
                                        const But = SiebelAppFacade.GetAllButtons
                                            ? SiebelAppFacade.GetAllButtons(SiebelAppFacade.CTIPR)
                                            : [];

                                        if ((But['RI CDC Sign Off'].m_state == 'enabled' && But['RI CDC Sign On'].m_state == 'disabled')) {
                                            clearInterval(IntId);
                                            resolve(true);
                                        }
                                    }, 800);

                                });

                                // eslint-disable-next-line no-void
                                void promise.then((result) => {
                                    console.log('res');

                                    const ButAvaya = SiebelAppFacade.GetAllButtons
                                        ? SiebelAppFacade.GetAllButtons(SiebelAppFacade.CTIPR)
                                        : [];

                                    if (ButAvaya['RRIOUICommAgentAvailable'].m_state == 'disabled') //Если мы не вошли в Avaya
                                    {
                                        DataManager.add('changeCurrentStatus', currentStatusProfile);
                                        Error = true;

                                        DataManager.add('isErrorConnect', {
                                            text: 'Не получилось войти в Avaya',
                                        });

                                        if (ws) {
                                            SetProfileAttr('CDCCTIPostponedStatus', '');
                                            const responseError = {
                                                "topic": "error",
                                                "event": "userStatusChange",
                                                "message": {
                                                    "text": "Произошла ошибка, статус в Avaya не изменен"
                                                }
                                            };

                                            const response = {
                                                "topic": "userStatus",
                                                "event": "item",
                                                "message": {
                                                    "item": {
                                                        "statusCode": currentStatusProfile,
                                                        "changedAfterCall": "0"
                                                    }
                                                }
                                            };

                                            SiebelAppFacade.Send(responseError);
                                            SiebelAppFacade.Send(response);

                                        }

                                        return;
                                    }

                                    const But = SiebelAppFacade.GetAllButtons
                                        ? SiebelAppFacade.GetAllButtons(SiebelAppFacade.CTIPR)
                                        : [];

                                    Result = SiebelAppFacade.CTI('RRIOUIAgentAvailable', 'RRIOUICommAgentAvailable',);
                                    if (Result !== -1) { //Входим в готов
                                        //DataManager.add('changeCurrentStatus', 16);
                                        SiebelApp.S_App.SetProfileAttr('CDCCTIStatus', 16);
                                        SiebelApp.S_App.SetProfileAttr('futureStatus', "");
                                        let CDCCTIPostponedStatus = SiebelApp.S_App.GetProfileAttr('CDCCTIPostponedStatus');

                                        if (ws && CDCCTIPostponedStatus == '') {
                                            const response = {
                                                "topic": "userStatus",
                                                "event": "item",
                                                "message": {
                                                    "item": {
                                                        "statusCode": value,
                                                        "changedAfterCall": "0"
                                                    }
                                                }
                                            };
                                            SiebelAppFacade.Send(response);

                                        }

                                        return;
                                    } else {
                                        DataManager.add('changeCurrentStatus', currentStatusProfile);
                                    }



                                    if (But['Agent State For Work Item'].m_state == 'enabled') {
                                        //actual status = ready
                                        Result = SiebelAppFacade.CTI('RRIOUIAgentAvailable', 'RRIOUICommAgentAvailable');
                                        if (Result !== -1) {
                                            //DataManager.add('changeCurrentStatus', 16);
                                            SiebelApp.S_App.SetProfileAttr('CDCCTIStatus', 16);
                                            SiebelApp.S_App.SetProfileAttr('futureStatus', "");
                                            let CDCCTIPostponedStatus = SiebelApp.S_App.GetProfileAttr('CDCCTIPostponedStatus');

                                            //Успешно встали в готов. Теперь пошлем wss сообщение, если нужно
                                            if (ws && CDCCTIPostponedStatus == '') {
                                                const response = {
                                                    "topic": "userStatus",
                                                    "event": "item",
                                                    "message": {
                                                        "item": {
                                                            "statusCode": value,
                                                            "changedAfterCall": "0"
                                                        }
                                                    }
                                                };
                                                SiebelAppFacade.Send(response);

                                            }

                                            return;
                                        } else { //Не смогли встать в готов
                                            DataManager.add('changeCurrentStatus', currentStatusProfile);
                                            SiebelApp.S_App.SetProfileAttr('futureStatus', '');
                                            if (ws) {
                                                SetProfileAttr('CDCCTIPostponedStatus', '');
                                                const responseError = {
                                                    "topic": "error",
                                                    "event": "userStatusChange",
                                                    "message": {
                                                        "text": "Произошла ошибка, статус в Avaya не изменен"
                                                    }
                                                };

                                                const response = {
                                                    "topic": "userStatus",
                                                    "event": "item",
                                                    "message": {
                                                        "item": {
                                                            "statusCode": currentStatusProfile,
                                                            "changedAfterCall": "0"
                                                        }
                                                    }
                                                };

                                                SiebelAppFacade.Send(responseError);
                                                SiebelAppFacade.Send(response);

                                            }
                                            //countChange = countChange + 1;
                                        }
                                    }

                                });
                                break;
                            //RI CDC Hangup Call && RI CDC GetEDUData
                            default: //Break

                                const Buthrr = SiebelAppFacade.GetAllButtons
                                    ? SiebelAppFacade.GetAllButtons(SiebelAppFacade.CTIPR)
                                    : [];
                                if (Buthrr['RI CDC Sign Off'].m_state == 'disabled' && Buthrr['RI CDC Sign On'].m_state == 'disabled' && Buthrr['Agent State For Work Item'].m_state == 'disabled'
                                    && Buthrr['RI CDC Hangup Call'].m_state == 'disabled' && Buthrr['RI CDC GetEDUData'].m_state == 'disabled') {
                                    DataManager.add('isErrorConnect', {
                                        text: 'Проблема с интернет - соединением. Пожалуйста, перезагрузите страницу',
                                    });
                                    DataManager.add('changeCurrentStatus', 15);

                                    if (ws) {
                                        const responseError = {
                                            "topic": "error",
                                            "event": "userStatusChange",
                                            "message": {
                                                "text": "Произошла ошибка, статус в Avaya не изменен. Проблема с интернет - соединением"
                                            }
                                        };

                                        const response = {
                                            "topic": "userStatus",
                                            "event": "item",
                                            "message": {
                                                "item": {
                                                    "statusCode": 15,
                                                    "changedAfterCall": "0"
                                                }
                                            }
                                        };

                                        SetProfileAttr('CDCCTIPostponedStatus', '');
                                        SiebelAppFacade.Send(responseError);
                                        SiebelAppFacade.Send(response);
                                    }

                                    break;
                                }

                                if (currentStatusProfile === value) {
                                    DataManager.add('isErrorConnect', {
                                        text: 'Такой статус уже установлен',
                                    });

                                    // const response = {
                                    //     "topic": "error",
                                    //     "event": "userStatusChange",
                                    //     "message": {
                                    //         "text": "Произошла ошибка, статус в Avaya не изменен"
                                    //     }
                                    // };

                                    // if (ws) SiebelAppFacade.Send(response);

                                    break;
                                }

                                let continueFlag = null;
                                let statusType = null;

                                /*if ($('#header-box [class^=Selectstyles__Current]').text() ===
                                    'Не готов'
                                ) */
                                if (Buthrr['RI CDC Sign On'].m_state == 'enabled' && Buthrr['RI CDC Sign Off'].m_state == 'disabled') {
                                    if (Buttons['RI CDC Sign Off'].m_state == 'disabled' && Buttons['RI CDC Sign On'].m_state == 'enabled') {
                                        console.log("Входим в CTI для перехода в перерыв");

                                        Res = SiebelAppFacade.CTI('RICDCSignOn', 'RI CDC Sign On');//Войти в CTI

                                        if (Res == -1) {
                                            DataManager.add('changeCurrentStatus', 15);

                                            Error = true;

                                            DataManager.add('isErrorConnect', {
                                                text: 'Avaya Conection Error',
                                            });

                                            console.log("Не получилось войти в CTI");

                                            if (ws) {
                                                const responseError = {
                                                    "topic": "error",
                                                    "event": "userStatusChange",
                                                    "message": {
                                                        "text": "Произошла ошибка, статус в Avaya не изменен"
                                                    }
                                                };

                                                const response = {
                                                    "topic": "userStatus",
                                                    "event": "item",
                                                    "message": {
                                                        "item": {
                                                            "statusCode": currentStatusProfile,
                                                            "changedAfterCall": "0"
                                                        }
                                                    }
                                                };

                                                SetProfileAttr('CDCCTIPostponedStatus', '');
                                                SiebelAppFacade.Send(responseError);
                                                SiebelAppFacade.Send(response);
                                            }

                                            break;
                                        }
                                    }


                                    //Проверяем Avaya
                                    setTimeout(() => {
                                        const ButAv = SiebelAppFacade.GetAllButtons
                                            ? SiebelAppFacade.GetAllButtons(SiebelAppFacade.CTIPR)
                                            : [];
                                        if (ButAv['RRIOUICommAgentAvailable'].m_state == 'disabled') {
                                            DataManager.add('changeCurrentStatus', currentStatusProfile);
                                            DataManager.add('isErrorConnect', {
                                                text: 'Не получилось войти в Avaya',
                                            });
                                            Res = SiebelAppFacade.CTI('RICDCSignOff', 'RI CDC Sign Off');

                                            if (ws) {
                                                const responseError = {
                                                    "topic": "error",
                                                    "event": "userStatusChange",
                                                    "message": {
                                                        "text": "Произошла ошибка, статус в Avaya не изменен"
                                                    }
                                                };

                                                const response = {
                                                    "topic": "userStatus",
                                                    "event": "item",
                                                    "message": {
                                                        "item": {
                                                            "statusCode": currentStatusProfile,
                                                            "changedAfterCall": "0"
                                                        }
                                                    }
                                                };

                                                SetProfileAttr('CDCCTIPostponedStatus', '');
                                                SiebelAppFacade.Send(responseError);
                                                SiebelAppFacade.Send(response);
                                            }

                                            return;
                                        }
                                    }, 4000);

                                    ///Promise
                                    const promise = new Promise((resolve, reject) => {

                                        const IntId = setInterval(() => {
                                            const But = SiebelAppFacade.GetAllButtons
                                                ? SiebelAppFacade.GetAllButtons(SiebelAppFacade.CTIPR)
                                                : [];

                                            if ((But['RI CDC Sign Off'].m_state == 'enabled' && But['RI CDC Sign On'].m_state == 'disabled' && But['RRIOUICommAgentAvailable'].m_state == 'enabled')) {
                                                clearInterval(IntId);
                                                resolve(true);
                                            }
                                        }, 500);

                                    });

                                    // Если resolve = true
                                    //&& But['RRIOUICommAgentAvailable'].m_state == 'disabled'
                                    void promise.then((result) => {
                                        console.log('resolve Вошли в CTI');

                                        /*//Проверяем Avaya
                                        const ButAv = SiebelAppFacade.GetAllButtons
                                                ? SiebelAppFacade.GetAllButtons(SiebelAppFacade.CTIPR)
                                                : [];

                                        setTimeout(() => {console.log('timeout')

                                        }, 5000);
                                        if(ButAv['RRIOUICommAgentAvailable'].m_state == 'enabled'){console.log('super')}
                                        else if(ButAv['RRIOUICommAgentAvailable'].m_state == 'disabled')
                                        {
                                            DataManager.add('changeCurrentStatus', currentStatusProfile);
                                            DataManager.add('isErrorConnect', {
                                                text: 'Не получилось войти в Avaya',
                                            });
                                            return;
                                        }
                                        //*/

                                        const Butssss = SiebelAppFacade.GetAllButtons
                                            ? SiebelAppFacade.GetAllButtons(SiebelAppFacade.CTIPR)
                                            : [];

                                        if (Butssss['RRIOUICommAgentAvailable'].m_state == 'disabled') { //Не смогли встать в готов для перехода в перерыв
                                            console.log("disabled");
                                            DataManager.add('changeCurrentStatus', currentStatusProfile);
                                            DataManager.add('isErrorConnect', {
                                                text: 'Не получилось войти в Avaya',
                                            });
                                            if (ws) {
                                                const responseError = {
                                                    "topic": "error",
                                                    "event": "userStatusChange",
                                                    "message": {
                                                        "text": "Произошла ошибка, статус в Avaya не изменен"
                                                    }
                                                };

                                                const response = {
                                                    "topic": "userStatus",
                                                    "event": "item",
                                                    "message": {
                                                        "item": {
                                                            "statusCode": currentStatusProfile,
                                                            "changedAfterCall": "0"
                                                        }
                                                    }
                                                };

                                                SetProfileAttr('CDCCTIPostponedStatus', '');
                                                SiebelAppFacade.Send(responseError);
                                                SiebelAppFacade.Send(response);
                                            }
                                            return;
                                        }
                                        else {
                                            console.log("enabled");
                                            Res = SiebelAppFacade.CTI(
                                                'RRIOUIChangeAuxReasonCode',
                                                'Agent State For Work Item',
                                                value,
                                            );
                                            if (Res !== -1) {
                                                DataManager.add('changeCurrentStatus', value);
                                                SiebelApp.S_App.SetProfileAttr('CDCCTIStatus', value);
                                                let CDCCTIPostponedStatus = SiebelApp.S_App.GetProfileAttr('CDCCTIPostponedStatus');
                                                if (ws && CDCCTIPostponedStatus == '') {
                                                    const response = {
                                                        "topic": "userStatus",
                                                        "event": "item",
                                                        "message": {
                                                            "item": {
                                                                "statusCode": value,
                                                                "changedAfterCall": "0"
                                                            }
                                                        }
                                                    };
                                                    SiebelAppFacade.Send(response);
                                                }
                                            }
                                            else if (Res === -1) {
                                                DataManager.add('changeCurrentStatus', currentStatusProfile);
                                                DataManager.add('isErrorConnect', {
                                                    text: 'Avaya Conection Error',
                                                });

                                                if (ws) {
                                                    const responseError = {
                                                        "topic": "error",
                                                        "event": "userStatusChange",
                                                        "message": {
                                                            "text": "Произошла ошибка, статус в Avaya не изменен"
                                                        }
                                                    };

                                                    const response = {
                                                        "topic": "userStatus",
                                                        "event": "item",
                                                        "message": {
                                                            "item": {
                                                                "statusCode": currentStatusProfile,
                                                                "changedAfterCall": "0"
                                                            }
                                                        }
                                                    };

                                                    SetProfileAttr('CDCCTIPostponedStatus', '');
                                                    SiebelAppFacade.Send(responseError);
                                                    SiebelAppFacade.Send(response);
                                                }

                                            }
                                            return;
                                        }

                                    });
                                    ///
                                }
                                /*else if ($('#header-box [class^=Selectstyles__Current]').text() ===
                                    'Готов'
                                )*/
                                else if (Buthrr['Agent State For Work Item'].m_state == 'enabled' && Buthrr['RRIOUICommAgentAvailable'].m_state == 'disabled' && Buthrr['RI CDC Sign Off'].m_state == 'enabled') {
                                    continueFlag = 1;
                                    statusType = 'Ready';

                                }

                                /*else if ($('#header-box [class^=Selectstyles__Current]').text() !==
                                    'Не готов' || ($('#header-box [class^=Selectstyles__Current]').text() !== 'Готов') && But['RRIOUICommAgentAvailable'].m_state == 'disabled')*/
                                else if (Buthrr['Agent State For Work Item'].m_state == 'enabled' && Buthrr['RRIOUICommAgentAvailable'].m_state == 'enabled' && Buthrr['RI CDC Sign Off'].m_state == 'enabled') {
                                    continueFlag = 1;
                                    statusType = 'Aux';
                                    if (eventListenerFlg) statusType = 'Ready';
                                }
                                else if (Buthrr['Agent State For Work Item'].m_state == 'enabled' && Buthrr['RI CDC Sign Off'].m_state == 'disabled' && Buthrr['RI CDC Hangup Call'].m_state == 'enabled') { //Мы на исходящем
                                    continueFlag = 1;
                                    if (Buthrr['RRIOUICommAgentAvailable'].m_state == 'enabled') statusType = 'Aux';
                                    else statusType = 'Ready';
                                }
                                if (continueFlag === 1) {
                                    if (statusType === 'Ready') {
                                        Res = SiebelAppFacade.CTI(
                                            'RRIOUICommAgentUnavailable',
                                            'Agent State For Work Item',
                                            value,
                                        );
                                        console.log('RRIOUICommAgentUanvailable', Res);
                                    }
                                    else if (statusType === 'Aux') {
                                        Res = SiebelAppFacade.CTI(
                                            'RRIOUIChangeAuxReasonCode',
                                            'Agent State For Work Item',
                                            value,
                                        );
                                        console.log('RRIOUIChangeAuxReasonCode', Res);
                                    }

                                    if (Res !== -1) {
                                        if (SiebelApp.S_App.GetProfileAttr("futureStatus") !== "") {
                                            SiebelApp.S_App.SetProfileAttr("futureStatus", "");
                                        }
                                        SiebelApp.S_App.SetProfileAttr('CDCCTIStatus', value);

                                        if (ws && SiebelApp.S_App.GetProfileAttr('CDCCTIPostponedStatus') == '') {
                                            const response = {
                                                "topic": "userStatus",
                                                "event": "item",
                                                "message": {
                                                    "item": {
                                                        "statusCode": value,
                                                        "changedAfterCall": "0"
                                                    }
                                                }
                                            };
                                            DataManager.add('changeCurrentStatus', value);
                                            SiebelAppFacade.Send(response);
                                        }

                                    }
                                    else {
                                        if (SiebelApp.S_App.GetProfileAttr("futureStatus") !== "") {
                                            SiebelApp.S_App.SetProfileAttr("futureStatus", "");
                                        }
                                        DataManager.add('isErrorConnect', {
                                            text: 'Avaya Conection Error',
                                        });
                                        DataManager.add('changeCurrentStatus', currentStatusProfile);
                                        console.log("Не удалось перейти в перерыв");
                                        Error = true;

                                        if (ws) {
                                            const responseError = {
                                                "topic": "error",
                                                "event": "userStatusChange",
                                                "message": {
                                                    "text": "Произошла ошибка, статус в Avaya не изменен"
                                                }
                                            };

                                            const response = {
                                                "topic": "userStatus",
                                                "event": "item",
                                                "message": {
                                                    "item": {
                                                        "statusCode": currentStatusProfile,
                                                        "changedAfterCall": "0"
                                                    }
                                                }
                                            };

                                            SetProfileAttr('CDCCTIPostponedStatus', '');
                                            SiebelAppFacade.Send(responseError);
                                            SiebelAppFacade.Send(response);
                                        }

                                    }
                                }
                                else if (continueFlag === 0) {
                                    if (SiebelApp.S_App.GetProfileAttr("futureStatus") !== "") {
                                        SiebelApp.S_App.SetProfileAttr("futureStatus", "");
                                    }
                                    DataManager.add('isErrorConnect', {
                                        text: 'Connect Avaya Conection Error',
                                    });
                                    DataManager.add('changeCurrentStatus', currentStatusProfile);
                                    console.log("Не удалось перейти в готов для дальнейшего перехода в перерыв");
                                    Error = true;

                                    if (ws) {
                                        const responseError = {
                                            "topic": "error",
                                            "event": "userStatusChange",
                                            "message": {
                                                "text": "Произошла ошибка, статус в Avaya не изменен"
                                            }
                                        };

                                        const response = {
                                            "topic": "userStatus",
                                            "event": "item",
                                            "message": {
                                                "item": {
                                                    "statusCode": currentStatusProfile,
                                                    "changedAfterCall": "0"
                                                }
                                            }
                                        };

                                        SetProfileAttr('CDCCTIPostponedStatus', '');
                                        SiebelAppFacade.Send(responseError);
                                        SiebelAppFacade.Send(response);
                                    }
                                }
                                break;








                        }
                        //Выход из Switch
                        /*if (!Error) {
                            SiebelApp.S_App.SetProfileAttr('CDCCTIStatus', value);
                        }*/
                    }

                    const onStatusChangeFun = function (value, ws = false) {
                        SetProfileAttr('ws', '');
                        SetProfileAttr('CDCCTIPostponedStatus', '');
                        if (ws === true) SetProfileAttr('ws', 'true');
                        let Error = false;
                        let Res = 0;
                        let Result;
                        if (typeof value == 'string') { value = Number(value); }
                        console.log('typeof = ', typeof value);
                        let currentStatusProfile = Number(SiebelApp.S_App.GetProfileAttr('CDCCTIStatus'));
                        SiebelApp.S_App.SetProfileAttr('futureStatus', "");//RUAVSVA Новая статусная модель

                        const Buttons = SiebelAppFacade.GetAllButtons
                            ? SiebelAppFacade.GetAllButtons(SiebelAppFacade.CTIPR)
                            : [];


                        //EventManager
                        document.removeEventListener('chStatus', handlerStatus);//Удаляем Listener

                        let futureStatus = value;
                        SiebelApp.S_App.SetProfileAttr('futureStatus', futureStatus)

                        function handlerStatus(value) {
                            ///
                            const promiseEvent = new Promise((resolve, reject) => {

                                const IntId = setInterval(() => {
                                    const But = SiebelAppFacade.GetAllButtons
                                        ? SiebelAppFacade.GetAllButtons(SiebelAppFacade.CTIPR)
                                        : [];

                                    if ((But['RI CDC Sign Off'].m_state == 'enabled' && But['RI CDC Sign On'].m_state == 'disabled')) {
                                        clearInterval(IntId);
                                        resolve(true);
                                    }
                                }, 500);

                            });
                            // Если resolve = true
                            void promiseEvent.then((result) => {
                                console.log('Вызов закончился');
                                console.log('new status = ', value);
                                //let fs = SiebelApp.S_App.GetProfileAttr("futureStatus");
                                //StatusChange(value, Buttons, currentStatusProfile, true);
                            });

                            console.log('new status = ', value);
                            StatusChange(value, Buttons, currentStatusProfile, false, ws);
                        }

                        let bActiveCall = SiebelApp.S_App.GetProfileAttr('bActiveCall');

                        //else {
                        if (bActiveCall == "") { //Если в текущий момент звонка нет
                            console.log('Меняем сразу');
                            StatusChange(futureStatus, Buttons, currentStatusProfile, false, ws);
                        }
                        else {
                            SiebelApp.S_App.SetProfileAttr('CDCCTIPostponedStatus', '1');
                            const postponed = {
                                "topic": "userStatus",
                                "event": "postponed",
                                "message": {
                                    "text": "активируется после окончания вызова"
                                }
                            }
                            StatusChange(futureStatus, Buttons, currentStatusProfile, false, ws);
                            //document.addEventListener('chStatus', handlerStatus(value));
                        } //Если идет звонок, то создаем Listener
                    }

                    const onStatusChange = function (value) {
                        onStatusChangeFun(value);
                        /*let Error = false;
                        let Res = 0;
                        let Result;
                        let currentStatusProfile = Number(SiebelApp.S_App.GetProfileAttr('CDCCTIStatus'));
                        SiebelApp.S_App.SetProfileAttr('futureStatus', "");//RUAVSVA Новая статусная модель

                        const Buttons = SiebelAppFacade.GetAllButtons
                            ? SiebelAppFacade.GetAllButtons(SiebelAppFacade.CTIPR)
                            : [];


                        //EventManager
                        document.removeEventListener('chStatus', handlerStatus);//Удаляем Listener

                        let futureStatus = value;
                        SiebelApp.S_App.SetProfileAttr('futureStatus', futureStatus)

                        function handlerStatus(value) {
                            ///
                            const promiseEvent = new Promise((resolve, reject) => {

                                const IntId = setInterval(() => {
                                    const But = SiebelAppFacade.GetAllButtons
                                        ? SiebelAppFacade.GetAllButtons(SiebelAppFacade.CTIPR)
                                        : [];

                                    if ((But['RI CDC Sign Off'].m_state == 'enabled' && But['RI CDC Sign On'].m_state == 'disabled')) {
                                        clearInterval(IntId);
                                        resolve(true);
                                    }
                                }, 500);

                            });
                            // Если resolve = true
                            void promiseEvent.then((result) => {
                                console.log('Вызов закончился');
                                console.log('new status = ', value);
                                //let fs = SiebelApp.S_App.GetProfileAttr("futureStatus");
                                //StatusChange(value, Buttons, currentStatusProfile, true);
                            });

                            console.log('new status = ', value);
                            StatusChange(value, Buttons, currentStatusProfile, false);
                        }

                        let bActiveCall = SiebelApp.S_App.GetProfileAttr('bActiveCall');

                        //else {
                        if (bActiveCall == "") { //Если в текущий момент звонка нет
                            console.log('Меняем сразу');
                            StatusChange(futureStatus, Buttons, currentStatusProfile, false);
                        }
                        else document.addEventListener('chStatus', handlerStatus(value)); //Если идет звонок, то создаем Listener*/
                        // }




                        //StatusChange(value, Buttons, currentStatusProfile);

                        /*switch (value) {
                            case 16: //Ready
                                Result = SiebelAppFacade.CTI(
                                    'RRIOUIAgentAvailable',
                                    'RRIOUICommAgentAvailable',
                                );
                                if(SiebelApp.S_App.GetProfileAttr('bActiveCall') === 'true'){
                                    Error = true;
                                    DataManager.add('changeCurrentStatus', currentStatusProfile);
                                    break;
                                }
                                if(Result !== -1){
                                    DataManager.add('isErrorConnect', { flag: false });
                                    DataManager.add('changeCurrentStatus', 16);
                                    SiebelApp.S_App.SetProfileAttr('CDCCTIStatus', 16);
                                    break;
                                } else {
                                    DataManager.add('changeCurrentStatus', currentStatusProfile);
                                }
                                if (Buttons['Agent State For Work Item'].m_state == 'enabled') {
                                    //actual status = ready
                                    DataManager.add('isErrorConnect', { flag: false });
                                    DataManager.add('changeCurrentStatus', 16);
                                    SiebelApp.S_App.SetProfileAttr('CDCCTIStatus', 16);
                                    break;
                                }
                                if (
                                    $("#header-box span[class^='Badgestyles__Item']").text() != ''
                                ) {
                                    //error is visible
                                    SiebelAppFacade.DMPL.add('changeReadyStatus', true);
                                    if (Buttons['RI CDC Sign On'].m_state == 'disabled') {
                                        //toolbar is enabled
                                        //relog
                                        SiebelAppFacade.CTI('RICDCSignOff', 'RI CDC Sign Off');
                                        const SignOnPromise = getPromiseFromEvent(
                                            document,
                                            'RICDCSignOn',
                                        )
                                            .then((res) => {
                                                SiebelAppFacade.CTI('RICDCSignOn', 'RI CDC Sign On');
                                                return getPromiseFromEvent(
                                                    document,
                                                    'RRIOUIAgentAvailable',
                                                );
                                            })
                                            .then((res) => {
                                                GetReady(res);
                                            });
                                    } else {
                                        SiebelAppFacade.CTI('RICDCSignOn', 'RI CDC Sign On');
                                        getPromiseFromEvent(document, 'RRIOUIAgentAvailable').then(
                                            (res) => {
                                                GetReady(res);
                                            },
                                        );
                                    }
                                } else {
                                    Result = SiebelAppFacade.CTI(
                                        'RICDCSignOn',
                                        'RI CDC Sign On',
                                    );
                                    if (Result == -1)
                                        Result = SiebelAppFacade.CTI(
                                            'RRIOUIAgentAvailable',
                                            'RRIOUICommAgentAvailable',
                                        );
                                    else if (Result == 0) {
                                        SiebelAppFacade.DMPL.add('changeReadyStatus', true);
                                        getPromiseFromEvent(document, 'RRIOUIAgentAvailable').then(
                                            (res) => {
                                                GetReady(res);
                                            },
                                        );
                                    }
                                    if (Result == -1) {
                                        Result = SiebelAppFacade.CTI(
                                            'RICDCSignOff',
                                            'RI CDC Sign Off',
                                        );
                                        if (Result == 0)
                                            getPromiseFromEvent(document, 'RICDCSignOn')
                                                .then((res) => {
                                                    SiebelAppFacade.CTI('RICDCSignOn', 'RI CDC Sign On');
                                                    return getPromiseFromEvent(
                                                        document,
                                                        'RRIOUIAgentAvailable',
                                                    );
                                                })
                                                .then((res) => {
                                                    GetReady(res);
                                                });
                                        else {
                                            DataManager.add('isErrorConnect', {
                                                flag: true,
                                                text: ConnectError,
                                            });
                                            DataManager.add('changeCurrentStatus', 15);
                                            SiebelApp.S_App.SetProfileAttr('CDCCTIStatus', 15);
                                        }
                                    }
                                }
                                break;
                            case 15: //Not Ready
                                Res = SiebelAppFacade.CTI('RICDCSignOff', 'RI CDC Sign Off');
                                if (Res == -1) {
                                    DataManager.add('changeCurrentStatus', currentStatusProfile);
                                    Error = true;
                                }
                                break;
                            default: //Break

                                if (
                                    $('#header-box [class^=Selectstyles__Current]').text() ==
                                    'Готов'
                                )
                                    Res = SiebelAppFacade.CTI(
                                        'RRIOUICommAgentUnavailable',
                                        'Agent State For Work Item',
                                        value,
                                    );
                                else
                                    Res = SiebelAppFacade.CTI(
                                        'RRIOUIChangeAuxReasonCode',
                                        'Agent State For Work Item',
                                        value,
                                    );
                                if (Res == -1) {
                                    DataManager.add('changeCurrentStatus', currentStatusProfile);
                                    Error = true;
                                }
                                break;
                        }
                        if (!Error) {
                            SiebelApp.S_App.SetProfileAttr('CDCCTIStatus', value);
                        }*/
                    };

                    const onCall = () => {
                        console.log('onCall');
                    };


                    //RUAVSVA CDR - 3043

                    function GetCTICDCStatusLOV(teamCode) {
                        const service = SiebelApp.S_App.GetService('RRI OUI Service');
                        let inPropSet = new JSSPropertySet();
                        let outPropSet = new JSSPropertySet();

                        inPropSet.SetProperty('CommName', teamCode);

                        outPropSet = service.InvokeMethod('GetCTICDCStatusLOV', inPropSet);

                        let recordSet;
                        if (outPropSet !== null) {
                            recordSet = outPropSet.childArray[0].childArray;
                        }
                        const Status = [];

                        for (i = 0; i < recordSet.length; i++) {
                            Status.push({
                                name: recordSet[i].propArray.Status,
                                code: +recordSet[i].propArray.Code,
                                design: recordSet[i].propArray.Design,
                                limit: recordSet[i].propArray.Limit,
                            });
                        }
                        return Status;
                    }

                    let teamCode = 'ARM';

                    if (SiebelApp.S_App.GetProfileAttr('RICDCRP')) {
                        teamCode = 'Raifpay';
                    }

                    if (SiebelApp.S_App.GetProfileAttr('RICDCVK')) {
                        teamCode = 'RI CDC VK Corp';
                    }

                    if (SiebelApp.S_App.GetProfileAttr('RICDCTB')) {
                        teamCode = 'RI CDC TB Corp';
                    }

                    if (SiebelApp.S_App.GetProfileAttr('RICDCIC')) {
                        teamCode = 'IC';
                    }

                    if (teamCode === 'ARM') { SiebelApp.S_App.SetProfileAttr("teamCode", "") } else SiebelApp.S_App.SetProfileAttr("teamCode", teamCode);

                    const statusOptions = [];

                    Status = GetCTICDCStatusLOV(teamCode);
                    for (let i = 0; i < Status.length; i++) {
                        statusOptions.push({
                            label: Status[i].name,
                            value: Status[i].code,
                            design: Status[i].design,
                            limit: Status[i].limit,
                        });
                    }

                    let State = 15;
                    function InitStatus() {
                        const Buttons = SiebelAppFacade.GetAllButtons
                            ? SiebelAppFacade.GetAllButtons(SiebelAppFacade.CTIPR)
                            : [];
                        let State = 15;
                        if (Object.keys(Buttons).length == 0) {
                            //init if commtoolbar loads after preload
                            getPromiseFromEvent(document, 'RICDCSignOff').then((res) => {
                                InitStatus();
                            });
                        }
                        if (Buttons['RI CDC Sign On']) {
                            if (
                                Buttons['RI CDC Sign Off'].m_state == 'enabled' ||
                                Buttons['RI CDC Sign On'].m_state == 'disabled'
                            ) {
                                //CTI Panel Enabled
                                if (Buttons['RRIOUICommAgentAvailable'].m_state == 'enabled') {
                                    State = 15; //Not Ready Yet
                                } else if (
                                    Buttons['Agent State For Work Item'].m_state == 'enabled'
                                ) {
                                    State = 16; //Ready//changestatus
                                }
                            }
                        }
                        DataManager.add('changeCurrentStatus', State);
                        SiebelApp.S_App.SetProfileAttr('CDCCTIStatus', State);
                        return State;
                    }
                    let StatusProfile = +SiebelApp.S_App.GetProfileAttr('CDCCTIStatus');
                    if (StatusProfile == 15) {
                        State = InitStatus();
                    } else if (StatusProfile != 0) {
                        State = StatusProfile;
                    }
                    let UserName = SiebelApp.S_App.GetProfileAttr('RI Full Name RUS');
                    UserName = UserName.slice(0, UserName.lastIndexOf(' '));
                    //SiebelApp.S_App.SetProfileAttr("CDCCTIStatus",State);
                    SiebelAppFacade.HeaderShow({
                        elementId: 'header-box',
                        currentStatus: State,
                        operator: {
                            id: SiebelApp.S_App.GetProfileAttr('Login Name'),
                            fio: UserName,
                            ext: SiebelApp.S_App.GetProfileAttr('Extencion Work Phone'),
                        },
                        statusOptions,
                        settingOptions: [
                            { id: 1, name: 'Настройки', onAction: onSettings },
                            {
                                id: 2,
                                name: 'Выйти',
                                onAction: onLogout,
                            },
                        ],
                        onCall: (flag, phone) => //RUAVSVA CDR-3843
                        {
                            //Проверяем доступность Avaya
                            //Создаем объект с номером телефона
                            //                            const user =
                            //                            {
                            //                                phone: phone,
                            //                            }
                            //                            SiebelAppFacade.Socket.send(user);

                            const Buttton = SiebelAppFacade.GetAllButtons
                                ? SiebelAppFacade.GetAllButtons(SiebelAppFacade.CTIPR)
                                : [];
                            if (Buttton['RI CDC Sign Off'].m_state == 'disabled' && Buttton['RI CDC Sign On'].m_state == 'disabled' && Buttton['Agent State For Work Item'].m_state == 'disabled'
                                && Buttton['RI CDC Hangup Call'].m_state == 'disabled' && Buttton['RI CDC GetEDUData'].m_state == 'disabled') {
                                DataManager.add('isErrorConnect', {
                                    text: 'Проблема с интернет - соединением. Пожалуйста, перезагрузите страницу',
                                })
                            }
                            else {
                                //
                                console.log(phone);
                                let phoneSearch;
                                let resPhone = [...phone];
                                const lPhone = phone.length;
                                let callContinue = false;
                                const teamCode = SiebelApp.S_App.GetProfileAttr('teamCode');
                                if (lPhone < 10) callContinue = true;
                                if (!callContinue) {
                                    if (resPhone[0] === '7') {
                                        phoneSearch = phone;
                                        resPhone.shift();
                                        resPhone.unshift('8');
                                        resPhone.unshift('0');
                                        phone = resPhone.join('');
                                    }
                                    if (resPhone[0] === '8') {
                                        const AphoneSearch = [...phone];
                                        AphoneSearch.shift();
                                        AphoneSearch.unshift('7');
                                        phoneSearch = AphoneSearch.join('');
                                        resPhone.unshift('0');
                                        phone = resPhone.join('');


                                    }
                                    if (lPhone === 10) {
                                        phoneSearch = '7' + phone;
                                        resPhone.unshift('8');
                                        resPhone.unshift('0');
                                        phone = resPhone.join('');
                                    }//9081104899 нет дозвона
                                    console.log(phone);
                                    console.log(phoneSearch);

                                    ClientSearch(phoneSearch);
                                    //Создаем обращение
                                    OutboundCallConnect(phoneSearch)
                                }
                                else if (teamCode == 'RI CDC VK Corp' || teamCode == 'RI CDC TB Corp') {
                                    SiebelApp.S_App.SetProfileAttr("Identified", "Y");
                                    OutboundCallConnect(phone, teamCode);
                                }
                                //
                                const ser = SiebelApp.S_App.GetService("Communications Client");
                                const inPropSet = SiebelApp.S_App.NewPropertySet();
                                inPropSet.SetProperty('NewCallPhone', phone);
                                ser.InvokeMethod('RRIOUIMakeCallToPhone', inPropSet);
                                DataManager.add('ctiPanelEvents', { pathEvent: 'hidden', value: false }); //ARM-114
                                //
                            }
                        },
                        onStatusChange,
                        onAppealCreate: (appealType, phoneNumber) => {
                            appealType = appealType == 0 ? '' : appealType;
                            const serviceWF = SiebelApp.S_App.GetService('Workflow Process Manager');
                            const psInp = SiebelApp.S_App.NewPropertySet();
                            let psOut = SiebelApp.S_App.NewPropertySet();
                            psInp.SetProperty('ProcessName', 'RI CDC Create Request Process');
                            psInp.SetProperty('appealType', appealType);
                            psInp.SetProperty('phoneNumber', phoneNumber);
                            psOut = serviceWF.InvokeMethod('RunProcess', psInp);
                        },
                        options,
                        goToBack: () => {
                            const serviceWF = SiebelApp.S_App.GetService('Workflow Process Manager');
                            const psInp = SiebelApp.S_App.NewPropertySet();
                            psInp.SetProperty('ProcessName', 'RBRU Go To View');
                            psInp.SetProperty('View Name', 'RI CDC Request History Detail View');
                            psInp.SetProperty('BO Name', 'RI CDC Request');
                            psInp.SetProperty('BC Name', 'RI CDC Request');
                            psInp.SetProperty('Entity Id', SiebelApp.S_App.GetProfileAttr("RICDCReqId"));

                            serviceWF.InvokeMethod('RunProcess', psInp);
                        },
                        subscribe: DataManager.subscribe,
                    });

                    const wsCallOut = (phone) => {
                        console.log(phone);
                        let phoneSearch;
                        let resPhone = [...phone];
                        const lPhone = phone.length;
                        let callContinue = false;
                        if (lPhone < 10) callContinue = true;
                        if (!callContinue) {
                            if (resPhone[0] === '7') {
                                phoneSearch = phone;
                                resPhone.shift();
                                resPhone.unshift('8');
                                resPhone.unshift('0');
                                phone = resPhone.join('');
                            }
                            if (resPhone[0] === '8') {
                                const AphoneSearch = [...phone];
                                AphoneSearch.shift();
                                AphoneSearch.unshift('7');
                                phoneSearch = AphoneSearch.join('');
                                resPhone.unshift('0');
                                phone = resPhone.join('');


                            }
                            if (lPhone === 10) {
                                phoneSearch = '7' + phone;
                                resPhone.unshift('8');
                                resPhone.unshift('0');
                                phone = resPhone.join('');
                            }
                            console.log(phone);
                            console.log(phoneSearch);

                            //Посылаем сообщение для создания обращения
                            outgoingCall = ClientSearch(phoneSearch); 
                            console.log(outgoingCall);
                            SiebelAppFacade.Send(outgoingCall);
                            //OutboundCallConnect(phoneSearch)
                        }
                        //
                        const ser = SiebelApp.S_App.GetService("Communications Client");
                        const inPropSet = SiebelApp.S_App.NewPropertySet();
                        inPropSet.SetProperty('NewCallPhone', phone);
                        ser.InvokeMethod('RRIOUIMakeCallToPhone', inPropSet);
                        DataManager.add('ctiPanelEvents', { pathEvent: 'hidden', value: false }); //ARM-114


                        //Состояние кнопок для исходящего
                        // const armSocket = getSysPref('RI CDC ARM Socket');//ARM-529
                        // if (armSocket == 'true') {
                        //     SiebelAppFacade.Send(armItem);
                        //     SiebelAppFacade.Send(isHiden(false));

                        //     //defaultStateCTI
                        //     SiebelAppFacade.Send(callGive('isHidden', true));//ARM-543
                        //     SiebelAppFacade.Send(callBack('isHidden', true));//ARM-543
                        //     SiebelAppFacade.Send(switchToCaller('isHidden', true));//ARM-543
                        //     SiebelAppFacade.Send(switchToDestination('isHidden', true));//ARM-543

                        //     SiebelAppFacade.Send(callHold('isDisabled', false));
                        //     SiebelAppFacade.Send(callTransfer('isDisabled', false));
                        //     SiebelAppFacade.Send(callTransferConsultation('isDisabled', false));
                        //     SiebelAppFacade.Send(callIVR('isDisabled', false));
                        //     SiebelAppFacade.Send(callEnd('isDisabled', false));

                        //     SiebelAppFacade.Send(callHold('isHold', false)); //ARM-548

                        // }
                    }


                    //WebSocket
                    SiebelAppFacade.Send = () => { };

                    let login = String(SiebelApp.S_App.GetUserName());
                    login = login.toLowerCase();

                    const PILOT_USERS = ['ruazmk1', 'ruancs4', 'ruasrmo', 'ruakenq', 'ruaglaz', 'ruaaayn', 'rualsi8', 'ruavsva', 'ruapkel', 'ruamyp2', 'ruabkii', 'rualpk3', 'ruamua'];
                    if (PILOT_USERS.find((element) => element == login)) {
                        SiebelAppFacade.Send = function (object) {
                            WebSocket.send(object);
                        }

                        const querytoken = (login) => {
                            let _token = "";
                            const serviceWF = SiebelApp.S_App.GetService('Workflow Process Manager');
                            let psInp = SiebelApp.S_App.NewPropertySet();
                            let psOut = SiebelApp.S_App.NewPropertySet();
                            psInp.SetProperty('ProcessName', 'RI CDC Query Token');
                            psInp.SetProperty('login', login);
                            psOut = serviceWF.InvokeMethod('RunProcess', psInp);

                            if(psOut.GetChildCount() > 0 && psOut.GetChild(0).GetProperty("Error Message") == "") {
                                _token = psOut.GetChild(0).GetProperty("code");
                            } else {
                                console.warn(`[ARM WebSocket] не найден токен для пользователя ${login}`);
                                console.log(psOut);
                            }
                            return _token;
                        }



                        let tokenFn = () => querytoken(login);
                        const WebSocket = SiebelAppFacade.Socket;
                        const ARM_HOST = getSysPref('RI CDC ARM Back Host');
                        const ARM_WSS = `wss://${ARM_HOST}/siebel/`;
                        WebSocket.connect('ws', ARM_WSS);

                        const socketData = (data) => {
                            //Принять сообщение
                            if (data.topic === "incomingCall" && data.event === "avayaAccept") {
                                const callId = data.message.callId;
                                SiebelApp.S_App.SetProfileAttr("callId", callId);
                                SiebelAppFacade.CommToolbarPhyRenderer.prototype.ShowCTI();

                                let trackingId = SiebelApp.S_App.GetProfileAttr("CTI TrackingID");
                                trackingId = formattedTracking(trackingId);

                                const json1 = {
                                    "topic": "success",
                                    "event": "incomingCallAvayaAccept",
                                    "message": {
                                        "text ": "Успех"
                                    }
                                };
                                const json2 = {
                                    "topic": "incomingCallAvayaAccept",
                                    "event": "item",
                                    "message": {
                                        "callId": SiebelApp.S_App.GetProfileAttr("callId"),
                                        "trackingId": trackingId,
                                    }
                                }
                                SiebelAppFacade.Send(json1);
                                SiebelAppFacade.Send(json2);

                            };

                            if (data.topic === 'userStatus' && data.event === 'change') { ///userStatus/change - изменение статуса пользователя
                                const status = data.message.statusCode;
                                onStatusChangeFun(status, true);
                            }

                            if (data.topic === 'system' && data.event === 'ping') {//system ping
                                const ping = {
                                    'topic': 'system',
                                    'event': 'ping'
                                };
                                SiebelAppFacade.Send(ping);
                            }

                            if (data.topic === 'callEnd' && data.event === 'onCallEnd' && data.service === 'siebel') { //завершить вызов
                                SiebelAppFacade.CommToolbarPhyRenderer.prototype.OnHangUp();
                            }

                            if (data.topic === 'callHold' && data.event === 'onHold' && data.service === 'siebel') { //Пауза
                                const flag = data.message.isHold;
                                SiebelAppFacade.CommToolbarPhyRenderer.prototype.onPause(flag);
                            }

                            if (data.topic === 'callIVR' && data.event === 'onCallIVR' && data.service === 'siebel') { //IVR
                                const message = data.message;
                                SiebelAppFacade.CommToolbarPhyRenderer.prototype.setIVRNumber(message);
                            }

                            if (data.topic === 'callTransfer' && data.event === 'onCallTransfer' && data.service === 'siebel') { //Transfer
                                const message = data.message;
                                SiebelAppFacade.CommToolbarPhyRenderer.prototype.OnCallTransfer('transfer', message);
                            }

                            if (data.topic === 'callTransferConsultation' && data.event === 'onCallTransferConsultation' && data.service === 'siebel') { //TransferConsultation
                                const message = data.message;
                                SiebelAppFacade.CommToolbarPhyRenderer.prototype.OnCall('transferConsultation', message);
                            }

                            if (data.topic === 'callBack' && data.event === 'onCallBack' && data.service === 'siebel') { //Завершить консультацию
                                const message = data.message;
                                SiebelAppFacade.CommToolbarPhyRenderer.prototype.onCallBack();
                            }

                            if (data.topic === 'callGive' && data.event === 'onCallGive' && data.service === 'siebel') { //Передать консультацию
                                const message = data.message;
                                SiebelAppFacade.CommToolbarPhyRenderer.prototype.OnCallTransfer('transferConsultation', message);
                            }

                            if (data.topic === 'switchToCaller' && data.event === 'onTrigger' && data.service === 'siebel') { //Переключиться на 1 линию
                                SiebelAppFacade.CommToolbarPhyRenderer.prototype.switchToCaller();
                            }

                            if (data.topic === 'switchToDestination' && data.event === 'onTrigger' && data.service === 'siebel') { //Переключиться на 2 линию
                                SiebelAppFacade.CommToolbarPhyRenderer.prototype.switchToDestination();
                            }

                            if (data.topic === 'callOut' && data.event === 'onCallOut' && data.service === 'siebel') { //Исходящий вызов
                                wsCallOut(data.message);
                            }


                            /*
                             {
                                        "topic": "callEnd",
                                        "event": "onCallEnd",
                                        "service" : "siebel"
                                    }
                             */

                        };

                        WebSocket.data(socketData);
                    }
                    // Обращение
                    if (activeViewName.indexOf('RI CDC Request') > -1) {
                        const div = $('#_swecontent div[title-preserved]')[1];
                        div.id = 'reload-box';

                        SiebelAppFacade.AppealBodyShow('reload-box');
                    }

                    document.body.classList.remove('ri-sme-account-details');

                } else if (URL.indexOf('fins_cdc') > -1) {
                    SiebelApp.Utils.Confirm = origSiebConfirmFunc;
                    document.body.classList.add('ri-sme-account-details');

                    // Перемещаем тулбар и тредбар внутрь content-box
                    const contentBox = document.getElementById('content-box');
                    let toolbarDiv = contentBox.querySelector('.siebui-button-toolbar');
                    let threadbarDiv = contentBox.querySelector('#_swethreadbar');

                    if (!threadbarDiv) {
                        threadbarDiv = contentBox.insertBefore(document.getElementById('_swethreadbar'), contentBox.querySelector('#_swecontent'));
                    }

                    if (!toolbarDiv) {
                        toolbarDiv = contentBox.insertBefore(document.getElementsByClassName('siebui-button-toolbar')[0], threadbarDiv);
                    }
                }
            } catch (error) {
                //No-Op
                console.log(error);
            }
        }
        const origSiebConfirmFunc = SiebelApp.Utils.Confirm;
        SiebelApp.EventManager.addListner('preload', OnPreloadCDC, this);
    })());
}
