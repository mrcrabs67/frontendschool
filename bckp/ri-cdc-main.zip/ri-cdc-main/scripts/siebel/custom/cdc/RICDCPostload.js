if (typeof (SiebelAppFacade.RICDCPostload) == "undefined") {
    Namespace('SiebelAppFacade.RICDCPostload');

     define("siebel/custom/cdc/RICDCPostload", [
   'siebel/custom/cdc/dist/app',
   'siebel/custom/cdc/dist/cdc-vendor',
  ],function(){
        SiebelApp.EventManager.addListner( "postload", OnPostload, this );
        function OnPostload( ){
            try{
                console.log("RICDCPostload");
				function cleaning() {
					const sweappmenu = document.getElementById('_sweappmenu');
					if (sweappmenu) {
					 sweappmenu.style.display = 'none';
					}

					const swethreadbar = document.getElementById('_swethreadbar');
					if (swethreadbar) {
					 swethreadbar.style.display = 'none';
					}

					const swescrnbar = document.getElementById('_swescrnbar');
					if (swescrnbar) {
					 swescrnbar.style.display = 'none';
					}

					const siebuiViewMultiColumn = document.getElementById('siebui-view-multi-column');
					if (siebuiViewMultiColumn) {
					 siebuiViewMultiColumn.style.display = 'none';
					}

					const siebuiButtonToolbar = document.querySelector('div.siebui-button-toolbar');
					if (siebuiButtonToolbar) {
					 siebuiButtonToolbar.style.display = 'none';
					}

					const childrenPR = document.getElementById('s_S_A1_div');
					if (childrenPR) {
					 childrenPR.style.display = 'none';
					}

					document.getElementById('_swecontent').style.height = "100%"
				   }
console.log("RICDCCallsFormAppletPR");

     /*const PM = this.GetPM();
     const sAppletId = PM.Get('GetFullId');

     const elAppletId = document.getElementById(sAppletId);
     if (elAppletId) {
      elAppletId.style.height = "100%"
     }*/

     //cleaning();

     //SiebelAppFacade.BodyShow(sAppletId);

     const footerItems = [
      {
       id: 1,
       icon: 'Settings',
       title: 'Настройки',
       onClick: () => SiebelApp.S_App.GotoView('RI CDC All Request List View'),
      },
      {
       id: 2,
       icon: 'ChartPie',
       title: 'Отчеты',
       onClick: () => SiebelApp.S_App.GotoView('RI CDC All Request List View'),
      },
     ];

     const menuItems = [
      {
       id: 1,
       active: false,
       icon: 'CallOut',
       title: 'Обзвон',
       onClick: () => SiebelApp.S_App.GotoView('RI CDC All Request List View'),
      },
      {
       id: 2,
       active: false,
       icon: 'Retry2',
       title: 'История',
       onClick: () => SiebelApp.S_App.GotoView("RI CDC All Request List View"),
      },
      {
       id: 3,
       active: false,
       icon: 'Rating',
       title: 'Топ тикетов',
       onClick: () => SiebelApp.S_App.GotoView("RI CDC All Request List View"),
      },
      {
       id: 4,
       active: false,
       icon: 'People1',
       title: 'Контакты',
       onClick: () => SiebelApp.S_App.GotoView("RI CDC All Request List View"),
      },
      {
       id: 5,
       active: false,
       icon: 'Education',
       title: 'База знаний',
       onClick: () => SiebelApp.S_App.GotoView("RI CDC All Request List View"),
      },
     ];

     SiebelAppFacade.SidebarShow({
      elementId: 'sidebar-box', menuItems, footerItems
     });
            }
            catch(error)
            {
                //No-Op
				console.log(error);
            }
        }
    }());
}