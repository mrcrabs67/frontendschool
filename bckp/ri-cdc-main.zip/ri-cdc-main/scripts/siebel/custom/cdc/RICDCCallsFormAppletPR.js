//Regenerate using:https://duncanford.github.io/prpm-code-generator/?prpm=PR&object=DesktopForm&name=RICDCCallsFormApplet&userprops=&comments=Yes&logging=No
if (typeof(SiebelAppFacade.RICDCCallsFormAppletPR) === "undefined") {

 SiebelJS.Namespace("SiebelAppFacade.RICDCCallsFormAppletPR");
 define("siebel/custom/cdc/RICDCCallsFormAppletPR", [
  'siebel/custom/cdc/RICDCFormAppletPR',
   //'siebel/custom/cdc/dist/app',
   //'siebel/custom/cdc/dist/cdc-vendor',
  ],
  function () {

   SiebelAppFacade.RICDCCallsFormAppletPR = (function () {

    function RICDCCallsFormAppletPR(pm) {
     SiebelAppFacade.RICDCCallsFormAppletPR.superclass.constructor.apply(this, arguments);
    }

    SiebelJS.Extend(RICDCCallsFormAppletPR, SiebelAppFacade.RICDCFormAppletPR);

    RICDCCallsFormAppletPR.prototype.Init = function () {
     // Init is called each time the object is initialised.
     // Add code here that should happen before default processing
     SiebelAppFacade.RICDCCallsFormAppletPR.superclass.Init.apply(this, arguments);
     // Add code here that should happen after default processing
    }

    RICDCCallsFormAppletPR.prototype.ShowUI = function () {
     // ShowUI is called when the object is initially laid out.
     // Add code here that should happen before default processing
     SiebelAppFacade.RICDCCallsFormAppletPR.superclass.ShowUI.apply(this, arguments);
     // Add code here that should happen after default processing
     //console.log("RICDCCallsFormAppletPR");

    }

    RICDCCallsFormAppletPR.prototype.BindData = function (bRefresh) {
     // BindData is called each time the data set changes.
     // This is where you'll bind that data to user interface elements you might have created in ShowUI
     // Add code here that should happen before default processing
     SiebelAppFacade.RICDCCallsFormAppletPR.superclass.BindData.apply(this, arguments);
     // Add code here that should happen after default processing
    }

    RICDCCallsFormAppletPR.prototype.BindEvents = function () {
     // BindEvents is where we add UI event processing.
     // Add code here that should happen before default processing
     SiebelAppFacade.RICDCCallsFormAppletPR.superclass.BindEvents.apply(this, arguments);
     // Add code here that should happen after default processing
    }

    RICDCCallsFormAppletPR.prototype.EndLife = function () {
     // EndLife is where we perform any required cleanup.
     // Add code here that should happen before default processing
     SiebelAppFacade.RICDCCallsFormAppletPR.superclass.EndLife.apply(this, arguments);
     // Add code here that should happen after default processing
    }

    return RICDCCallsFormAppletPR;
   }()
  );
  return "SiebelAppFacade.RICDCCallsFormAppletPR";
 })
}

