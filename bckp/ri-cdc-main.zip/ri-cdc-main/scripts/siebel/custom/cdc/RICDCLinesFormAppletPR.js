//Regenerate using:https://duncanford.github.io/prpm-code-generator/?prpm=PR&object=DesktopForm&name=RICDCLinesFormApplet&userprops=&comments=No&logging=No
if (typeof(SiebelAppFacade.RICDCLinesFormAppletPR) === "undefined") {

 SiebelJS.Namespace("SiebelAppFacade.RICDCLinesFormAppletPR");
 define("siebel/custom/cdc/RICDCLinesFormAppletPR", ['siebel/custom/cdc/RICDCFormAppletPR',],
  function () {
   SiebelAppFacade.RICDCLinesFormAppletPR = (function () {

    function RICDCLinesFormAppletPR(pm) {
     SiebelAppFacade.RICDCLinesFormAppletPR.superclass.constructor.apply(this, arguments);
    }

    SiebelJS.Extend(RICDCLinesFormAppletPR, SiebelAppFacade.RICDCFormAppletPR);

    RICDCLinesFormAppletPR.prototype.Init = function () {
     SiebelAppFacade.RICDCLinesFormAppletPR.superclass.Init.apply(this, arguments);
    }

    RICDCLinesFormAppletPR.prototype.ShowUI = function () {
     SiebelAppFacade.RICDCLinesFormAppletPR.superclass.ShowUI.apply(this, arguments);
     //console.log("RICDCLinesFormAppletPR");

     const PM = this.GetPM();
     const sAppletId = PM.Get('GetFullId');

     /*const elAppletId = document.getElementById(sAppletId);
     if (elAppletId) {
      elAppletId.style.display = 'none';
     }*/
    }
     // SiebelAppFacade.ContentShow('content-box');

    RICDCLinesFormAppletPR.prototype.BindData = function (bRefresh) {
     SiebelAppFacade.RICDCLinesFormAppletPR.superclass.BindData.apply(this, arguments);
    }

    RICDCLinesFormAppletPR.prototype.BindEvents = function () {
     SiebelAppFacade.RICDCLinesFormAppletPR.superclass.BindEvents.apply(this, arguments);
    }

    RICDCLinesFormAppletPR.prototype.EndLife = function () {
     SiebelAppFacade.RICDCLinesFormAppletPR.superclass.EndLife.apply(this, arguments);
    }

    return RICDCLinesFormAppletPR;
   }()
  );
  return "SiebelAppFacade.RICDCLinesFormAppletPR";
 })
}

