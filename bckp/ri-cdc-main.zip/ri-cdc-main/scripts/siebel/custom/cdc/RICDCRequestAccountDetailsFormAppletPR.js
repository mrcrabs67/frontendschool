//Regenerate using:https://duncanford.github.io/prpm-code-generator/?prpm=PR&object=DesktopForm&name=RI%20CDC%20Request%20Account%20Details%20Form%20Applet&userprops=&comments=Yes&logging=No
if (typeof (SiebelAppFacade.RICDCRequestAccountDetailsFormAppletPR) === "undefined") {

    SiebelJS.Namespace("SiebelAppFacade.RICDCRequestAccountDetailsFormAppletPR");
    define("siebel/custom/cdc/RICDCRequestAccountDetailsFormAppletPR", ['siebel/custom/cdc/RICDCFormAppletPR',],
        function () {

            SiebelAppFacade.RICDCRequestAccountDetailsFormAppletPR = (function () {

                function RICDCRequestAccountDetailsFormAppletPR(pm) {
                    SiebelAppFacade.RICDCRequestAccountDetailsFormAppletPR.superclass.constructor.apply(this, arguments);
                }

                SiebelJS.Extend(RICDCRequestAccountDetailsFormAppletPR, SiebelAppFacade.RICDCFormAppletPR);

                RICDCRequestAccountDetailsFormAppletPR.prototype.Init = function () {
                    // Init is called each time the object is initialised.
                    // Add code here that should happen before default processing
                    SiebelAppFacade.RICDCRequestAccountDetailsFormAppletPR.superclass.Init.apply(this, arguments);
                    // Add code here that should happen after default processing
                }

                RICDCRequestAccountDetailsFormAppletPR.prototype.ShowUI = function () {
                    // ShowUI is called when the object is initially laid out.
                    // Add code here that should happen before default processing
                    SiebelAppFacade.RICDCRequestAccountDetailsFormAppletPR.superclass.ShowUI.apply(this, arguments);
                    // Add code here that should happen after default processing

                    /*if (SiebelAppFacade.DMFA === undefined){
                        SiebelAppFacade.DMFA = SiebelAppFacade.Events();
                    }
                    const DataManager = SiebelAppFacade.DMFA;*/
                    let DataManager = SiebelAppFacade.DMPL;

                    if (SiebelAppFacade.DMPL) {
                        DataManager = SiebelAppFacade.DMPL;
                    } else {
                        DataManager = SiebelAppFacade.Events();
                    }

                    const PR = this;
                    const View = SiebelApp.S_App.GetActiveView();
                    const Applet = View.GetActiveApplet();
                    const PM = PR.GetPM();
                    const BC = PM.Get("GetBusComp");
                    //

                    let fullNameOrg = BC.GetFieldValue("Account_Name");
                    let InternationalNameOrg = BC.GetFieldValue("Account_Name_Int");
                    let inn = BC.GetFieldValue("RI_Account_INN");
                    let kpp = BC.GetFieldValue("RI_Account_KPP");
                    let segment = BC.GetFieldValue("RI_Client_Segment");
                    let gcc = BC.GetFieldValue("RI_GCC_Id_Calc");

                    let subcategory = BC.GetFieldValue("RI SME Subcategory"); //SME Sub-Категория

                    function getBranch() {
                        let branch = BC.GetFieldValue("RI Client Main Branch");
                        if (branch === "" || branch === " ") 
                            branch = undefined;
                        return branch;
                    }
                    //let branch = BC.GetFieldValue("RI Client Main Branch"); //Основное отделение клиента

                    let mainEmailAddress = BC.GetFieldValue("Main Email Address"); //Адрес электронной почты
                    const AccountId = SiebelApp.S_App.GetActiveBusObj().GetBusCompByName('RI CDC Request').GetFieldValue("Account Id");

                    //let cnum = "";

                    function getCnum() {
                        let cnum = "";
                        if (BC.GetFieldValue("RI_External_Client_Midas_ID") != "") {
                            cnum = BC.GetFieldValue("RI_External_Client_Midas_ID");
                        } else {
                            cnum = BC.GetFieldValue("RI_External_Client_ID");
                        }
                        return cnum;
                    }


                    PM.AttachPostProxyExecuteBinding("RefreshRecord", DataTabsCompanyUpdate);
                    const getPhoneCodes = function (AccountId) {
                        if (AccountId) {
                            const serviceWF = SiebelApp.S_App.GetService('Workflow Process Manager');
                            const psInp = SiebelApp.S_App.NewPropertySet();
                            psInp.SetProperty('ProcessName', 'RI CDC Query IO Process');
                            psInp.SetProperty('IOName', 'RI CDC Service Region');
                            psInp.SetProperty(
                                'Search',
                                `[RI Service Region.Account Id]="${AccountId}" AND [RI Service Region.Current Phone Code] IS NOT NULL`,
                            );
                            const psOut = serviceWF.InvokeMethod('RunProcess', psInp);
                            const codesArr = [];
                            const resArr = psOut.childArray[0].childArray[0].childArray[0].childArray;
                            resArr.forEach(element => {
                                const arr = element.propArray;
                                codesArr.push({
                                    code: arr['Current Phone Code'],
                                    codeRegion: arr['Region Code'],
                                    region: arr['Region Name'],
                                });
                            });
                            return codesArr;
                        } else return [];
                    };
                    const codes = getPhoneCodes(AccountId);
                    const Organization = {
                        data: {
                            fullNameOrg: fullNameOrg,
                            InternationalNameOrg: InternationalNameOrg,
                            inn: inn,
                            kpp: kpp,
                            segment: segment,
                            cnum: getCnum(),
                            gcc: gcc,
                            customerPhoneCode: codes,
                            subcategory: subcategory, //SME Sub-Категория
                            branch: getBranch(), //Основное отделение клиента
                            mainEmailAddress: mainEmailAddress, //Адрес электронной почты
                        },
                        subscribe: DataManager.subscribe,
                        goToTab: (name) => {
                            SiebelApp.S_App.SetProfileAttr('CDCTop', $('div#_sweview').scrollTop());
                            SiebelApp.S_App.GotoView('RI CDC Request History Detail View')
                        },
                    };

                    SiebelAppFacade.AppealTabsCompanyShow(Organization);

                    function DataTabsCompanyUpdate() {
                        const AccountId = SiebelApp.S_App.GetActiveBusObj().GetBusCompByName('RI CDC Request').GetFieldValue("Account Id");
                        let branch = undefined;
                        const codes = getPhoneCodes(AccountId);
                        if (BC.GetFieldValue("RI Client Main Branch") != "" || BC.GetFieldValue("RI Client Main Branch") != " ") branch = BC.GetFieldValue("RI Client Main Branch");
                        //setTimeout(() => console.log('onSelect', value), 1000);
                        const data = {
                            fullNameOrg: BC.GetFieldValue("Account_Name"),
                            InternationalNameOrg: BC.GetFieldValue("Account_Name_Int"),
                            inn: BC.GetFieldValue("RI_Account_INN"),
                            kpp: BC.GetFieldValue("RI_Account_KPP"),
                            segment: BC.GetFieldValue("RI_Client_Segment"),
                            cnum: getCnum(),
                            gcc: BC.GetFieldValue("RI_GCC_Id_Calc"),
                            customerPhoneCode: codes,
                            subcategory: BC.GetFieldValue("RI SME Subcategory"), //SME Sub-Категория
                            branch: getBranch(), //Основное отделение клиента
                            mainEmailAddress: BC.GetFieldValue("Main Email Address"), //Адрес электронной почты
                        }
                        DataManager.add('appealDataTabsCompanyUpdate', data);
                        //console.log("DataTabsCompanyUpdate");
                        //console.log(data);
                    }

                    //const PM = this.GetPM();
                    /*const sAppletId = PM.Get('GetFullId');

                    const elAppletId = document.getElementById(sAppletId);
                    if (elAppletId) {
                        elAppletId.style.display = 'none';
                    }*/
                    const top = SiebelApp.S_App.GetProfileAttr('CDCTop');
                    if (top !== "") {
                        SiebelApp.S_App.SetProfileAttr('CDCTop', "");
                        setTimeout(() => { $('div#_sweview').scrollTop(top) }, 200);
                    }
                }

                RICDCRequestAccountDetailsFormAppletPR.prototype.BindData = function (bRefresh) {
                    // BindData is called each time the data set changes.
                    // This is where you'll bind that data to user interface elements you might have created in ShowUI
                    // Add code here that should happen before default processing
                    SiebelAppFacade.RICDCRequestAccountDetailsFormAppletPR.superclass.BindData.apply(this, arguments);
                    // Add code here that should happen after default processing
                }

                RICDCRequestAccountDetailsFormAppletPR.prototype.BindEvents = function () {
                    // BindEvents is where we add UI event processing.
                    // Add code here that should happen before default processing
                    SiebelAppFacade.RICDCRequestAccountDetailsFormAppletPR.superclass.BindEvents.apply(this, arguments);
                    // Add code here that should happen after default processing
                }

                RICDCRequestAccountDetailsFormAppletPR.prototype.EndLife = function () {
                    // EndLife is where we perform any required cleanup.
                    // Add code here that should happen before default processing
                    SiebelAppFacade.RICDCRequestAccountDetailsFormAppletPR.superclass.EndLife.apply(this, arguments);
                    // Add code here that should happen after default processing
                }

                return RICDCRequestAccountDetailsFormAppletPR;
            }()
            );
            return "SiebelAppFacade.RICDCRequestAccountDetailsFormAppletPR";
        })
}
