/* prettier-ignore */
//Regenerate using:https://duncanford.github.io/prpm-code-generator/?prpm=PR&object=DesktopForm&name=RICDCAgentsFormApplet&userprops=&comments=Yes&logging=No
if (typeof(SiebelAppFacade.RICDCAgentsFormAppletPR) === "undefined") {

 SiebelJS.Namespace("SiebelAppFacade.RICDCAgentsFormAppletPR");
 define("siebel/custom/cdc/RICDCAgentsFormAppletPR", ['siebel/custom/cdc/RICDCFormAppletPR', 'siebel/custom/cdc/cdc-utils'],
  function () {

   SiebelAppFacade.RICDCAgentsFormAppletPR = (function () {

    function RICDCAgentsFormAppletPR(pm) {
     SiebelAppFacade.RICDCAgentsFormAppletPR.superclass.constructor.apply(this, arguments);
    }

    SiebelJS.Extend(RICDCAgentsFormAppletPR, SiebelAppFacade.RICDCFormAppletPR);

    RICDCAgentsFormAppletPR.prototype.Init = function () {
     // Init is called each time the object is initialised.
     // Add code here that should happen before default processing
     SiebelAppFacade.RICDCAgentsFormAppletPR.superclass.Init.apply(this, arguments);
     // Add code here that should happen after default processing
    }

    RICDCAgentsFormAppletPR.prototype.ShowUI = function () {
     // ShowUI is called when the object is initially laid out.
     // Add code here that should happen before default processing
     SiebelAppFacade.RICDCAgentsFormAppletPR.superclass.ShowUI.apply(this, arguments);
     // Add code here that should happen after default processing
     //console.log("RICDCAgentsFormAppletPR");

    }

    RICDCAgentsFormAppletPR.prototype.BindData = function (bRefresh) {
     // BindData is called each time the data set changes.
     // This is where you'll bind that data to user interface elements you might have created in ShowUI
     // Add code here that should happen before default processing
     SiebelAppFacade.RICDCAgentsFormAppletPR.superclass.BindData.apply(this, arguments);
     // Add code here that should happen after default processing
    }

    RICDCAgentsFormAppletPR.prototype.BindEvents = function () {
     // BindEvents is where we add UI event processing.
     // Add code here that should happen before default processing
     SiebelAppFacade.RICDCAgentsFormAppletPR.superclass.BindEvents.apply(this, arguments);
     // Add code here that should happen after default processing
    }

    RICDCAgentsFormAppletPR.prototype.EndLife = function () {
     // EndLife is where we perform any required cleanup.
     // Add code here that should happen before default processing
     SiebelAppFacade.RICDCAgentsFormAppletPR.superclass.EndLife.apply(this, arguments);
     // Add code here that should happen after default processing
    }

    return RICDCAgentsFormAppletPR;
   }()
  );
  return "SiebelAppFacade.RICDCAgentsFormAppletPR";
 })
}

