//Regenerate using:https://duncanford.github.io/prpm-code-generator/?prpm=PR&object=DesktopList&name=RI%20CDC%20Request%20Operators%20List%20Applet&userprops=&comments=Yes&logging=No
if (typeof(SiebelAppFacade.RICDCRequestOperatorsListAppletPR) === "undefined") {

    SiebelJS.Namespace("SiebelAppFacade.RICDCRequestOperatorsListAppletPR");
    define("siebel/custom/cdc/RICDCRequestOperatorsListAppletPR", ['siebel/custom/cdc/RICDCListAppletPR',//"siebel/jqgridrenderer"
    ],
     function () {
      SiebelAppFacade.RICDCRequestOperatorsListAppletPR = (function () {
   
       function RICDCRequestOperatorsListAppletPR(pm) {
        SiebelAppFacade.RICDCRequestOperatorsListAppletPR.superclass.constructor.apply(this, arguments);
       }
   
       SiebelJS.Extend(RICDCRequestOperatorsListAppletPR, SiebelAppFacade.RICDCListAppletPR);
   
       RICDCRequestOperatorsListAppletPR.prototype.Init = function () {
        // Init is called each time the object is initialised.
        // Add code here that should happen before default processing
        SiebelAppFacade.RICDCRequestOperatorsListAppletPR.superclass.Init.apply(this, arguments);
        // Add code here that should happen after default processing
       }
   
       RICDCRequestOperatorsListAppletPR.prototype.ShowUI = function () {
        // ShowUI is called when the object is initially laid out.
        // Add code here that should happen before default processing
        SiebelAppFacade.RICDCRequestOperatorsListAppletPR.superclass.ShowUI.apply(this, arguments);
        // Add code here that should happen after default processing
        //console.log("RICDCRequestOperatorsListApplet");
		const PR = this;
		const View = SiebelApp.S_App.GetActiveView();
		const Applet = View.GetActiveApplet();
		const PM = PR.GetPM();
		const sAppletId = PM.Get('GetFullId');
        
		const elAppletId = document.getElementById(sAppletId);
        if (elAppletId) {
         elAppletId.style.display = 'none';
        }
       }
   
       RICDCRequestOperatorsListAppletPR.prototype.BindData = function (bRefresh) {
        // BindData is called each time the data set changes.
        // This is where you'll bind that data to user interface elements you might have created in ShowUI
        // Add code here that should happen before default processing
        SiebelAppFacade.RICDCRequestOperatorsListAppletPR.superclass.BindData.apply(this, arguments);
        // Add code here that should happen after default processing
       }
   
       RICDCRequestOperatorsListAppletPR.prototype.BindEvents = function () {
        // BindEvents is where we add UI event processing.
        // Add code here that should happen before default processing
        SiebelAppFacade.RICDCRequestOperatorsListAppletPR.superclass.BindEvents.apply(this, arguments);
        // Add code here that should happen after default processing
       }
   
       RICDCRequestOperatorsListAppletPR.prototype.EndLife = function () {
        // EndLife is where we perform any required cleanup.
        // Add code here that should happen before default processing
        SiebelAppFacade.RICDCRequestOperatorsListAppletPR.superclass.EndLife.apply(this, arguments);
        // Add code here that should happen after default processing
       }
   
       return RICDCRequestOperatorsListAppletPR;
      }()
     );
     return "SiebelAppFacade.RICDCRequestOperatorsListAppletPR";
    })
   }
   
   