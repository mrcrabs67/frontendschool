function RequestControlPickList(PR,ControlName)
{
    let PM  = PR.GetPM();
    let InsPS = new JSSPropertySet();
    InsPS.SetProperty("SWEJI", "false");
    InsPS.SetProperty("SWEField", PR.GetColumnControl(ControlName).GetInputName());
    PM.ExecuteMethod("InvokeMethod", "GetQuickPickInfo", InsPS);
}
function DisableNotifyGeneric()
{
    let OldFn = SiebelApp.S_App.ListApplet.superclass.NotifyGeneric;
    SiebelApp.S_App.ListApplet.superclass.NotifyGeneric = function(a,b){
        if(View.GetName()!="RI CDC Request Detail View"){
            OldFN.call(this,a,b);
        }
    }
}
