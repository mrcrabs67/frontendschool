if (typeof SiebelAppFacade.RICDCCommToolbarPR === 'undefined') {
    SiebelJS.Namespace('SiebelAppFacade.RICDCCommToolbarPR');
    define('siebel/custom/cdc/cti/RICDCCommToolbarPR', [
        'siebel/commToolbarprender',
        'siebel/custom/cdc/cdc-utils',
    ], function () {
        const DataManager = SiebelAppFacade.Events();
        let timer;
        const Variables = {};
        Variables.bActiveCall = false;
        Variables.notCallShow = false;
        Variables.firstLoad = true;
        Variables.firstLoadIncomingcCall = true;
        Variables.firstCallOut = true;
        //let bActiveCall = false;
        let bActiveConsult = false;
        let bGoHome = false;
        let notCallShow = false;
        const eSignOnEnabled = new Event('RICDCSignOn');
        const eSignOffEnabled = new Event('RICDCSignOff');
        const myEvent = new CustomEvent('chStatus');//RUAVSVA Новая статусная модель
        const eAgentAvailableEnabled = new Event('RRIOUIAgentAvailable');

        if (typeof SiebelAppFacade.DMPL === 'undefined') SiebelAppFacade.DMPL = DataManager;
        SiebelAppFacade.CommToolbarPhyRenderer.prototype.OldShowUI =
            SiebelAppFacade.CommToolbarPhyRenderer.prototype.ShowUI;
        SiebelAppFacade.CommToolbarPhyRenderer.prototype.CTI = function (command, buttonName = command, ReasonCode = "") {
            var Buttons = SiebelAppFacade.GetAllButtons(SiebelAppFacade.CTIPR);
            if (Buttons[buttonName]?.m_state == "enabled" || buttonName == 'noCheck') {
                let serviceCached = SiebelApp.S_App.GetService('Communications Client');//'RRI OUI Cached Service'
                const inPropSet = SiebelApp.S_App.NewPropertySet();
                //inPropSet.SetProperty('Command', command);
                if (ReasonCode != "") {
                    inPropSet.SetProperty('ReasonCode', ReasonCode);
                }
                serviceCached.InvokeMethod(command, inPropSet);
                return 0;
            } else {
                return -1;
            }
        }
        SiebelAppFacade.CommToolbarPhyRenderer.prototype.SetVariable = function (name, value) {
            Variables[name] = value;
            SiebelApp.S_App.SetProfileAttr(name, value);
        }

        const getSysPref = (name) => {
            const serviceWF = SiebelApp.S_App.GetService('Workflow Process Manager');
            const psInp = SiebelApp.S_App.NewPropertySet();
            let psOut = SiebelApp.S_App.NewPropertySet();
            psInp.SetProperty('ProcessName', 'RI CDC Get System Preference');
            psInp.SetProperty('Name', name);
            psOut = serviceWF.InvokeMethod('RunProcess', psInp);

            const value = psOut.childArray[0].propArray['Value']
            return value;
        }

        const isHiden = (flag) => {
            const response =
            {
                "topic": "ctiPanel",
                "event": "isHidden",
                "service": "siebel",
                "message": flag
            };
            return response;
        }

        const callHoldDisabled = (message) => {
            const response = {
                "topic": "callHold",
                "event": "isDisabled",
                "service": "siebel",
                "message": message
            };
            return response;
        }

        const callHold = (type, message) => {
            const response = {
                "topic": "callHold",
                "event": type,
                "service": "siebel",
                "message": message
            };
            return response;
        }

        const callBack = (type, message) => {
            const response = {
                "topic": "callBack",
                "event": type,
                "service": "siebel",
                "message": message
            };
            return response;
        }

        const callEnd = (type, message) => {
            const response = {
                "topic": "callEnd",
                "event": type,
                "service": "siebel",
                "message": message
            };
            return response;
        }


        const callIVR = (type, message) => {
            const response = {
                "topic": "callIVR",
                "event": type,
                "service": "siebel",
                "message": message
            };
            return response;
        }

        const callTransfer = (type, message) => {
            const response = {
                "topic": "callTransfer",
                "event": type,
                "service": "siebel",
                "message": message
            };
            return response;
        }

        const callTransferConsultation = (type, message) => {
            const response = {
                "topic": "callTransferConsultation",
                "event": type,
                "service": "siebel",
                "message": message
            };
            return response;
        }

        const callGive = (type, message) => {
            const response = {
                "topic": "callGive",
                "event": type,
                "service": "siebel",
                "message": message
            };
            return response;
        }

        const switchToCaller = (type, message) => {
            const response = {
                "topic": "switchToCaller",
                "event": type,
                "service": "siebel",
                "message": message
            };
            return response;
        }

        const switchToDestination = (type, message) => {
            const response = {
                "topic": "switchToDestination",
                "event": type,
                "service": "siebel",
                "message": message
            };
            return response;
        }

        const incomingCall = (type, message) => {
            const response = {
                "topic": "incomingCall",
                "event": type,
                "service": "siebel",
                "message": message,
              };
              return response;
        }

        const dirQuery = () => {
            const phones = [];

            const serviceWF = SiebelApp.S_App.GetService('Workflow Process Manager');
            const psInp = SiebelApp.S_App.NewPropertySet();
            let psOut = SiebelApp.S_App.NewPropertySet();
            psInp.SetProperty('ProcessName', 'RI CDC CTI Directory Get All Values');

            psOut = serviceWF.InvokeMethod('RunProcess', psInp);

            if(psOut.GetChildCount() > 0 ) {
                const phonesOut = psOut.GetChild(0);
                const countPhones = phonesOut.GetChildCount();
                for(let i = 0; i < countPhones; i++){
                    phones.push(
                        {
                            title: phonesOut.GetChild(i).GetProperty("Name"),
                            phone: phonesOut.GetChild(i).GetProperty("Phone Number"),
                        }
                    )
                }
            }

            return phones;
        }

        const formattedTracking = (trackingId) => {
            let newtrackingid = String(trackingId);
            const cut = trackingId.indexOf(':');
            newtrackingid = trackingId.slice(0, cut);
            return newtrackingid;
        }

        SiebelAppFacade.CommToolbarPhyRenderer.prototype.setIVRNumber = function (phoneNumber) {
            const regex = /([0-9*#])/g;
            phoneNumber = phoneNumber.match(regex).join("");
            if (phoneNumber !== null || phoneNumber !== "") {
                const ser = SiebelApp.S_App.GetService("Communications Client");
                const inPropSet = SiebelApp.S_App.NewPropertySet();
                //console.log("Value = ", phoneNumber);
                inPropSet.SetProperty('Value', phoneNumber);
                ser.InvokeMethod('RICDCSendDTMF', inPropSet);
                console.log("IVR Number = ", phoneNumber);
            }
            else console.log('Введите корректный номер');
        }

        SiebelAppFacade.CommToolbarPhyRenderer.prototype.GetAllButtons = function (PR) {
            const aTopCtrlSeqMap = PR.GetPM().Get('GetTopCtrlsSeqMap');
            const aSubCtrlsSeqMap = PR.GetPM().Get('GetSubCtrlsSeqMap');
            const aButtons = [];
            let oBtn = {};
            for (const el in aTopCtrlSeqMap) {
                oBtn = { ...aTopCtrlSeqMap[el] };
                aButtons[aTopCtrlSeqMap[el].m_name] = oBtn;
            }
            for (const el in aSubCtrlsSeqMap) {
                oBtn = { ...aSubCtrlsSeqMap[el] };
                aButtons[aSubCtrlsSeqMap[el][1].m_name] = oBtn[1];
            }
            //SiebelAppFacade.CTIButtons = aButtons;
            return aButtons;
        }
        SiebelAppFacade.CommToolbarPhyRenderer.prototype.ShowCTI = function () {
            this.SetVariable('bActiveCall', true);
            //bActiveCall = true;
            DataManager.add('isOpenModalCall', false);
            this.CTI('RICDCAcceptCall', 'RI CDC Accept Call');
            let Phone = $("#Work_Item_List option").length > 0 ? $("#Work_Item_List option")[0].outerText : "";
            const workItemList = Phone;//ARM-583
            Phone = "+" + Phone.slice(Phone.indexOf(":") + 1);

            if (Phone.includes('+08')) {
                Phone = '+7' + Phone.slice(3, Phone.length);
            }

            const armSocket = getSysPref('RI CDC ARM Socket');//ARM-529
            const phones = dirQuery();
            const callLabel = (workItemList.indexOf("Call-Out") > -1) ? "Исходящий вызов" : "Входящий вызов";//ARM-583

            const armItem = {
                "topic": "ctiPanel",
                "event": "item",
                "service": "siebel",
                "message": {
                    "callLabel": callLabel, //ARM-583
                    "callPhone": Phone,
                    "callStartSeconds": 0,
                    "phones": phones,
                    "skillGroupLabel": "Skill-группа",
                    "skillGroup": "1-ая линия тех.поддержки",
                }
            }
            if (armSocket == 'true') {
                SiebelAppFacade.Send(armItem);
                SiebelAppFacade.Send(isHiden(false));

                //defaultStateCTI
                SiebelAppFacade.Send(callGive('isHidden', true));//ARM-543
                SiebelAppFacade.Send(callBack('isHidden', true));//ARM-543
                SiebelAppFacade.Send(switchToCaller('isHidden', true));//ARM-543
                SiebelAppFacade.Send(switchToDestination('isHidden', true));//ARM-543

                SiebelAppFacade.Send(callHold('isDisabled', false));
                SiebelAppFacade.Send(callTransfer('isDisabled', false));
                SiebelAppFacade.Send(callTransferConsultation('isDisabled', false));
                SiebelAppFacade.Send(callIVR('isDisabled', false));
                SiebelAppFacade.Send(callEnd('isDisabled', false));

                SiebelAppFacade.Send(callHold('isHold', false)); //ARM-548

            }


            if (SiebelApp.S_App.GetProfileAttr("CDCCTI") != "1") {
                /*RUAVSVA CDR - 3248*/
                SiebelAppFacade.eventsMap('defaultStateCTI', DataManager.add); //ARM-114

                const serviceWF = SiebelApp.S_App.GetService('Workflow Process Manager');
                const psInp = SiebelApp.S_App.NewPropertySet();
                let psOut = SiebelApp.S_App.NewPropertySet();
                psInp.SetProperty('ProcessName', 'RI CDC CTI Directory Query');
                psOut = serviceWF.InvokeMethod('RunProcess', psInp);

                const nameResult = psOut.childArray[0].propArray["Name Result"];
                const phoneNumberResult = psOut.childArray[0].propArray["Phone Number Result"];

                const aNameRes = nameResult.split(";");
                const aPhoneNumberResult = phoneNumberResult.split(";");
                const ctiDirLength = aNameRes.length;
                //

                const phones = [];
                phones.length = 0;
                for (i = 0; i < ctiDirLength; i++) {
                    phones.push(
                        {
                            title: aNameRes[i],
                            phone: aPhoneNumberResult[i],
                        }
                    )
                }
                /*const phones = [
                    { title: 'Виктор', phone: '1011979' },
                    { title: 'Елена', phone: '1010711' },
                    { title: 'Евгений', phone: '1011008' },
                    { title: 'Антон', phone: '89254433850' },
                ];*/

                SiebelAppFacade.CTIPanelShow({
                    elementId: 'cti-panel-box',
                    data: {
                        isHide: false,
                        subscribe: DataManager.subscribe,
                        event: DataManager.add,
                        incomingCallLabel: 'Вызов',
                        incomingCallPhone: Phone,
                        skillGroupLabel: 'Skill-группа',
                        skillGroup: '1-ая линия тех.поддержки',
                        callStartSeconds: 0,
                        phones: phones,
                        onPause: this.onPause,
                        onMicrophone: () => console.log('onMicrophone'),
                        onCall: this.OnCall,//(type, phoneNumber)
                        onCallTransfer: this.OnCallTransfer,//(type, phoneNumber)
                        onCallBack: this.onCallBack,
                        switchToCaller: this.switchToCaller, //ARM-114
                        switchToDestination: this.switchToDestination, //ARM-114
                        onCallKeyboard: () => console.log('onCallKeyboard'),
                        onCallOut: () => this.OnHangUp(),
                        setIVRNumber: (phoneNumber) => {
                            //console.log(phoneNumber);
                            const regex = /([0-9*#])/g;
                            phoneNumber = phoneNumber.match(regex).join("");
                            //console.log(phoneNumber);
                            if (phoneNumber !== null || phoneNumber !== "") {
                                const ser = SiebelApp.S_App.GetService("Communications Client");
                                const inPropSet = SiebelApp.S_App.NewPropertySet();
                                //console.log("Value = ", phoneNumber);
                                inPropSet.SetProperty('Value', phoneNumber);
                                ser.InvokeMethod('RICDCSendDTMF', inPropSet);

                                let textPhones = $("#Work_Item_List option").length > 0 ? $("#Work_Item_List option")[0].outerText : "";//Проверяем на наличие консультации
                                let textPhoneslength = $("#Work_Item_List option").length; // ARM-114

                                let consultflg;

                                if (textPhones.indexOf('[L1]') > -1 || textPhones.indexOf('[L2]') > -1) {
                                    consultflg = true;
                                }

                                if (!consultflg) { SiebelAppFacade.eventsMap('ivr', DataManager.add); } //ARM-114}
                                else if (textPhones.indexOf('[L1]') > -1) {
                                    SiebelAppFacade.eventsMap('ivrWithConsultOne', DataManager.add); //ARM-114
                                }
                                else if (textPhones.indexOf('[L2]') > -1) { SiebelAppFacade.eventsMap('ivrWithConsultTwo', DataManager.add) }; //ARM-114
                                //
                            }
                            else DataManager.add('isErrorConnect', {
                                text: 'Некорректно заполнены входные данные',
                            });
                        },

                    }
                });
                SiebelApp.S_App.SetProfileAttr("CDCCTI", "1");
            } else {
                //setTimeout(()=>{
                //DataManager.add('isHideCTIPanel', false);
                DataManager.add('ctiPanelEvents', { pathEvent: 'hidden', value: false }); //ARM-114

                //let onPauseOut = SiebelApp.S_App.GetProfileAttr('onPauseOut');
                // if (onPauseOut !== '1') {
                //     SiebelAppFacade.eventsMap('defaultStateCTI', DataManager.add);} //ARM-114
                SiebelAppFacade.eventsMap('defaultStateCTI', DataManager.add); //ARM-114
                //DataManager.add('changePhoneCTIPanel',Phone);
                // DataManager.add('ctiPanelEvents', { pathEvent: 'input.phone.change', value: Phone }); //ARM-114
                // },0);
            }
        }
        SiebelAppFacade.CommToolbarPhyRenderer.prototype.OnHangUp = function () {
            const Buttons = SiebelAppFacade.GetAllButtons ? SiebelAppFacade.GetAllButtons(SiebelAppFacade.CTIPR) : {};
            this.SetVariable('bActiveCall', false);
            SiebelApp.S_App.SetProfileAttr("CTI Request Id Out", "");//CDR-3968
            //bActiveCall = false;
            if (Buttons["Release Work"].m_state == 'enabled') {
                let r = SiebelApp.S_App.GetService(consts.get("NAME_COMMSVC"));
                r.InvokeMethod('ReleaseWork');
                return;
            }

            //todo call transfer condition
            this.CTI('RICDCHangupCall', 'RI CDC Hangup Call');
            SiebelAppFacade.eventsMap('callOut', DataManager.add); //ARM-114

            const armSocket = getSysPref('RI CDC ARM Socket');//ARM-529
            if (armSocket == 'true') {
                SiebelAppFacade.Send(isHiden(true));
            }

        }

        SiebelAppFacade.CommToolbarPhyRenderer.prototype.OnCallTransfer = function (type, phoneNumber) {
            SiebelApp.S_App.SetProfileAttr("CTI Request Id Out", "");
            if (phoneNumber.length > 12 || phoneNumber.length < 7) return alert('Некорректная длина номера');
            const serviceCached = SiebelApp.S_App.GetService('RRI OUI Cached Service');
            const inPropSet = SiebelApp.S_App.NewPropertySet();
            let command = 'RRIOUIMuteTransferCallToPopupQueueGroup';
            inPropSet.SetProperty('ParamName', 'TransferPhone');
            inPropSet.SetProperty('ParamValue', phoneNumber);
            const armSocket = getSysPref('RI CDC ARM Socket');//ARM-529
            switch (type) {
                case 'transfer':
                    command = 'RRIOUIMuteTransferCallToPopupQueueGroup';
                    SiebelAppFacade.eventsMap('transfer', DataManager.add); //ARM-114

                    // if (armSocket == 'true') {
                    //     // SiebelAppFacade.Send(isHiden(false));//ARM-543
                    // }

                    break;
                case 'transferConsultation':
                    command = 'RRIOUICompleteConsultativeTransfer';
                    SiebelAppFacade.eventsMap('transferWithOutConsult', DataManager.add); //ARM-114

                    const armSocket = getSysPref('RI CDC ARM Socket');//ARM-529
                    // if(armSocket == 'true'){
                    //     //SiebelAppFacade.Send(isHiden(true));
                    // }

                    break;
                default:
                    console.log('unknown type', type);
                    break;
            }
            inPropSet.SetProperty('Command', command);
            SiebelApp.S_App.SetProfileAttr('transferEDU', 'true');
            serviceCached.InvokeMethod('InvokeOUICTICommand', inPropSet);
            bActiveConsult = false;
            bGoHome = true;
            SiebelApp.S_App.SetProfileAttr("CTI Request Id Out", "");
        }
        SiebelAppFacade.CommToolbarPhyRenderer.prototype.OnCall = function (type, phoneNumber) { //Перевод с консультацией
            SiebelApp.S_App.SetProfileAttr("CTI Request Id Out", "");
            if (phoneNumber.length > 12 || phoneNumber.length < 7) return alert('Некорректная длина номера');
            const serviceCached = SiebelApp.S_App.GetService('RRI OUI Cached Service');
            const inPropSet = SiebelApp.S_App.NewPropertySet();
            let command = 'RRIOUIConsultativeTransferCallToPhoneGroup';
            inPropSet.SetProperty('ParamName', 'TransferPhone');
            inPropSet.SetProperty('ParamValue', phoneNumber);
            const armSocket = getSysPref('RI CDC ARM Socket');//ARM-529
            switch (type) {
                case 'transferConsultation':
                    command = 'RRIOUIConsultativeTransferCallToPhoneGroup';
                    //DataManager.add('callStatus','call');
                    // DataManager.add('ctiPanelEvents', { pathEvent: 'status', value: 'call' }); //ARM-114
                    SiebelAppFacade.eventsMap('callWaiting', DataManager.add); //ARM-114

                    if (armSocket == 'true') {
                        SiebelAppFacade.Send(callGive('isHidden', false));//ARM-543
                        SiebelAppFacade.Send(callBack('isHidden', false));//ARM-543
                        SiebelAppFacade.Send(switchToCaller('isHidden', false));//ARM-543

                        SiebelAppFacade.Send(callHold('isDisabled', true));
                        SiebelAppFacade.Send(callTransfer('isDisabled', true));
                        SiebelAppFacade.Send(callTransferConsultation('isDisabled', true));
                        SiebelAppFacade.Send(callIVR('isDisabled', true));
                        SiebelAppFacade.Send(callEnd('isDisabled', true));
                        SiebelAppFacade.Send(callGive('isDisabled', true));
                        SiebelAppFacade.Send(callBack('isDisabled', false));
                        SiebelAppFacade.Send(switchToCaller('isDisabled', true));//ARM-543

                    }

                    break;
                default:
                    console.log('unknown type', type);
                    break;
            }
            inPropSet.SetProperty('Command', command);
            serviceCached.InvokeMethod('InvokeOUICTICommand', inPropSet);
            bActiveConsult = true;
        }
        SiebelAppFacade.CommToolbarPhyRenderer.prototype.onCallBack = function () {
            const serviceCached = SiebelApp.S_App.GetService('RRI OUI Cached Service');
            const inPropSet = SiebelApp.S_App.NewPropertySet();
            inPropSet.SetProperty('Command', 'CancelConsultTransferCall');
            serviceCached.InvokeMethod('InvokeOUICTICommand', inPropSet);
            SiebelAppFacade.eventsMap('finishConsult', DataManager.add); //ARM-114

            const armSocket = getSysPref('RI CDC ARM Socket');//ARM-529
            if (armSocket == 'true') { //defaultStateCTI webSocket
                SiebelAppFacade.Send(callGive('isHidden', true));//ARM-543
                SiebelAppFacade.Send(callBack('isHidden', true));//ARM-543
                SiebelAppFacade.Send(switchToCaller('isHidden', true));//ARM-543

                SiebelAppFacade.Send(callHold('isDisabled', false));
                SiebelAppFacade.Send(callTransfer('isDisabled', false));
                SiebelAppFacade.Send(callTransferConsultation('isDisabled', false));
                SiebelAppFacade.Send(callIVR('isDisabled', false));
                SiebelAppFacade.Send(callEnd('isDisabled', false));

                SiebelAppFacade.Send(callHold('isHold', false)); //ARM-548
            }

        }
        SiebelAppFacade.CommToolbarPhyRenderer.prototype.onPause = function (flag) {


            const serviceCached = SiebelApp.S_App.GetService('RRI OUI Cached Service');
            const inPropSet = SiebelApp.S_App.NewPropertySet();

            const command = flag ? 'HoldCall' : 'HoldReconnectCall';

            let consultflg;
            //SiebelApp.S_App.SetProfileAttr('onPauseOut', '');

            let textPhones = $("#Work_Item_List option").length > 0 ? $("#Work_Item_List option")[0].outerText : "";//получаем номер
            //let textPhoneslength = $("#Work_Item_List option").length; // ARM-114 Проверяем длину work_item

            if (textPhones.indexOf('[L1]') > -1 || textPhones.indexOf('[L2]') > -1) {
                consultflg = true;
            }
            // if (textPhones.indexOf('Call-out') {
            //     consultflg = true;
            // }

            // if ($('button[data-testid=' + 'cti-panel--btn-pause' + '] span svg path')[0].hasAttribute('fill-rule') == true) {
            //     command = 'HoldReconnectCall';
            // } else {
            //     command = 'HoldCall';
            // }

            inPropSet.SetProperty('Command', command);
            serviceCached.InvokeMethod('InvokeOUICTICommand', inPropSet);

            //

            //

            const armSocket = getSysPref('RI CDC ARM Socket');//ARM-529
            switch (command) {
                case 'HoldCall':
                    // if (consultflg == true) SiebelAppFacade.eventsMap('onHoldWithConsult', DataManager.add)
                    // else SiebelAppFacade.eventsMap('onHold', DataManager.add);
                    //if (textPhoneslength == 1) { SiebelAppFacade.eventsMap('onHold', DataManager.add); } //ARM-114}
                    if (!consultflg) { SiebelAppFacade.eventsMap('onHold', DataManager.add); } //ARM-114
                    else if (textPhones.indexOf('[L1]') > -1) {
                        SiebelAppFacade.eventsMap('onHoldWithConsultOne', DataManager.add); //ARM-114
                    }
                    else if (textPhones.indexOf('[L2]') > -1) { SiebelAppFacade.eventsMap('onHoldWithConsultTwo', DataManager.add) }; //ARM-114

                    if (armSocket == 'true') { //ARM-529
                        //SiebelAppFacade.Send(callHoldDisabled(true));
                        SiebelAppFacade.Send(callTransfer('isDisabled', true));
                        SiebelAppFacade.Send(callTransferConsultation('isDisabled', true));
                        SiebelAppFacade.Send(callIVR('isDisabled', true));
                        SiebelAppFacade.Send(callEnd('isDisabled', true));
                        
                        //ARM-551
                        SiebelAppFacade.Send(callGive('isDisabled', true));
                        SiebelAppFacade.Send(callBack('isDisabled', true));
                        SiebelAppFacade.Send(switchToCaller('isDisabled', true));
                        SiebelAppFacade.Send(switchToDestination('isDisabled', true));
                    }
                    break;

                case 'HoldReconnectCall':
                    // if (consultflg == true) SiebelAppFacade.eventsMap('unholdWithConsult', DataManager.add)
                    // else SiebelAppFacade.eventsMap('unhold', DataManager.add);
                    if (!consultflg) { SiebelAppFacade.eventsMap('unhold', DataManager.add); } //ARM-114}
                    else if (textPhones.indexOf('[L1]') > -1) {
                        SiebelAppFacade.eventsMap('unholdWithConsultOne', DataManager.add); //ARM-114
                    }
                    else if (textPhones.indexOf('[L2]') > -1) { SiebelAppFacade.eventsMap('unholdWithConsultTwo', DataManager.add) }; //ARM-114
                    if (armSocket == 'true') { //ARM-529
                        //SiebelAppFacade.Send(callHoldDisabled(true));
                        SiebelAppFacade.Send(callTransfer('isDisabled', false));
                        SiebelAppFacade.Send(callTransferConsultation('isDisabled', false));
                        SiebelAppFacade.Send(callIVR('isDisabled', false));
                        SiebelAppFacade.Send(callEnd('isDisabled', false));
                        //ARM-580
                        SiebelAppFacade.Send(switchToCaller('isDisabled', false));
                        SiebelAppFacade.Send(switchToDestination('isDisabled', false));
                    }
                    break;
            }
        }

        //ARM-114
        SiebelAppFacade.CommToolbarPhyRenderer.prototype.switchToCaller = function () {
            let ser = SiebelApp.S_App.GetService("Communications Client");
            let inPropSet = SiebelApp.S_App.NewPropertySet();
            let outPropSet = SiebelApp.S_App.NewPropertySet();
            outPropSet = ser.InvokeMethod('SwitchToCaller', inPropSet);
            console.log(outPropSet);
            const armSocket = getSysPref('RI CDC ARM Socket');//ARM-529

            if (armSocket == 'true' && Variables.bActiveCall) {
                // SiebelAppFacade.Send(callGive('isHidden', false));//ARM-543
                // SiebelAppFacade.Send(callBack('isHidden', false));//ARM-543
                SiebelAppFacade.Send(switchToCaller('isHidden', true));//ARM-543
                SiebelAppFacade.Send(switchToDestination('isHidden', false));//ARM-543

                SiebelAppFacade.Send(callHold('isDisabled', false));
                SiebelAppFacade.Send(callTransfer('isDisabled', true));
                SiebelAppFacade.Send(callTransferConsultation('isDisabled', true));
                SiebelAppFacade.Send(callIVR('isDisabled', true));
                SiebelAppFacade.Send(callEnd('isDisabled', true));
                SiebelAppFacade.Send(callGive('isDisabled', false));
                SiebelAppFacade.Send(callBack('isDisabled', false));
                SiebelAppFacade.Send(switchToCaller('isDisabled', false));//ARM-543
                SiebelAppFacade.Send(switchToDestination('isDisabled', false));//ARM-543
            }

            //SiebelAppFacade.eventsMap('switchToCaller', DataManager.add); //ARM-114

        }

        SiebelAppFacade.CommToolbarPhyRenderer.prototype.switchToDestination = function () {
            let ser = SiebelApp.S_App.GetService("Communications Client");
            let inPropSet = SiebelApp.S_App.NewPropertySet();
            let outPropSet = SiebelApp.S_App.NewPropertySet();
            outPropSet = ser.InvokeMethod('SwitchToDestination', inPropSet);
            console.log(outPropSet);
            const armSocket = getSysPref('RI CDC ARM Socket');//ARM-529

            if (armSocket == 'true' && Variables.bActiveCall) {
                // SiebelAppFacade.Send(callGive('isHidden', false));//ARM-543
                // SiebelAppFacade.Send(callBack('isHidden', false));//ARM-543
                SiebelAppFacade.Send(switchToCaller('isHidden', false));//ARM-543
                SiebelAppFacade.Send(switchToDestination('isHidden', true));//ARM-543

                SiebelAppFacade.Send(callHold('isDisabled', false));
                SiebelAppFacade.Send(callTransfer('isDisabled', true));
                SiebelAppFacade.Send(callTransferConsultation('isDisabled', true));
                SiebelAppFacade.Send(callIVR('isDisabled', true));
                SiebelAppFacade.Send(callEnd('isDisabled', true));
                SiebelAppFacade.Send(callGive('isDisabled', false));
                SiebelAppFacade.Send(callBack('isDisabled', false));
                SiebelAppFacade.Send(switchToCaller('isDisabled', false));//ARM-543
                SiebelAppFacade.Send(switchToDestination('isDisabled', false));//ARM-543
            }

            //SiebelAppFacade.eventsMap('switchToDestination', DataManager.add); //ARM-114

        }

        SiebelAppFacade.CommToolbarPhyRenderer.prototype.IncomingCallShow = function () {
            const Buttons = SiebelAppFacade.GetAllButtons ? SiebelAppFacade.GetAllButtons(SiebelAppFacade.CTIPR) : {};
            if (Buttons["Release Work"].m_state == 'enabled') {
                let r = SiebelApp.S_App.GetService(consts.get("NAME_COMMSVC"));
                r.InvokeMethod('ReleaseWork');
                //RUAAAQP  исправление мигания Title при переводе звонка
                clearInterval(this.m_timerId);
                $("title").text(this.m_oldtitle);
                return;
            }
            const phoneCount = $("#Work_Item_List option").length;
            SiebelApp.S_App.SetProfileAttr('phoneCount', phoneCount);
            let Phone = phoneCount > 0 ? $("#Work_Item_List option")[0].outerText : "";
            if (Phone.indexOf("WrapUp") == -1) {
                SiebelApp.S_App.SetProfileAttr("CDCAccountId", "");
                SiebelApp.S_App.SetProfileAttr("CDCCallerName", "");
                SiebelApp.S_App.SetProfileAttr("FoundCompId", "");
                SiebelApp.S_App.SetProfileAttr("NeedOpenFlg", "");
                SiebelApp.S_App.SetProfileAttr("Identified", "N");//CDR-3360
                SiebelApp.S_App.SetProfileAttr("CDCLeadId", "");//ARM-154
                SiebelApp.S_App.SetProfileAttr("FoundLeadsId", "");//ARM-154
                const time = new Date();
                const incomingCallTime = time.toLocaleTimeString("ru-RU", { "hour12": false });

                const OrgList = [];
                const NamesList = [];
                const organizations = [];//ARM-323
                const fio = [];//ARM-323
                let companyGroup = '';
                let clientCategory = '';

                Phone = Phone.slice(Phone.indexOf(":") + 1);
                //if(Phone.indexOf('-Xfer')>-1)Phone = Phone.slice(0,Phone.indexOf('-Xfer')-1);
                if (Phone.indexOf('-Xfer') > -1 || SiebelApp.S_App.GetProfileAttr('CTI Request Id').length > 0) {
                    const serviceWF = SiebelApp.S_App.GetService('Workflow Process Manager');
                    const psInp = SiebelApp.S_App.NewPropertySet();
                    let psOut = SiebelApp.S_App.NewPropertySet();
                    psInp.SetProperty('ProcessName', 'RI CDC Request Info')
                    psInp.SetProperty('Object Id', SiebelApp.S_App.GetProfileAttr('CTI Request Id'));
                    psOut = serviceWF.InvokeMethod('RunProcess', psInp);
                    Phone = psOut.childArray[0].propArray['Phone'];
                    clientCategory = psOut.childArray[0].propArray['Category'];
                    NamesList.push(psOut.childArray[0].propArray['FullName']);
                    OrgList.push(psOut.childArray[0].propArray['OrganizationName']);

                } else {


                    const serviceWF = SiebelApp.S_App.GetService('Workflow Process Manager');
                    const psInp = SiebelApp.S_App.NewPropertySet();
                    let psOut = SiebelApp.S_App.NewPropertySet();
                    psInp.SetProperty('ProcessName', 'RI CDC Search Client Process');
                    psInp.SetProperty('sPhoneNum', Phone);
                    psInp.SetProperty('SimFlg', 'Y');//
                    psOut = serviceWF.InvokeMethod('RunProcess', psInp);
                    let Num = +psOut.childArray[0].propArray.OutNum;
                    let NumLeads = +psOut.childArray[0].propArray.OutNumLeads;//ARM-154

                    if (Num > 1 && psOut.childArray[0].childArray.length === 1) {
                        Num = 1;
                    }

                    let ResIO = Num > 0 ? psOut.childArray[0].childArray[0].childArray[0].childArray : [];
                    let ResLeadsIO = NumLeads > 0 ? psOut.childArray[0].childArray[1].childArray[0].childArray : [];//ARM-154

                    const ArrayLength = ResIO.length;
                    const ArrayLengthLeads = ResLeadsIO.length;

                    const Res = [];
                    const aAccountId = [];
                    let AccountId = '';
                    let CallerName = '';
                    let CurOrgNameShort = '';
                    let CurFullName = '';
                    let CurAccountId = '';
                    let inn = '';
                    let cnum = '';



                    if (Num > 0) {
                        SiebelApp.S_App.SetProfileAttr("Identified", "Y");
                        for (let i = 0; i < ArrayLength; i++) {
                            Res.push(ResIO[i].propArray);
                            CurOrgNameShort = Res[i]['Client Name'];//new 
                            //CurOrgNameShort = Res[i]['RI Client Name Short'];
                            CurFullName = Res[i]['RI Contact Person Name'];//new 
                            //CurFullName = Res[i]['RI Full Name'];
                            CurAccountId = Res[i]['Parent Id'];//new
                            //CurAccountId = Res[i]['Account Id'];
                            //inn = Res[i]['inn'];
                            if(Res[i].hasOwnProperty('inn')) inn = Res[i]['inn'];
                            //cnum = Res[i]['cnum'];
                            if(Res[i].hasOwnProperty('cnum')) cnum = Res[i]['cnum'];
                            if (OrgList.indexOf(CurOrgNameShort) == -1) OrgList.push(CurOrgNameShort ? CurOrgNameShort : '');
                            if (NamesList.indexOf(CurFullName) == -1) NamesList.push(CurFullName ? CurFullName : '');
                            if (aAccountId.indexOf(CurAccountId) == -1) aAccountId.push(CurAccountId ? CurAccountId : '');//RUAVSVA 01.04.2022 CDR - 3073
                            if (aAccountId !== "") organizations.push({
                                "name": CurOrgNameShort ? CurOrgNameShort : '',
                                "id": CurAccountId ? CurAccountId : '',
                                "inn": inn ? inn : '',
                                "cnum": cnum ? cnum : '',
                            });
                        }
                        if (Num == 1) {
                            AccountId = Res[0]['Parent Id'];//new 
                            //AccountId = Res[0]['Account Id'];
                            SiebelApp.S_App.SetProfileAttr('CDCAccountId', AccountId);
                            CallerName = Res[0]['RI Contact Person Name'];//new 
                            //CallerName = Res[0]['RI Full Name'];
                            SiebelApp.S_App.SetProfileAttr('CDCCallerName', CallerName);
                        }
                        companyGroup = Res[0]['GCC Id'];//new 
                        //companyGroup = Res[0]['RI GCC'];
                        clientCategory = Res[0]['RI CDC Client Category'];//new 
                        //clientCategory = Res[0]['RI_CDC_Client_Category'];

                        /***************************************************¶
                         RUAVSVA 01.04.2022 CDR - 3073
                         ***************************************************/
                        let profile = SiebelApp.S_App.GetProfileAttr('FoundCompId');
                        for (i = 0; i < 100 && i < aAccountId.length; i++) {
                            profile += aAccountId[i] + ';';
                        }
                        SiebelApp.S_App.SetProfileAttr('FoundCompId', profile);
                        SiebelApp.S_App.SetProfileAttr('NeedOpenFlg', 'Y');//RUAVSVA 17.04.2022 CDR-3074

                        /***************************************************
                         RUAVSVA 01.04.2022 CDR - 3073
                         ***************************************************/
                    } else if (NumLeads > 0) {
                        SiebelApp.S_App.SetProfileAttr("Identified", "Y");
                        for (let i = 0; i < ArrayLengthLeads; i++) {
                            Res.push(ResLeadsIO[i].propArray);
                            CurOrgNameShort = Res[i]['RI Full Company Name'];
                            CurFullName = Res[i]['RI Full Company Name'];
                            CurAccountId = Res[i]['Row Id'];
                            if (OrgList.indexOf(CurOrgNameShort) == -1) OrgList.push(CurOrgNameShort ? CurOrgNameShort : '');
                            if (NamesList.indexOf(CurFullName) == -1) NamesList.push(CurFullName ? CurFullName : '');
                            if (aAccountId.indexOf(CurAccountId) == -1) aAccountId.push(CurAccountId ? CurAccountId : '');
                        }
                        if (NumLeads == 1) {
                            AccountId = Res[0]['Row Id'];
                            SiebelApp.S_App.SetProfileAttr('CDCLeadId', AccountId);
                            CallerName = Res[0]['RI Full Company Name'];
                            SiebelApp.S_App.SetProfileAttr('CDCCallerName', CallerName);
                        }
                        companyGroup = "";
                        clientCategory = "Потеницальный клиент";
                        let profile = SiebelApp.S_App.GetProfileAttr('FoundLeadsId');
                        for (i = 0; i < 100 && i < aAccountId.length; i++) {
                            profile += aAccountId[i] + ';';
                        }
                        SiebelApp.S_App.SetProfileAttr('FoundLeadsId', profile);
                        SiebelApp.S_App.SetProfileAttr('NeedOpenFlg', 'Y');//RUAVSVA 17.04.2022 CDR-3074
                    }
                    else {
                        SiebelApp.S_App.SetProfileAttr("Identified", "N");
                        SiebelApp.S_App.SetProfileAttr('NeedOpenFlg', 'Y');//RUAVSVA 17.04.2022 CDR-3074
                    }



                }

                const data = {}
                /*{ incomingCallTime: incomingCallTime,
                 //waitingTimeLine: '00:05',
                 organizations: OrgList,
                 companyGroup: companyGroup,
                 clientCategory: clientCategory,
                 phone:  Phone,
                 fio:NamesList,
                 //skillGroup: 'Corporate VIP',
                 //additionalGroup: '1011032',
                 //serviceScenario: 'Прямой звонок клиента на VIP-линию',
               }*/

                data["incomingCallTime"] = incomingCallTime;
                data["phone"] = Phone;
                if (OrgList.length > 0) data["organizations"] = OrgList;
                if (NamesList.length > 0) data["fio"] = NamesList;
                if (companyGroup != "") data["companyGroup"] = companyGroup;
                if (clientCategory != "") data["clientCategory"] = clientCategory;

                //console.log(data);
                //Добавить inn и cnum
                let login = SiebelApp.S_App.GetProfileAttr('Login Name');
                login = login.toLowerCase();
                let trackingId = SiebelApp.S_App.GetProfileAttr("CTI TrackingID Inbound");
                trackingId = formattedTracking(trackingId);
                dataSend = {
                    "event": "item",
                    "topic": "incomingCall",
                    "message": {
                        "item": {
                            "login": login,
                            "phone": Phone,
                            "organizations": organizations,
                            "fio": NamesList,
                            "incomingCallTime": incomingCallTime,
                            "companyGroup": companyGroup,
                            "clientCategory": clientCategory,
                            "trackingId": trackingId,
                        }
                    }
                }
                const armSocket = getSysPref('RI CDC ARM Socket');
                if (armSocket == 'true') {
                    SiebelAppFacade.Send(dataSend);
                }

                if ($("#incoming-call-modal").length == 0) {
                    SiebelAppFacade.IncomingCallShow({
                        elementId: 'modals-box',
                        isOpen: true,
                        subscribe: DataManager.subscribe,
                        onAcceptIncomingCall: () => this.ShowCTI(),
                        data: data
                    });
                } else {
                    //setTimeout(()=>{
                    DataManager.add('isOpenModalCall', true);
                    //DataManager.add('isOpenModalCall', false);

                    DataManager.add('dataUpdateModalCall', data);
                    //},0);
                }
            }
        }
        SiebelAppFacade.CommToolbarPhyRenderer.prototype.IncomingCallHide = function () {
            DataManager.add('isOpenModalCall', false);
           
            let Phone = $("#Work_Item_List option").length > 0 ? $("#Work_Item_List option")[0].outerText : "";
            let WrapUp;
            if (Phone.indexOf("WrapUp") > -1) WrapUp = true;
            const armSocket = getSysPref('RI CDC ARM Socket');
            if(armSocket == 'true' && Variables.firstLoadIncomingcCall == false && WrapUp != true){
                const message = {
                    "isOpen": false
                  };
            SiebelAppFacade.Send(incomingCall("view", message));
                
            }

            this.SetVariable('firstLoadIncomingcCall', false);
        }
        SiebelAppFacade.CommToolbarPhyRenderer.prototype.CTIHide = function () {
            let Phone = $("#Work_Item_List option").length > 0 ? $("#Work_Item_List option")[0].outerText : "";
            let WrapUp;
            if (Phone.indexOf("WrapUp") > -1) WrapUp = true;

            const armSocket = getSysPref('RI CDC ARM Socket');//ARM-529
            if (armSocket == 'true' && Variables.firstLoad == false && WrapUp != true) {
                SiebelAppFacade.Send(isHiden(true));
            }

            this.SetVariable('bActiveCall', false);
            this.SetVariable('notCallShow', false);
            this.SetVariable('firstLoad', false);
            //bActiveCall = false;
            //DataManager.add('isHideCTIPanel', true);
            DataManager.add('ctiPanelEvents', { pathEvent: 'hidden', value: true }); //ARM-114

            SiebelApp.S_App.SetProfileAttr("CTI Request Id", '');
            SiebelApp.S_App.SetProfileAttr("CTI TrackingID", '');
        }
        SiebelAppFacade.CommToolbarPhyRenderer.prototype.CleanAllWorkItem = function () {
            const CommunicationsClientService = SiebelApp.S_App.GetService(consts.get("NAME_COMMSVC"));
            const InPS = CCFMiscUtil_CreatePropSet();
            InPS.SetProperty("MediaProfile", "AICD Profile");
            CommunicationsClientService.InvokeMethod("CleanAllWorkItem", InPS);//#1
        }
        SiebelAppFacade.CommToolbarPhyRenderer.prototype.GetReady = function () {
            let Result = SiebelAppFacade.CTI("RRIOUIAgentAvailable", "RRIOUICommAgentAvailable");
            const DataManager = SiebelAppFacade.DMPL;
            if (DataManager) {
                DataManager.add("changeReadyStatus", true);
                if (Result == -1) {
                    SiebelAppFacade.CTI("RICDCSignOff", "RI CDC Sign Off");
                    DataManager.add('isErrorConnect', { flag: true, text: ConnectError });
                    DataManager.add('changeCurrentStatus', 15);
                    SiebelApp.S_App.SetProfileAttr("CDCCTIStatus", 15);
                } else {
                    DataManager.add('changeCurrentStatus', 16);
                    SiebelApp.S_App.SetProfileAttr("CDCCTIStatus", 16);
                }
                return Result;
            }
        }
        SiebelAppFacade.CommToolbarPhyRenderer.prototype.showStatusText = function (e, t) {
            const DataManager = SiebelAppFacade.DMPL;
            //DataManager ? console.log(DataManager) : console.log('Пусто');
            //console.log(DataManager);
            //SiebelApp.S_App.SetProfileAttr('disconnected consultation', '');
            let text = '';
            const armSocket = getSysPref('RI CDC ARM Socket');//ARM-529
            if (DataManager && $('#header-box span[class^=' + 'Badgestyles__Item' + ']').length == 0) {
                switch (e) {
                    case 'Cannot Mute Transfer WorkItem':
                    case 'Cannot Consult Transfer WorkItem':
                        text = 'Абонент занят/вне сети.';
                        break;
                    case 'Party disconnected from consultation':
                        text = 'Клиент положил трубку.';
                        //SiebelApp.S_App.SetProfileAttr('disconnected consultation', 'true');

                        SiebelAppFacade.eventsMap('defaultStateCTI', DataManager.add); //ARM-114
                        if (armSocket == 'true') { //defaultStateCTI webSocket
                            SiebelAppFacade.Send(callGive('isHidden', true));//ARM-543
                            SiebelAppFacade.Send(callBack('isHidden', true));//ARM-543
                            SiebelAppFacade.Send(switchToCaller('isHidden', true));//ARM-543
                            SiebelAppFacade.Send(switchToDestination('isHidden', true));

                            SiebelAppFacade.Send(callHold('isDisabled', false));
                            SiebelAppFacade.Send(callTransfer('isDisabled', false));
                            SiebelAppFacade.Send(callTransferConsultation('isDisabled', false));
                            SiebelAppFacade.Send(callIVR('isDisabled', false));
                            SiebelAppFacade.Send(callEnd('isDisabled', false));

                            SiebelAppFacade.Send(callHold('isHold', false)); //ARM-548
                        }

                        break;
                    default:
                        text = '';
                        break;
                }
                if (text !== '') {
                    DataManager.add('isErrorConnect', { text: text });
                }
            }
        }
        SiebelAppFacade.CommToolbarPhyRenderer.prototype.updateHTMLControl = function (e, t, n) {
            let sStatus = '';
            let bStartTimer = false;
            const armSocket = getSysPref('RI CDC ARM Socket');//ARM-529
            // let discons = SiebelApp.S_App.GetProfileAttr('disconnected consultation');
            // if(e == 'Party disconnected from consultation') console.log('her');
            // if(discons == true){
            //     SiebelAppFacade.eventsMap('defaultStateCTI', DataManager.add); //ARM-114
            //     SiebelApp.S_App.SetProfileAttr('disconnected consultation', '');
            // }
            switch (t) {
                /*case 'starttimer':
                    this.toolbar.current.callTimer.current.startTime(new Date(n[0] * 1000));
                    break;
                case 'stoptimer':
                    if (this.toolbar.current.callTimer.current.timer) this.toolbar.current.callTimer.current.stopTime();
                    break;*/
                case 'value':
                    if (e.m_name === 'Work Item List') {
                        /**/
                        //this.IncomingCallShow();
                        //this.aButtons[e.m_name] = e;
                        if (n[0]) {
                            let Phone = $("#Work_Item_List option").length > 0 ? $("#Work_Item_List option")[0].outerText : "";
                            if (Phone.indexOf('Consult') > -1) {
                                bActiveConsult = true;
                            } else if (Phone.indexOf('Consult') == -1 && bActiveConsult) {
                                //DataManager.add('callStatus','start');
                                //DataManager.add('ctiPanelEvents', { pathEvent: 'status', value: 'start' }); //ARM-114(asdf)
                                if (Phone.indexOf('->Call:') > -1) console.log('endcall');
                                bActiveConsult = false;
                            }
                            if (Phone.indexOf("ID") > -1 || Phone.indexOf("WrapUp") > -1) {
                                this.IncomingCallHide();
                                this.CTIHide();
                                if (Phone.indexOf("ID") > -1) {
                                    //RUAAAQP CDR-2917 исправление мигания Title при переводе звонка
                                    clearInterval(this.m_timerId);
                                    $("title").text(this.m_oldtitle);
                                    clearTimeout(+$("#Working_Time").attr("timerid"));
                                    //$("#Work_Item_List").children().remove();
                                    this.CleanAllWorkItem();

                                    if (bGoHome) {
                                        setTimeout(() => {
                                            SiebelApp.S_App.GotoView('RI CDC HomePage View');
                                        }, 1000);
                                        bGoHome = false;
                                    }
                                    //перезапуск CTI после перевода звонка START
                                    let r = SiebelApp.S_App.GetService(consts.get("NAME_COMMSVC"));
                                    r.InvokeMethod("ShellUIExit");//#2
                                    SiebelApp.S_App.CommToolbar.DisableAllButtons();//#3
                                    SiebelApp.S_App.CommToolbar.ParseParameters();//#4
                                    let Obj = {
                                        bPush: true,
                                        bRun: true,
                                        bStarted: false,
                                        bfirstTime: true,
                                        iInterval: 3,
                                        iPushCheckInterval: 0,
                                        iRetryBeforeStopPush: 0,
                                        sCmd: "SWECmd=WaitForCmd&SWEService=Communications Client",
                                        sStopPushString: "",
                                    }
                                    SiebelApp.S_App.CommToolbarUtil.StartPush(Obj);//#5
                                    SiebelApp.S_App.CommToolbar.InitCTIToolbar();//#6
                                    setTimeout((s) => {
                                        console.log("try to connect");
                                        SiebelAppFacade.DMPL.add("changeReadyStatus", true);
                                        SiebelAppFacade.DMPL.add('isErrorConnect', { text: ConnectError });
                                        SiebelAppFacade.DMPL.add('changeCurrentStatus', 15);
                                        SiebelApp.S_App.SetProfileAttr("CDCCTIStatus", 15);
                                        s.InvokeMethod("RICDCSignOn");
                                        let t1;
                                        t1 = setInterval((s) => {
                                            console.log("try to get available");
                                            let Result = SiebelAppFacade.CTIPR.GetReady();
                                            if (Result != -1) {
                                                SiebelAppFacade.DMPL.add("changeReadyStatus", false);
                                                clearInterval(t1);
                                            } else SiebelAppFacade.CTI("RICDCSignOn", "RI CDC Sign On");
                                            //s.InvokeMethod("RRIOUIAgentAvailable");
                                            //SiebelAppFacade.CTI('RRIOUIAgentAvailable','RRIOUICommAgentAvailable');
                                            //SiebelAppFacade.DMPL.add('changeCurrentStatus', 16);
                                            //SiebelApp.S_App.SetProfileAttr("CDCCTIStatus",16);

                                        }, 3000, s);
                                    }, 3000, r);
                                    //перезапуск CTI после перевода звонка END
                                }
                                break;
                            }
                            Phone = Phone.slice(Phone.indexOf(":") + 1);
                            if (Phone.indexOf('-Xfer') > -1) {
                                Phone = Phone.slice(0, Phone.indexOf('-Xfer') - 1);
                                bGoHome = true;
                            }
                            //bGoHome = true;
                            //RUAVSVA

                            let textPhone = $("#Work_Item_List option").length > 0 ? $("#Work_Item_List option")[0].outerText : "";
                            if (textPhone.indexOf('*Call:') > -1 && textPhone.indexOf('-Xfer') == -1) {
                                //Phone = Phone.slice(Phone.indexOf(':') + 1, );
                                bGoHome = false;
                            }
                            //RUAVSVA
                            //RUAVSVA CDR-3968(Если выхов исходящий, то карточку не открываем)
                            if (textPhone.indexOf('*Call-Out:') > -1) {
                                this.SetVariable('notCallShow', true);
                            }
                            //
                            const time = new Date();
                            const incomingCallTime = time.toLocaleTimeString("ru-RU", { "hour12": false });
                            const data = {
                                incomingCallTime: incomingCallTime,
                                phone: Phone
                            };
                            const transferEDU = SiebelApp.S_App.GetProfileAttr('transferEDU');
                            if (((e.m_name === 'Work Item List' && e.value !== '') && transferEDU !== 'true') || e.m_name !== 'Work Item List') {
                                this.CTI('RRIGetEDUData', 'RI CDC GetEDUData');
                            }
                            /*if($("#incoming-call-modal").length==0){
                                                SiebelAppFacade.IncomingCallShow({
                                                          isLoading:true,
                                                          elementId: 'modals-box',
                                                          isOpen: true,
                                                          subscribe: DataManager.subscribe,
                                                          onAcceptIncomingCall: () => this.ShowCTI(),
                                                          data: data
                                                        });
                                                }*/
                            if (!/*bActiveCall*/Variables.bActiveCall && !Variables.notCallShow) {
                                this.SetVariable('bActiveCall', true);
                                //bActiveCall = true;
                                //DataManager.add('isOpenModalCall', true);
                                //DataManager.add('dataUpdateModalCall',data);
                                setTimeout(() => {
                                    this.IncomingCallShow();
                                }, 0);
                            }
                            //Открываем CTI - панель на исходящем
                            else if ((n[0].indexOf("*Call-Out:") > -1 && n[0].indexOf("-Consult") == -1)) {
                                if(Variables.firstCallOut){
                                    this.SetVariable('firstCallOut', false);
                                    this.ShowCTI();
                                }
                                //DataManager.add('ctiPanelEvents', { pathEvent: 'hidden', value: false }); //Просто открываем CTI
                            }
                            /*else if (n[0].indexOf(" *") > 0)//если вызов принят в avaya one-x
                            {
                                DataManager.add('isOpenModalCall', false);
                                this.ShowCTI();
                            }*/
                            //this.aButtons[e.m_name].mValue = n[0];
                        } else {
                            // Признак завершения звонка, считаем, что звонок завершился, если поле Work Item List очищается
                            this.IncomingCallHide();
                            this.CTIHide();

                            //SiebelApp.S_App.SetProfileAttr('CDCCTI', '0');


                            SiebelApp.S_App.SetProfileAttr('transferEDU', '');//ARM-114

                            this.SetVariable('firstCallOut', true);

                            //ARM-360 START
                            if (SiebelApp.S_App.GetProfileAttr('ws') == 'true' && SiebelApp.S_App.GetProfileAttr('CDCCTIPostponedStatus') == '1') {
                                const response = {
                                    "topic": "userStatus",
                                    "event": "item",
                                    "message": {
                                        "item": {
                                            "statusCode": SiebelApp.S_App.GetProfileAttr('CDCCTIStatus'),
                                            "changedAfterCall": "1"
                                        }
                                    }
                                };
                                SiebelAppFacade.Send(response);
                                SetProfileAttr('ws', '');

                            }
                            //ARM-360 END

                            if (SiebelApp.S_App.GetProfileAttr('futureStatus') !== '') document.dispatchEvent(myEvent);//RUAVSVA Новая статусная модель
                            if (SiebelApp.S_App.GetProfileAttr('ws') == 'true' && SiebelApp.S_App.GetProfileAttr('CDCCTIPostponedStatus') == '1') {
                                const response = {
                                    "topic": "userStatus",
                                    "event": "item",
                                    "message": {
                                        "item": {
                                            "statusCode": SiebelApp.S_App.GetProfileAttr('CDCCTIStatus'),
                                            "changedAfterCall": "1"
                                        }
                                    }
                                };
                                SiebelAppFacade.Send(response);

                            }
                            if (bGoHome || (SiebelApp.S_App.GetProfileAttr("ActiveViewName").indexOf("RI CDC") == -1 && document.URL.indexOf("fins_cdc") > -1)) SiebelApp.S_App.GotoView('RI CDC HomePage View');
                            /*if (
                                this.state.ctiButtons['Work Item List'].mValue &&
                                this.state.ctiButtons['Work Item List'].mValue !== ''
                            )
                                this.bCancelCall = true;*/
                            //this.aButtons[e.m_name].mValue = '';
                        }
                        //this.setState({ ctiButtons: this.aButtons, newCallInput: '' });
                    }
                    switch (e.m_type) {
                        // Заполнение массива активных вызовов, взято из core-cti.js
                        case 'combo box': {
                            const callOptions = [];
                            for (let i = 0; i < n.length; i += 2)
                                if (i + 1 < n.length) {
                                    callOptions.push({ value: n[i], name: n[i + 1] });
                                }
                            //this.setState({ callOptions: callOptions });
                            break;
                        }
                        default:
                    }
                    break;
                case 'state':
                    const DataManagerPL = SiebelAppFacade.DMPL;
                    const Buttons = SiebelAppFacade.GetAllButtons ? SiebelAppFacade.GetAllButtons(SiebelAppFacade.CTIPR) : {};
                    if (e.m_name == 'RI CDC Sign On' && e.m_state == 'enabled') {
                        document.dispatchEvent(eSignOnEnabled);
                    }
                    if (e.m_name == 'RI CDC Sign Off' && e.m_state == 'enabled') {
                        document.dispatchEvent(eSignOffEnabled);
                    }
                    if (e.m_name == 'RRIOUICommAgentAvailable' && e.m_state == 'disabled') {
                        if (Buttons["Agent State For Work Item"].m_state == 'enabled') {
                            if (DataManagerPL) {
                                DataManagerPL.add('changeCurrentStatus', 16);
                                SiebelApp.S_App.SetProfileAttr("CDCCTIStatus", 16);
                            }
                        }
                    }
                    if (e.m_name == 'Agent State For Work Item') {
                        if (e.m_state == 'disabled') {

                            if (Buttons["RI CDC Sign On"]) {
                                let State = 15;
                                if (Buttons["RI CDC Sign Off"].m_state == 'enabled') { //CTI Panel Enabled
                                    if (Buttons["RRIOUICommAgentAvailable"].m_state == 'enabled') {
                                        State = 15;//Not Ready Yet
                                    } else if (Buttons["Agent State For Work Item"].m_state == 'enabled') {
                                        State = 16;//Ready//changestatus
                                    }
                                }
                            }
                            if (DataManagerPL) {
                                DataManagerPL.add('changeCurrentStatus', 15);
                                SiebelApp.S_App.SetProfileAttr("CDCCTIStatus", 15);
                            }
                        } else {
                            document.dispatchEvent(eAgentAvailableEnabled);
                        }
                    } else if (e.m_name == 'RRIOUICompleteConsultative') {
                        if (e.m_state == 'disabled') { //Консультация завершается и кнопка передать недоступна
                            let consultflg;
                            let textPhones = $("#Work_Item_List option").length > 0 ? $("#Work_Item_List option")[0].outerText : "";//получаем номер

                            if (textPhones.indexOf('[L1]') > -1 || textPhones.indexOf('[L2]') > -1) {
                                consultflg = true;
                            }

                            if (!consultflg) {
                                SiebelAppFacade.eventsMap('defaultStateCTI', DataManager.add); //ARM-114
                                if (armSocket == 'true' && Variables.bActiveCall) { //defaultStateCTI webSocket
                                    SiebelAppFacade.Send(callGive('isHidden', true));//ARM-543
                                    SiebelAppFacade.Send(callBack('isHidden', true));//ARM-543
                                    SiebelAppFacade.Send(switchToCaller('isHidden', true));//ARM-543

                                    SiebelAppFacade.Send(callHold('isDisabled', false));
                                    SiebelAppFacade.Send(callTransfer('isDisabled', false));
                                    SiebelAppFacade.Send(callTransferConsultation('isDisabled', false));
                                    SiebelAppFacade.Send(callIVR('isDisabled', false));
                                    SiebelAppFacade.Send(callEnd('isDisabled', false));

                                    SiebelAppFacade.Send(callHold('isHold', false)); //ARM-548
                                }
                            }

                        } else { //Консультация начинается(вызов принят)
                            SiebelAppFacade.eventsMap('callWithConsult', DataManager.add); //ARM-114

                            if (armSocket == 'true' && Variables.bActiveCall) {
                                // SiebelAppFacade.Send(callGive('isHidden', false));//ARM-543
                                // SiebelAppFacade.Send(callBack('isHidden', false));//ARM-543
                                // SiebelAppFacade.Send(switchToCaller('isHidden', false));//ARM-543

                                SiebelAppFacade.Send(callHold('isDisabled', false));
                                SiebelAppFacade.Send(callTransfer('isDisabled', true));
                                SiebelAppFacade.Send(callTransferConsultation('isDisabled', true));
                                SiebelAppFacade.Send(callIVR('isDisabled', true));
                                SiebelAppFacade.Send(callEnd('isDisabled', true));
                                SiebelAppFacade.Send(callGive('isDisabled', false));
                                SiebelAppFacade.Send(callBack('isDisabled', false));
                                SiebelAppFacade.Send(switchToCaller('isDisabled', false));//ARM-543
                            }

                        }


                    }

                    else if (e.m_name == 'RI CDC switchToCaller') {
                        let textPhone = $("#Work_Item_List option").length > 0 ? $("#Work_Item_List option")[0].outerText : "";
                        if (e.m_state == 'disabled') {

                        }
                        else {
                            if (Buttons['RRIOUICompleteConsultative'].m_state == 'enabled') {
                                SiebelAppFacade.eventsMap('switchToDestination', DataManager.add);


                            }; //ARM-114
                        }
                    }

                    else if (e.m_name == 'RI CDC switchToDestination') {
                        let textPhone = $("#Work_Item_List option").length > 0 ? $("#Work_Item_List option")[0].outerText : "";
                        if (e.m_state == 'disabled') {

                        }
                        else {
                            if (Buttons['RRIOUICompleteConsultative'].m_state == 'enabled') {
                                SiebelAppFacade.eventsMap('switchToCaller', DataManager.add);

                            }; //ARM-114
                        }
                    }

                    else if (e.m_name == 'Pause Work Item') {
                        // if(e.m_state == 'disabled'){console.log('disabled');}
                        // else console.log('enabled');
                    }

                    else if (e.m_name == 'Resume Work Item') {
                        const bHold = e.m_state == 'enabled' ? true : false;
                        if (DataManager) {
                            //DataManager.add('callHold',bHold);
                            //DataManager.add('ctiPanelEvents', { pathEvent: 'btn.hold.pause', value: bHold }); //ARM-144
                            //DataManager.add('ctiPanelCallOutDisabled', bHold);
                            //DataManager.add('ctiPanelEvents', { pathEvent: 'btn.out.disabled', value: bHold }); //ARM-144
                            //DataManager.add('ctiPanelCallTransferConsultationDisabled', bHold);
                            //DataManager.add('ctiPanelCallConsultationEvents', { pathEvent: 'disabled', value: bHold }); //ARM-144
                            //DataManager.add('ctiPanelCallTransferDisabled', bHold);
                            //DataManager.add('ctiPanelCallTransferEvents', { pathEvent: 'disabled', value: bHold }); // ARM-144
                        }
                    }
                    break;
                default:
                    //this.aButtons[e.m_name] = e;
                    if (e.m_name === 'RRIOUICommAgentAvailable') {
                        if (e.m_state === 'enabled' && SiebelApp.S_App.GetProfileAttr('RRI CTI OUI Agent Status') !== '') {
                            sStatus = SiebelApp.S_App.GetProfileAttr('RRI CTI OUI Agent Status');
                            bStartTimer = true;
                        }
                        /*if (e.m_state === 'disabled' && this.aButtons['Agent State For Work Item'].m_state === 'enabled') {
                            sStatus = 'Готов';
                            bStartTimer = true;
                        }*/
                        if (
                            e.m_state === 'enabled' &&
                            SiebelApp.S_App.GetProfileAttr('RRI CTI OUI Agent Status') === 'Активен'
                        ) {
                            sStatus = 'Не готов';
                            bStartTimer = true;
                        }
                    }
                    /*if (sStatus !== '') {
                        this.setState({ ctiButtons: this.aButtons, statusVal: sStatus });
                    } else {
                        this.setState({ ctiButtons: this.aButtons });
                    }
                    if (bStartTimer && !this.toolbar.current.statusTimer.current.timer)
                        this.toolbar.current.statusTimer.current.startTime();*/
                    break;
            }
        }
        SiebelAppFacade.CommToolbarPhyRenderer.prototype.ShowUI = function () {
            this.OldShowUI();
            SiebelApp.S_App.SetProfileAttr("CDCCTI", "0");
            SiebelAppFacade.IncomingCallShow({
                elementId: 'modals-box',
                isOpen: false,
                subscribe: DataManager.subscribe,
                onAcceptIncomingCall: () => this.ShowCTI(),
                data: {
                    incomingCallTime: '11:28:07',
                    waitingTimeLine: '00:05',
                    organizations: ['ОАО Газпром', 'Яндекс'],
                    companyGroup: 'Газпром',
                    clientCategory: 'VIP',
                    phone: '+74957654321',
                    fio: ['Иванов Иван Иванович'],
                    skillGroup: 'Corporate VIP',
                    additionalGroup: '1011032',
                    serviceScenario: 'Прямой звонок клиента на VIP-линию',
                }
            });

            if (typeof SiebelAppFacade.CTIPR === 'undefined') SiebelAppFacade.CTIPR = this;
            if (typeof SiebelAppFacade.GetCTIButtons === 'undefined') SiebelAppFacade.GetAllButtons = this.GetAllButtons;
            if (typeof SiebelAppFacade.CTI === 'undefined') SiebelAppFacade.CTI = this.CTI;
            this.GetPM().AttachPMBinding('UpdateHTMLControl', this.updateHTMLControl, { scope: this });
            this.GetPM().AttachPMBinding('ShowStatusText', this.showStatusText, { scope: this });
            if (typeof SiebelAppFacade.CTIPM === 'undefined') SiebelAppFacade.CTIPM = this.GetPM();
            //if (typeof SiebelAppFacade.CTI.avayaAccept === 'undefined') SiebelAppFacade.CTI.avayaAccept = SiebelAppFacade.CommToolbarPhyRenderer.prototype.ShowCTI;
            // SiebelAppFacade.RICDCShowCTIPanel.call(this);
            // document.getElementById('CommunicationPanel').style.display = 'none';
            // document.getElementById('CTIToolbar').style.display = 'none';
            // document.getElementById('Dashboard').style.display = 'none';
            // document.getElementById('CommunicationPanelContainer').classList.add('rri-cti-container');
        };
        return 'SiebelAppFacade.RICDCCommToolbarPR';
    });
}
