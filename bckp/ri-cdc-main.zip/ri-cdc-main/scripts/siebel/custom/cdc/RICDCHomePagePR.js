if (typeof SiebelAppFacade.RICDCHomePagePR === 'undefined') {
  SiebelJS.Namespace('SiebelAppFacade.RICDCHomePagePR');
  define('siebel/custom/cdc/RICDCHomePagePR', [
    'siebel/phyrenderer',
    'siebel/custom/cdc/cdc-utils',
    'siebel/custom/cdc/dist/app',
    'siebel/custom/cdc/dist/cdc-vendor',
  ], function () {
    SiebelAppFacade.RICDCHomePagePR = (function () {
      function RICDCHomePagePR(pm) {
        SiebelAppFacade.RICDCHomePagePR.superclass.constructor.apply(
          this,
          arguments,
        );
      }

      SiebelJS.Extend(RICDCHomePagePR, SiebelAppFacade.PhysicalRenderer);

      RICDCHomePagePR.prototype.Init = function () {
        // Init is called each time the object is initialised.
        // Add code here that should happen before default processing
        SiebelAppFacade.RICDCHomePagePR.superclass.Init.apply(this, arguments);
        // Add code here that should happen after default processing
      };

      RICDCHomePagePR.prototype.ShowUI = function () {
        // ShowUI is called when the object is initially laid out.
        // Add code here that should happen before default processing
        SiebelAppFacade.RICDCHomePagePR.superclass.ShowUI.apply(
          this,
          arguments,
        );

        const pm = this.GetPM();

        const doData = pm.Get('GetRecordSet');

        const onSave = (data) => {
          console.log('data save', data);

          const maps = {
            organization: 'Description',
          };

          SiebelAppFacade.mapsSave(pm, maps, data);
        }

        const data = {
            incomingCallTime: '00:05',
            waitingTimeLine: '00:05',
            organization: '',
            companyGroup: '',
            clientCategory: 'VIP',
            phone: '+74957654321',
            phoneMobile: '+74957654321',
            fio: '',
            skillGroup: 'Corporate VIP',
            additionalGroup: '1011032',
            serviceScenario: 'Прямой звонок клиента на VIP-линию',
            cnum: '',
            inn: '',
          };

        const sAppletId = pm.Get('GetFullId');

        // Add code here that should happen after default processing
         SiebelAppFacade.ModalIncomingCallShow({
           self: this,
           elementId: sAppletId,
           data,
           onSave
        });
      };

      RICDCHomePagePR.prototype.BindData = function (bRefresh) {
        // BindData is called each time the data set changes.
        // This is where you'll bind that data to user interface elements you might have created in ShowUI
        // Add code here that should happen before default processing
        SiebelAppFacade.RICDCHomePagePR.superclass.BindData.apply(
          this,
          arguments,
        );
        // Add code here that should happen after default processing
      };

      RICDCHomePagePR.prototype.BindEvents = function () {
        // BindEvents is where we add UI event processing.
        // Add code here that should happen before default processing
        SiebelAppFacade.RICDCHomePagePR.superclass.BindEvents.apply(
          this,
          arguments,
        );
        // Add code here that should happen after default processing
      };

      RICDCHomePagePR.prototype.EndLife = function () {
        // EndLife is where we perform any required cleanup.
        // Add code here that should happen before default processing
        SiebelAppFacade.RICDCHomePagePR.superclass.EndLife.apply(
          this,
          arguments,
        );
        // Add code here that should happen after default processing
      };

      return RICDCHomePagePR;
    })();
    return 'SiebelAppFacade.RICDCHomePagePR';
  });
}
