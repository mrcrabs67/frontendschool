const pmSave = (pm, name, value) => {
  const bc = pm.Get("GetBusComp");
  const controls = pm.Get("GetControls");

  bc.SetFieldValue(controls[name].GetFieldName(), value);
  pm.ExecuteMethod("InvokeMethod", "WriteRecord");
}

// Deprecated
// Old class, not use !!!
// use EventEmitter
class DataManager {
  subscribers = new Map();

  add(name, param) {
    const subscriber = this.subscribers.get(name);
    if (subscriber) {
      subscriber(param);
    }
  }

  subscribe(name, subscriber) {
    console.error('DataManager deprecated. Change to Events');

    if (!this.subscribers.has(name)) {
      this.subscribers.set(name, subscriber);
    }

    return () => {
      this.subscribers.delete(name);
    };
  }

  getBoundManager() {
    return {
      add: this.add.bind(this),
      subscribe: this.subscribe.bind(this),
    };
  }
}

SiebelAppFacade.mapsSave = (pm, maps, data) => {
  for (const prop in data) {
    if (maps[prop]) {
      pmSave(pm, maps[prop], data[prop]);
    }
  }
}

SiebelAppFacade.getBoundManager = () => {
  const Manager = new DataManager();
  return Manager.getBoundManager();
}

const EventEmitter = () => {
  const events = new Map();
  return {
    add: (name, param) => {
      const func = events.get(name);
      if (func) {
        func(param);
      }
    },
    subscribe: (name, func) => {
      if (!events.has(name)) {
        events.set(name, func);
      } else {
        console.log(`РљР»СЋС‡: ${name} СѓР¶Рµ Р·Р°РЅСЏС‚, РѕРЅ Р±СѓРґРµС‚ Р·Р°РјРµРЅРµРЅ РЅРѕРІС‹Рј.`);

        events.set(name, func);
      }

      return () => {
        events.delete(name);
      };
    },
    list: () => {
      console.log('events', events);
    },
  };
};

const emitter = EventEmitter();

// Singleton EventEmitter
// Not use !!!
const Events = (
  (instance) => () =>
    instance
)({
  add: emitter.add,
  subscribe: emitter.subscribe,
});

const WSS = 'wss://arm-test.raiffeisen.ru/siebel/';

const initWebSocket = () => {
  let socket = null;
  //TODO костыль, который нужно исправить
  let onMessageFn = () => console.log('[ARM WebSocket]: функция обработки сообщений не определена');
  //console.log("socket login = ", login);

  // @param token - строка | функция получения токена
  // @return - WebSocket
  const openWS = (token, uri) => {
    let _socket = typeof token === "string" ? new WebSocket(uri + token) : new WebSocket(uri + token());

    _socket.onopen = function (event) {
      console.log('[ARM WebSocket] соединение открыто')
    }
    _socket.onmessage = onMessageFn;
    _socket.onclose = function (event) {
      //TODO Отключил проверку wasClean, переподключаемся всегда. Надо подумать над необходимостью.
      if (event.wasClean) {
        console.log(`[ARM WebSocket] соединение закрыто, код=${event.code}`);
      } else {
        console.log(`[ARM WebSocket] соединение прервано код=${event.code} причина=${event.reason}`);
      }
      console.log(`[ARM WebSocket] попытка повторного подключения`);
      setTimeout(() => socket = openWS(token, uri), 5000);
    };
    _socket.onerror = function (error) {
      console.log(`[ARM WebSocket] произошла ошбика в соединении: ${error}`)
    }
    return _socket;
  }

  return {
    send: (params) => {
      if (socket?.readyState == 1) {
        socket?.send(JSON.stringify(params));
      }
    },
    data: (func) => {
      console.log(socket);
      onMessageFn = (e) => {
        func(JSON.parse(e.data))
      };
      socket.onmessage = onMessageFn;
    },
    connect: (token, uri = 'wss://arm-test.raiffeisen.ru/siebel/') => {
      console.log('[ARM WebSocket] создание');
      if (socket == null) {
        socket = openWS(token, uri);
      }
      else {
        console.log(`[ARM WebSocket] Сокет инициализирован. readyState = ${socket.readyState}`);
      }
    },
  };
};

const ws = initWebSocket();

const SingleWebSocket = (
  (instance) => () =>
    instance
)({
  send: ws.send,
  data: ws.data,
  connect: ws.connect,
  readyState: ws.readyState,
});


const eventIds = {
  1: (value) => ({
    topic: 'ctiPanelEvents',
    event: { pathEvent: 'hidden', value },
  }),
  2: (value) => ({
    topic: 'ctiPanelEvents',
    event: { pathEvent: 'input.phone.change', value },
  }),
  3: (value) => ({
    topic: 'ctiPanelEvents',
    event: { pathEvent: 'btn.hold.disabled', value },
  }),
  4: (value) => ({
    topic: 'ctiPanelEvents',
    event: { pathEvent: 'btn.hold.pause', value },
  }),
  5: (value) => ({
    topic: 'ctiPanelEvents',
    event: { pathEvent: 'btn.out.disabled', value },
  }),
  6: (value) => ({
    topic: 'ctiPanelEvents',
    event: { pathEvent: 'btn.out.hidden', value },
  }),
  7: (value) => ({
    topic: 'ctiPanelCallTransferEvents',
    event: { pathEvent: 'disabled', value },
  }),
  8: (value) => ({
    topic: 'ctiPanelCallConsultationEvents',
    event: { pathEvent: 'disabled', value },
  }),
  9: (value) => ({
    topic: 'ctiPanelEvents',
    event: { pathEvent: 'btn.ivr.disabled', value },
  }),
  10: (value) => ({
    topic: 'ctiPanelEvents',
    event: { pathEvent: 'btn.callTransfer.disabled', value },
  }),
  11: (value) => ({
    topic: 'ctiPanelEvents',
    event: { pathEvent: 'btn.callTransfer.hidden', value },
  }),
  12: (value) => ({
    topic: 'ctiPanelEvents',
    event: { pathEvent: 'btn.callBack.disabled', value },
  }),
  13: (value) => ({
    topic: 'ctiPanelEvents',
    event: { pathEvent: 'btn.callBack.hidden', value },
  }),
  14: (value) => ({
    topic: 'ctiPanelEvents',
    event: { pathEvent: 'btn.switchToCaller.disabled', value },
  }),
  15: (value) => ({
    topic: 'ctiPanelEvents',
    event: { pathEvent: 'btn.switchToCaller.hidden', value },
  }),
  16: (value) => ({
    topic: 'ctiPanelEvents',
    event: { pathEvent: 'btn.switchToDestination.disabled', value },
  }),
  17: (value) => ({
    topic: 'ctiPanelEvents',
    event: { pathEvent: 'btn.switchToDestination.hidden', value },
  }),
  18: () => ({
    topic: 'ctiPanelCallConsultationEvents',
    event: { pathEvent: 'open' },
  }),
  19: () => ({
    topic: 'ctiPanelCallConsultationEvents',
    event: { pathEvent: 'close' },
  }),
  20: () => ({
    topic: 'ctiPanelCallTransferEvents',
    event: { pathEvent: 'open' },
  }),
  21: () => ({
    topic: 'ctiPanelCallTransferEvents',
    event: { pathEvent: 'close' },
  }),
};

const maps = {
  defaultStateCTI: [
    eventIds[3](false),
    eventIds[4](false),
    eventIds[7](false),
    eventIds[8](false),
    eventIds[9](false),
    eventIds[5](false),
    eventIds[11](true),
    eventIds[13](true),
    eventIds[15](true),
    eventIds[17](true),
  ],
  onHold: [
    eventIds[3](false),
    eventIds[4](true),
    eventIds[7](true),
    eventIds[8](true),
    eventIds[9](true),
    eventIds[5](true),
    eventIds[5](true),
    eventIds[11](true),
    eventIds[13](true),
    eventIds[15](true),
    eventIds[17](true),
  ],
  callOut: [eventIds[1](true)],
  callWithoutConsult: [eventIds[1](true)],
  finishConsult: [
    eventIds[3](false),
    eventIds[4](false),
    eventIds[7](false),
    eventIds[8](false),
    eventIds[9](false),
    eventIds[5](false),
    eventIds[11](true),
    eventIds[13](true),
    eventIds[15](true),
    eventIds[17](true),
  ],
  switchToCaller: [
    eventIds[3](false),
    eventIds[4](false),
    eventIds[7](true),
    eventIds[8](true),
    eventIds[9](false),
    eventIds[5](true),
    eventIds[10](false),
    eventIds[11](false),
    eventIds[12](false),
    eventIds[13](false),
    eventIds[15](true),
    eventIds[16](false),
    eventIds[17](false),
  ],
  onHoldWithConsult: [
    eventIds[3](false),
    eventIds[4](true),
    eventIds[7](true),
    eventIds[8](true),
    eventIds[9](true),
    eventIds[5](true),
    eventIds[10](true),
    eventIds[11](false),
    eventIds[12](true),
    eventIds[13](false),
    eventIds[14](true),
    eventIds[15](false),
    eventIds[17](true),
  ],
  unhold: [
    eventIds[3](false),
    eventIds[4](false),
    eventIds[7](false),
    eventIds[8](false),
    eventIds[9](false),
    eventIds[5](false),
    eventIds[11](true),
    eventIds[13](true),
    eventIds[15](true),
    eventIds[17](true),
  ],
  callWithConsult: [
    eventIds[3](false),
    eventIds[4](false),
    eventIds[7](true),
    eventIds[8](true),
    eventIds[9](false),
    eventIds[5](true),
    eventIds[10](false),
    eventIds[11](false),
    eventIds[12](false),
    eventIds[13](false),
    eventIds[14](false),
    eventIds[15](false),
    eventIds[17](true),
  ],
  transfer: [eventIds[1](true)],
  transferWithOutConsult: [eventIds[1](true)],
  ivr: [
    eventIds[3](false),
    eventIds[4](false),
    eventIds[7](false),
    eventIds[8](false),
    eventIds[9](false),
    eventIds[5](false),
    eventIds[11](true),
    eventIds[13](true),
    eventIds[15](true),
    eventIds[17](true),
  ],
  switchToDestination: [
    eventIds[3](false),
    eventIds[4](false),
    eventIds[7](true),
    eventIds[8](true),
    eventIds[9](false),
    eventIds[5](true),
    eventIds[10](false),
    eventIds[11](false),
    eventIds[12](false),
    eventIds[13](false),
    eventIds[14](false),
    eventIds[15](false),
    eventIds[17](true),
  ],
  onHoldWithConsultOne: [
    eventIds[3](false),
    eventIds[4](true),
    eventIds[7](true),
    eventIds[8](true),
    eventIds[9](true),
    eventIds[5](true),
    eventIds[10](true),
    eventIds[11](false),
    eventIds[12](true),
    eventIds[13](false),
    eventIds[15](true),
    eventIds[16](true),
    eventIds[17](false),
  ],
  onHoldWithConsultTwo: [
    eventIds[3](false),
    eventIds[4](true),
    eventIds[7](true),
    eventIds[8](true),
    eventIds[9](true),
    eventIds[5](true),
    eventIds[10](true),
    eventIds[11](false),
    eventIds[12](true),
    eventIds[13](false),
    eventIds[14](true),
    eventIds[15](false),
    eventIds[17](true),
  ],
  unholdWithConsultOne: [
    eventIds[3](false),
    eventIds[4](false),
    eventIds[7](true),
    eventIds[8](true),
    eventIds[9](false),
    eventIds[5](true),
    eventIds[10](false),
    eventIds[11](false),
    eventIds[12](false),
    eventIds[13](false),
    eventIds[15](true),
    eventIds[16](false),
    eventIds[17](false),
  ],
  unholdWithConsultTwo: [
    eventIds[3](false),
    eventIds[4](false),
    eventIds[7](true),
    eventIds[8](true),
    eventIds[9](false),
    eventIds[5](true),
    eventIds[10](false),
    eventIds[11](false),
    eventIds[12](false),
    eventIds[13](false),
    eventIds[14](false),
    eventIds[15](false),
    eventIds[17](true),
  ],
  ivrWithConsultOne: [
    eventIds[3](false),
    eventIds[4](false),
    eventIds[7](true),
    eventIds[8](true),
    eventIds[9](false),
    eventIds[5](true),
    eventIds[10](false),
    eventIds[11](false),
    eventIds[12](false),
    eventIds[13](false),
    eventIds[15](true),
    eventIds[16](false),
    eventIds[17](false),
  ],
  ivrWithConsultTwo: [
    eventIds[3](false),
    eventIds[4](false),
    eventIds[7](true),
    eventIds[8](true),
    eventIds[9](false),
    eventIds[5](true),
    eventIds[10](false),
    eventIds[11](false),
    eventIds[12](false),
    eventIds[13](false),
    eventIds[14](false),
    eventIds[15](false),
    eventIds[17](true),
  ],
  callWaiting: [
    eventIds[3](true),
    eventIds[4](false),
    eventIds[5](true),
    eventIds[6](false),
    eventIds[7](true),
    eventIds[8](true),
    eventIds[9](false),
    eventIds[10](true),
    eventIds[11](false),
    eventIds[12](false),
    eventIds[13](false),
    eventIds[14](true),
    eventIds[15](false),
    eventIds[17](true),
  ],
};

const eventsMap = (key, emEvent) => {
  maps[key].forEach((item) => {
    emEvent(item.topic, item.event);
  });
};

// instance
SiebelAppFacade.Events = EventEmitter;
SiebelAppFacade.Socket = SingleWebSocket();
SiebelAppFacade.eventsMap = eventsMap;
