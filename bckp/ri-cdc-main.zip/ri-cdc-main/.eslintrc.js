const isCI = require('is-ci');
const fs = require('fs');

const prettierConfig = fs.readFileSync('./.prettierrc', 'utf8');
const prettierOptions = JSON.parse(prettierConfig);

module.exports = {
  extends: [
    'eslint-config-airbnb-base',
    'prettier',
    'plugin:sonarjs/recommended',
  ],
  env: {
    browser: true,
    node: true,
    jasmine: true,
    jest: true,
    es2020: true,
  },
  plugins: ['json', ...(isCI ? [] : ['prettier']), 'sonarjs'],
  parser: '@babel/eslint-parser',
  settings: {
    'import/resolver': {
      node: {
        extensions: ['.js'],
        moduleDirectory: ['node_modules', 'scripts'],
      },
    },
  },
  parserOptions: {
    requireConfigFile: false,
  },
  rules: {
    'no-undef': 'off',
    'new-cap': 'off',
    ...(!isCI ? { 'prettier/prettier': ['error', prettierOptions] } : {}),
  },
};
